<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class lessons extends CI_Controller {

	function __construct() {
        parent::__construct();
        $this->load->model('Generic_model', '', TRUE);
        $this->load->model('system_model', '', TRUE);
        
        /**if (!$this->session->userdata("username")) {
            redirect(base_url() . "index.php/login");
        };**/
        
    }
    
    public function index() {
        $this->load->view('admin/School/lessons/index');
    }
    
    public function adminIndex() {
          if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
			   $fields = '*';//get the class teachers for DATA TABLE
				$wherefieldtablefrom = array('lesson_plan.status'=>0,'lesson_plan.approval_status'=>'Pending Approval');
				$tablefrom = 'lesson_plan';
				$tablejoin = 'teacher';
				$tablejoincondition = 'lesson_plan.teacher_id = teacher.teacher_id';
				$data['records'] =  $this->Generic_model->join($fields, $wherefieldtablefrom, $tablefrom, $tablejoin, $tablejoincondition);
			  
				$this->load->view('admin/School/lessons/admin/index',$data);
			
			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
   //outer else
	} else {
		redirect('login/index');
	}
    }            
        public function approveLPForm($id) {
         if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
			  $fields = '*';
			   $whereArr = array("id" => $id);
			   $result=$this->Generic_model->getData($fields,'lesson_plan',$whereArr);
			   $data['records']=$result[0];
			   $this->load->view('admin/School/lessons/admin/approveLP',$data);  
			
			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
        //outer else
        } else {
                redirect('login/index');
        }
                   }     

        public function approval() {
        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
			 //              var_dump($_POST);
                $id = $this->input->post("LP_id", TRUE);
                
                $date_range = $this->input->post("daterangep", TRUE);
                //                var_dump($date_range);
                $start_date_s = substr($date_range, 0, 10); //getting startdate from date range picker
                $start_date = date('Y-m-d', strtotime($start_date_s));
                $month=date("F",strtotime($start_date));//Month of the LP
                $year=date("Y",strtotime($start_date));//year of the LP

                $end_date_s = substr($date_range, 13, 25);//getting end date from date picker
                $end_date = date('Y-m-d', strtotime($end_date_s));
                
                $dataArr = array(
                    "year" => $year,
                    "month" => $month,
                    "start_date" => $start_date,
                    "end_date" => $end_date, 
                    "date_range" => $date_range,
                    "lesson_plan_des" => $this->input->post("activity"),
                    "comment" => $this->input->post("comment"),
                    "approval_status" => $this->input->post("approval_status"),
                    );
//                var_dump($dataArr);die;
                  $whereArr = array("id" => $id);
                $this->Generic_model->updateData("lesson_plan", $dataArr, $whereArr);
                redirect(base_url() . '/index.php/lessons/adminIndex');  
			
			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
            //outer else
            } else {
                    redirect('login/index');
            }
                    }
        public function approvedLPs($var) {
            if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
			  $id = utf8_decode(urldecode($var));
              //   var_dump($idp);   
              list($t_id,$suject,$class_name)= explode(":",$id);
               $data['ids']=array($t_id,$suject,$class_name);
     //         var_dump($data['ids']);
			   $fields = '*';
			   $whereArr = array("teacher_id" => $t_id,"sub_name" =>$suject,"class_nm" =>$class_name,"approval_status" =>'Approved',"status"=>0);
			   $data['approved']=$this->Generic_model->getData($fields,'lesson_plan',$whereArr);
			   $this->load->view('admin/School/lessons/teacher/approvedLessonPlans',$data);  
			
			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
            //outer else
            } else {
                    redirect('login/index');
            }
                     }
         
        public function viewLPFormModal($id) {
            if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
			     $id_n = utf8_decode(urldecode($id));
               $fields = array("lesson_plan_des","comment");
                $whereArr = array("id" => $id_n);
                $result = $this->Generic_model->getData($fields, 'lesson_plan', $whereArr);
                echo json_encode($result);  
			
			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
                //outer else
                } else {
                        redirect('login/index');
                }

                } 
         
       public function lessonPlansForClasses() {
        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
			 $fields = array("class_name");//get the teacher name to select
        $whereArr=array("status" => 0);
        $data['clz']=$this->Generic_model->getData($fields,'class',$whereArr); 
        //var_dump($data);die;
        
        $this->load->view('admin/School/lessons/admin/lessonPlansForClasses',$data);  
			
			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
        //outer else
        } else {
                redirect('login/index');
        }
        } 
        
        
         public function LPAvailableTeachers($t_idp) { //to load subjects to the form //JQUERY
          if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
			 // var_dump($class_id);die;
           $t_id = utf8_decode(urldecode($t_idp));
//           var_dump($t_id);
            $fields = "class_nm"; //checking availability of LPs
            $whereArr = array("teacher_id" => $t_id,"status" =>0 ,"approval_status"=>'Approved');
            $result = $this->Generic_model->getData($fields, 'lesson_plan', $whereArr);
//           var_dump(count($result));die;
           
                if (count($result)>0) {
                    
                   $whereArr = array("teacher_id" => $t_id,"status" =>0 ,"approval_status"=>'Approved',);
                   $result1 = $this->Generic_model->getData("*", 'lesson_plan', $whereArr);
                   $record = array("record" =>$result1, "rec1"=> $t_id);
//                   var_dump($record);die;
                    echo json_encode($record);die;
                } else {
                   
                    $record = array("record1" => "NONO");
//                     var_dump($result);die;
                      echo json_encode($record);
                }  
			
			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
            //outer else
            } else {
                    redirect('login/index');
            }
   }
        
        public function loadDataLPFormModal($LP_idp) { //to load subjects to the form //JQUERY
          if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
			 // var_dump($class_id);die;
           $LP_id = utf8_decode(urldecode($LP_idp));
//           var_dump($t_id);
            $whereArr = array("id" => $LP_id);
            $result = $this->Generic_model->getData("*", 'lesson_plan', $whereArr);
          //var_dump($result);die;
            echo json_encode($result);
  
			
			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
            //outer else
            } else {
                    redirect('login/index');
            }
   }
   
      public function lessonPlansForTeachers() {
        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
			 $fields = array("teacher_id","t_name",);//get the teacher name to select
			$whereArr=array("status" => 0);
			$data['clz']=$this->Generic_model->getData($fields,'teacher',$whereArr); 
			//var_dump($data);die;
			
			$this->load->view('admin/School/lessons/admin/lessonPlansForTeachers',$data);  
				
			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
            //outer else
            } else {
                    redirect('login/index');
            }
        }  
       
        
        public function LPAvailableClasses
                ($class_idp) { //to load subjects to the form //JQUERY
          if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
			 // var_dump($class_id);die;
           $class_id = utf8_decode(urldecode($class_idp));
//           var_dump($class_id);
           $checkavailabilty = $this->system_model->checkApprovedSubjectLessonPClass($class_id);
//           var_dump($checkavailabilty);die;
                if ($checkavailabilty > 0) {
                    
                      $fields=array("id",
                          "sub_name",
                          "lesson_plan.teacher_id",
                          "year",
                          "month",
                          "date_range","lesson_plan_des","added_on","comment","t_name",    //data table
                             );
                    $wherefieldtablefrom = array("class_nm" => $class_id,"approval_status"=>'Approved');
                    $tablefrom = 'teacher';
                    $tablejoin = 'lesson_plan';
                    $tablejoincondition = 'teacher.teacher_id = lesson_plan.teacher_id';
                    $result =  $this->Generic_model->join($fields, $wherefieldtablefrom, $tablefrom, $tablejoin, $tablejoincondition);
                  $record = array("record" =>$result, "rec1"=> $class_id);
//                   var_dump($record);die;
                    echo json_encode($record);
                } else {
                   
                    $record = array("record1" => "NONO");
//                     var_dump($result);die;
                      echo json_encode($record);
                }  
			
			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
            //outer else
            } else {
                    redirect('login/index');
            }
   }
    
    /////////////////////////IF ADMIN TEACHES ONLY///////////////////////////
    
    
    
//    public function teachers() {
//        $fields = array("t_name","teacher_id");//get the teacher name to select
//        $whereArr=array("status" => 0);
//        $data['TName']=$this->Generic_model->getData($fields,'teacher',$whereArr); 
//        //var_dump($data);die;
//        
//        $this->load->view('admin/School/lessons/teacher/index',$data);
//    }
//    
//    public function teachersIndex() {
//        $TName = $this->input->post("TName");
//        list($t_id,$tname)= explode(":",$TName);
//        $data['tname']=$tname;
//        
//        $fields = "*";//get the subects to be seleceted DATA TABLE
//        $whereArr=array("teacher_id"=>$t_id,"status" => 0);
//        $data['assigns']=$this->Generic_model->getData($fields,'subject_teacher',$whereArr); 
//
//        $fields = "*";//Lesson Plans-Pending DATA TABLE
//        $whereArr=array("teacher_id"=>$t_id,"status" => 0,"approval_status"=>'Pending Approval');
//        $data['records']=$this->Generic_model->getData($fields,'lesson_plan',$whereArr); 
//         
//        $this->load->view('admin/School/lessons/teacher/index_2',$data);
//    }
    
    public function lessonPlanForm($var) {
        $id = utf8_decode(urldecode($var));
         //   var_dump($idp);   
         list($t_id,$suject,$class_name)= explode(":",$id);
          $data['ids']=array($t_id,$suject,$class_name);
//         var_dump($data['ids']);
         $this->load->view('admin/School/lessons/teacher/lessonPlanForm',$data);
    }
    
    public function addLessonPlan() {
//    var_dump($_POST);
         $now = new DateTime();//Foreach to add classes 
         $add_date = $now->format("Y-m-d");
         $dataArr = array(
            "class_nm" => $this->input->post("class"),
            "sub_name" => $this->input->post("subject"),
            "teacher_id" => $this->input->post("teacher_id"),
            "approval_status" => $this->input->post("lp_status"),
            "year" => $this->input->post("year"),
            "month" => $this->input->post("month"),
            "end_date" => $this->input->post("ToD"),
            "lesson_plan_des" => $this->input->post("activity"),
            "added_on" => $add_date,
            "start_date" => $this->input->post("fromD"),
             "date_range" => $this->input->post("daterangep"),
            );
//        var_dump($dataArr );
        $this->Generic_model->insertData('lesson_plan', $dataArr);
        redirect(base_url() . '/index.php/lessons/teachers');
    }
    
     public function editLPFormModal($id) {
                $id_n = utf8_decode(urldecode($id));
               $fields = array("lesson_plan_des", "added_on","id","start_date","end_date","comment","date_range");
                $whereArr = array("id" => $id_n);
                $result = $this->Generic_model->getData($fields, 'lesson_plan', $whereArr);
//                var_dump($result);die;
                echo json_encode($result);

                }
       public function editLPForm() {
//              var_dump($_POST);
                $id = $this->input->post("LP_id", TRUE);
                $dataArr = array(
                    "lesson_plan_des" => $this->input->post("activity"),
                    "added_on" => $this->input->post("add"),
                    "date_range" => $this->input->post("daterangep"),
//                    "start_date" => $this->input->post("fromD"),
//                    "end_date" => $this->input->post("ToD"),       
                    );
                  $whereArr = array("id" => $id);
//                  var_dump($dataArr);
//                  var_dump($whereArr);
                $this->Generic_model->updateData("lesson_plan", $dataArr, $whereArr);
                redirect(base_url() . '/index.php/lessons/teachers');
        }
            
        public function delete_LP($id) { //add grades for the School
                    $dataArr=array("status"=>1);//delete Student
                    $WhereArr=array('id'=>$id);
                   
                    $this->Generic_model->updateData("lesson_plan",$dataArr,$WhereArr);
                    
                   redirect(base_url() . '/index.php/lessons/teachers');

                }           
                
     
}