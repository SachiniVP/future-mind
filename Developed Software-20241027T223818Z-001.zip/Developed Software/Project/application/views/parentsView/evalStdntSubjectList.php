
<!DOCTYPE html>
<!--Administrator Dashboard-->

   
<!-- BEGIN HEAD-->
<head>
       
    <title>Student Subject List</title>
    <?php echo $this->load->view('admin_panel/template/header'); ?>
    <!-- PAGE LEVEL STYLES -->
    <link href="<?=base_url();?>assets/admin_assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
    <!-- END PAGE LEVEL  STYLES -->
</head>
<!-- END  HEAD-->    
   
    
    <!-- BEGIN BODY-->
<body class="padTop53" >

     <!-- MAIN WRAPPER -->
    <div id="wrap" style="background-color:#b8b8b8;">
        <!--HEADER SECTION -->
         <?php echo $this->load->view('admin_panel/template/navbar'); ?>
        <!-- END HEADER SECTION -->
        


        <!-- MENU SECTION -->
          <?php echo $this->load->view('parentsView/parents_menubar'); ?>
        <!--END MENU SECTION -->


        <!--PAGE CONTENT -->
        <div id="content" >
            
            <div class="inner" style="min-height:1200px;background-color:transparent">
                <!---breadcrumb--->
                <div class="row">
                    <div class="col-md-12">
                        <div class="col-lg-12">
                            <div class="well-sm">
                                <div style="">
                                    <ul class="breadcrumb"  >
                                    <li> <a href="<?php echo base_url()."index.php/parentsController/parentsDashboard"?>"> Dashboard </a> </li>
                                     <li class="active">Students Subject List</li>
                                </ul>
                                </div>    
                            </div>
                        </div> <!-- /.col-lg-12 --> 
                    </div> <!-- /.col-md-12 -->
                </div><!-- /.row -->
                <!---END breadcrumb--->
                
          
                <div class="well" style=" background-color: transparent;"> 
                <div class="col-sm-offset-1"><h3 style="font-family: calibri;margin-top:-10px"> Subjects </h3> </div> 
                <div class="container-fluid">
                     </div>
                <div class="row"><!--Renewals-->
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"> 
                        <div container='fluid'> 
                            <div class="well well-lg">
                                <div class="panel-body"> <!--DataTable-->
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered table-hover" id="dataTables-example" class="display" cellspacing="0" width="100%"> 
                                            <thead>
                                                <tr>
                                                    <th>Teacher</th>
                                                    <th>Subject</th>
<!--                                                     <th>Activity</th>
                                                     <th>Description</th>
                                                     <th>Effective Date</th>-->
                                                     <th> </th>
                                                </tr>
                                            </thead>
                                            <tbody center>
                                                <?php
                                                foreach ($subjects as $userItem) {
                                                           echo "<tr>";
                                    echo "<td>" .$userItem->t_name. "</td>";
                                    echo "<td>" . $userItem->sub_name. "</td>";
                                    echo "<td>";
//                                    echo "<a id='" . $userItem->class_name . "' href='#editclassFormModal' data-toggle='modal' class='editClass btn btn-primary btn-circle'><i class='icon-edit'></i></a>";
                                    echo "<a href='". base_url()."index.php/parentsController/evalStudentActSumery/".$userItem->sub_name.':'.$userItem->teacher_id.':'.$userItem->t_name.':'.$userItem->class_name.':'.$child_id."' > <button type='button' class='btn btn-info' >
                                                       <i class='icon-plus-sign'><b> View Details </b></i></button></a> ";
                                    echo"</td>";
                                                }
                                                ?>  
                                            </tbody>
                                        </table>
                                    </div>
                                </div><!--Data TAble-->                          
                            </div>
                        </div> 
                    </div>
                </div><!--END Renewals-->
                </div> 
                
          
              
              
                     
            </div>
           </div><!--END PAGE CONTENT -->
        </div><!--END MAIN WRAPPER -->
    
    
                <!-- PAGE LEVEL SCRIPTS -->
                <?php echo $this->load->view('admin_panel/template/footer'); ?> 
                
                
                <script src="<?=base_url();?>assets/admin_assets/plugins/dataTables/jquery.dataTables.js"></script>
                <script src="<?=base_url();?>assets/admin_assets/plugins/dataTables/dataTables.bootstrap.js"></script>
                <script>
                     $(document).ready(function () {
                         $('#dataTables-example').dataTable();
                     });
                </script>
                <!-- END PAGE LEVEL SCRIPTS -->  
                
                 
</body> 
<!-- END BODY-->
   
 
</html>

