<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class events extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('Generic_model', '', TRUE);
        $this->load->model('system_model', '', TRUE);
        /**if (!$this->session->userdata("username")) {
            redirect(base_url() . "index.php/login");
        };**/
        
    }
    
    public function index() {
                if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];


            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);               
//                var_dump($data);
                $this->load->view('admin/events/addEvents',$data);

            } else {
                
               $this->load->view('admin/accessDeniedPage');
            }
       //outer else
        } else {
            redirect('login/index');
        }
    }
    
    
            public function add_event() { //add new event
                   if ($this->session->userdata('logged_in')) {

                        $session_data = $this->session->userdata('logged_in');
                        $group_id = $session_data['group_id'];
                        $username = $session_data['username'];


                        // inner if
                        if ($group_id === "10") {
                            //get user info 
                            $fields = "*";//get teacher info
                            $whereArr=array("user_id" => $username);
                            $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
//var_dump($_POST);die;
//                          $now = new Date();
                            $date = date('Y-m-d');
                            //insert new user    
                            $dataArr = array(
                                    "target_group" => $this->input->post("target_group"),
                                    "add_date" =>$date,
                                    "added_by" => $username,
                                    "header" => $this->input->post("header"),
                                     "description" => $this->input->post("des"),
                                     "e_date"=>$this->input->post("e_date"),
                                    );
//                                    var_dump($dataArr);die;
                            $this->Generic_model->insertData('events', $dataArr);
                               redirect(base_url().'index.php/events/manageEvents');
                                                           
                        } else {

                           $this->load->view('admin/accessDeniedPage');
                        }
                   //outer else
                    } else {
                        redirect('login/index');
                    }
                }
      public function manageEvents() {
                if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];


            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);               
//                var_dump($data);
                 $fields = "*";//get teacher info
                $whereArr=array("status" => 0);
                $data['AllEvents']=$this->Generic_model->getData($fields,'events',$whereArr);
                $this->load->view('admin/events/manageEvents',$data);

            } else {
                
               $this->load->view('admin/accessDeniedPage');
            }
       //outer else
        } else {
            redirect('login/index');
        }
    }
    
            public function editEventForm($id) {
           if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
                $id = utf8_decode(urldecode($id));
         // var_dump($id);
                $fields = "*";
                $whereArr = array("id" => $id);
                $result = $this->Generic_model->getData($fields, 'events', $whereArr);
                
            echo json_encode($result);
			
        } else {
                  $this->load->view('admin/accessDeniedPage');
               }
  //outer else
       } else {
               redirect('login/index');
       }
    } 
    public function editEvent() {
               
    if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
			   //              var_dump($_POST);
                 $id = $this->input->post("log_id", TRUE);
                $header = $this->input->post("header", TRUE);
                $header_ltrim = ltrim($header, " ");
                
                $dataArr = array(
                    "header" => $header_ltrim,
                    "description" =>$this->input->post("des", TRUE),
                    "target_group" => $this->input->post("target_group", TRUE),
                    "e_date"=>$this->input->post("e_date"),
                 );
                //var_dump($dataArr);
                    $whereArr = array("id" => $id);
                    $result = $this->Generic_model->updateData("events", $dataArr, $whereArr);
                    redirect('events/manageEvents');
//                    $record = array("record1" => $result);
//                   echo json_encode($record);
                
			
        } else {
                  $this->load->view('admin/accessDeniedPage');
               }
  //outer else
       } else {
               redirect('login/index');
       }

    }
    
                     public function delete_event($id) { //add grades for the School
                     if ($this->session->userdata('logged_in')) {

                    $session_data = $this->session->userdata('logged_in');
                    $group_id = $session_data['group_id'];
                    $username = $session_data['username'];


                    // inner if
                    if ($group_id === "10") {
                        //get user info 
                        $fields = "*";//get teacher info
                        $whereArr=array("user_id" => $username);
                        $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            

                           $data=array("status"=>1);//delete Student
                            $WhereArr=array('id'=>$id);

                            $this->Generic_model->updateData("events",$data,$WhereArr);

                            redirect(base_url().'/index.php/events/manageEvents');


			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
		   //outer else
			} else {
				redirect('login/index');
			}
                }
    
    
    public function showEvents() { //to load events to the dashboard
          if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];


            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);     
                
                    $now = new DateTime();
                    $today = $now->format("Y-m-d");
                    
                    //get events
                    $where=array("e_date >=" => $today ,"status" => 0);
                    $asc_field = 'e_date';
                    $result = $this->Generic_model->getDataSortAsc('*', 'events', $where,$asc_field);
//                    var_dump(count($result));die;
                if(count($result)>0){
                    $record = array("record" =>$result, "recd"=> 'YES');
                    echo json_encode($record);
                    die;
//                                              var_dump($record);die;
                }else{
                    $record = array("recd"=> 'NONO');
                    echo json_encode($record);
                }

            } else {
                
               $this->load->view('admin/accessDeniedPage');
            }
       //outer else
        } else {
            redirect('login/index');
        }
    }
    

}


