
<!DOCTYPE html>
<!--Administrator Dashboard-->

   
<!-- BEGIN HEAD-->
<head>
       
    <title>Approved Lesson Plans Index</title>
    <?php echo $this->load->view('admin_panel/template/header'); ?>
    <!-- PAGE LEVEL STYLES -->
    <link href="<?=base_url();?>assets/admin_assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
    <!-- END PAGE LEVEL  STYLES -->
</head>
<!-- END  HEAD-->    
   
    
    <!-- BEGIN BODY-->
<body class="padTop53" >

     <!-- MAIN WRAPPER -->
    <div id="wrap" style="background-color:#b8b8b8;">
        <!--HEADER SECTION -->
         <?php echo $this->load->view('admin_panel/template/navbar'); ?>
        <!-- END HEADER SECTION -->
        


        <!-- MENU SECTION -->
          <?php echo $this->load->view('teacherViews/teacher_menubar'); ?>
        <!--END MENU SECTION -->


        <!--PAGE CONTENT -->
        <div id="content" >
            
            <div class="inner" style="min-height:1200px;background-color:transparent">
                <!---breadcrumb--->
                <div class="row">
                    <div class="col-md-12">
                        <div class="col-lg-12">
                            <div class="well-sm">
                                <div style="">
                                    <ul class="breadcrumb"  >
                                    <li> <a href="<?php echo base_url()."index.php/teacherController/teacherDashboard"?>"> Dashboard </a> </li>
                                    <li class="#"> School Settings </li>
                                    <li><a href="<?php echo base_url() . "index.php/teacherController/lessonPlanIndex" ?>">Lesson Plans(TEACHERS)</a></li>
                                    <li class="active"> Approved Lesson Plan Index</li>
                                </ul>
                                </div>    
                            </div>
                        </div> <!-- /.col-lg-12 --> 
                    </div> <!-- /.col-md-12 -->
                </div><!-- /.row -->
                <!---END breadcrumb--->
          
                <div class="well" style=" background-color: transparent;"> <!--  Table-->   
                <div class="col-sm-offset-1"><h2 style="font-family:serif;margin-top:-10px"> Approved Lesson Plans for <?php echo $ids[2] ; ?> <?php echo $ids[1] ; ?> </h2> </div> 
            </br>     
                <div class="row"> 
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                 <!--<div class="col-lg-9">--> 
                    <div class="well well-lg">
                         <div class="panel-body">
                            <div class="table-responsive">
                               <table class="table table-striped table-bordered table-hover" id="dataTables-example" class="display" cellspacing="0" width="100%">    <thead>
                                        <tr>
                                            <th>Year</th>
                                            <th>Month</th>
                                            <th>Date Range</th>
                                            <th>Added On</th>
                                            <th>Comments</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody center>
                                        <?php
                                foreach ($approved as $userItem) {
                                    echo "<tr>";
                                    echo "<td>" . $userItem->year . "</td>";
                                    echo "<td>" . $userItem->month. "</td>";
                                    echo "<td>" . $userItem->date_range . "</td>";
                                    echo "<td>" . $userItem->added_on. "</td>";
                                    echo "<td>" . $userItem->comment . "</td>";
                                    echo "<td>";
                                    echo "<a id='" . $userItem->id . "' href='#viewFormModal' data-toggle='modal' class='viewLP btn btn-info btn-circle'>
                                                        <i class='icon-eye-open'></i></a> ";
//                                    echo "<a href='". base_url()."index.php/lessons/delete_LP/".$userItem->id."' > <button type='button' class='btn btn-warning btn-circle' id='btnWarning'>
//                                                        <i class='icon-trash'></i></button></a> ";
                                    echo"</td>";
                                }
                                ?>  
                                    </tbody>
                                </table>
                            </div>
                         </div><!--Data TAble-->                          
                    </div>  
                <!--</div>--> 
                </div>
                </div>
            </div><!-- END Table-->
              
               </div><!-- Inner-->      
           </div><!--END PAGE CONTENT -->
           
           
           
           
           
           <!-- Edit Class Form Modal  -->
                <div id="viewFormModal" data-backdrop="static" data-keyboard="false" class="modal fade" role="dialog" aria-labelledby="gridSystemModalLabel">
                    <div class="modal-dialog modal-lg" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                <h4 class="modal-title" id="gridSystemModalLabel">Approved Lesson Plan | View</h4>
                            </div>
                            <form  id="viewLPForm" class="form-horizontal" method="POST" action="#">
                
                        <div class="modal-body">
                            <div class="hide">
                                <input  id="LP_id" name="LP_id"  class="form-control hidden" readonly/> 
                            </div>
                           
                        <div class='row'> 
                                <div class='row'>
                                    <div class='col-sm-3'> 
                                            <label for="Activity" class="control-label"> Activity</label>
                                        </div>
                                    <div class='col-sm-7'>
                                            <div class='form-group'>
                                                <textarea id="activity" name="activity" rows="5" cols="100" class="form-control" readonly></textarea>
                                            </div>
                                    </div>
                                </div> 
                                <div class='row'>
                                    <div class='col-sm-3'> 
                                            <label for="Comment" class="control-label"> Comment</label>
                                        </div>
                                    <div class='col-sm-7'>
                                            <div class='form-group'>
                                                <textarea id="comment" name="comment" rows="3" cols="100" class="form-control" readonly></textarea>
                                            </div>
                                    </div>
                                </div> 
                                <div class='row'> 
                                    <div class='col-sm-2'> 
                                             <label for="grade_name">Added On</label>
                                    </div>
                                    <div class='col-sm-3'><div class='form-group'>
                                            <input type="text" class="form-control" id="add" name="add" value="" required="" readonly>
                                    </div></div>
                                </div>
                                </div>
                                </div><!--//modalbody-->
                                <div class="modal-footer">
                                      <button id="cls" type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                </div><!-- /. modal-footer -->
                            </form>
                        </div><!-- /.modal-content -->
                    </div><!-- /.modal-dialog -->
                </div><!-- /.modal -->
                <!--/. Edit Class Form Modal -->

           
           
           
           
           
        </div><!--END MAIN WRAPPER -->
    
    
                <!-- PAGE LEVEL SCRIPTS -->
                <?php echo $this->load->view('admin_panel/template/footer'); ?> 
                     <!--DATA Table-->
                <script src="<?=base_url();?>assets/admin_assets/plugins/dataTables/jquery.dataTables.js"></script>
                <script src="<?=base_url();?>assets/admin_assets/plugins/dataTables/dataTables.bootstrap.js"></script>
                <script>
                     $(document).ready(function () {
                         $('.table ').dataTable();
                     });
                </script>
                <!-- END PAGE LEVEL SCRIPTS -->  
           
                                           
                
                <!--Load view Lesson Plan Modal-->
                    <script> 
               $(".viewLP").click(function () {
                baseurl = "http://localhost:8080/Project/";
                p_id = this.id;
                $('#viewLPForm')[0].reset();
                $.ajax({
                    url: baseurl + "index.php/teacherController/viewLPFormModal/" + p_id,
                    // data: {po_no: po_no},
                    dataType: 'json',
                    success: function (data) {

                        var id = data[0]["id"];
                        var act = data[0]["lesson_plan_des"];
                        var on = data[0]["added_on"];
                        var da = data[0]["comment"];
                        
                        $("#activity").val(act);
                        $("#comment").val(da);
                        $("#LP_id").val(id);
                        $("#add").val(on);
                        
                  }
                });
            });
                    </script>
                
          <script> //Delete Button for all on Data Tables
                $(document).ready(function() {
                            $("button#btnWarning").click(function(){
                              return confirm("You are going to REMOVE this delete!!");
                            }); 
                });
          </script>      
                
                
                
                
                
                
</body> 
<!-- END BODY-->
   
 
</html>

