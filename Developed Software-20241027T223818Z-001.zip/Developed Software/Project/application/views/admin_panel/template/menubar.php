<div id="left">
          
            <div class="media user-media well-small">
           
                <br />
                <div class="media-body" style="height: 80px;">
                   <h6 class="media-heading" style="color:black;font-family: calibri;font-size: medium;"><strong>Welcome</strong></h6>
                   <h5 class="media-heading" style="color:black;font-family: calibri;font-size: medium;"><strong><?php echo $userData[0]->name; ?></strong></h5>
                    
                </div>
                <br />
            </div>  
            <ul id="menu" class="collapse" style="font-weight: bolder;font-family: calibri;font-size: medium;">

                
                <li class="panel">
                    <a href="<?php echo base_url()."index.php/dashboard/"?>" >
                        <i class="icon-table"></i> Dashboard                       
                    </a>                   
                </li>

                <li class="panel">
                    <a href="#" data-parent="#menu" data-toggle="collapse" class="accordion-toggle" data-target="#persaonal-details-nav">
                        <i class="icon-tasks"> </i> Personal Details     
	   
                        <span class="pull-right">
                          <i class="icon-angle-left"></i>
                        </span>
                       &nbsp; <span class="label label-default">2</span>&nbsp;
                    </a>
                    <ul class="collapse" id="persaonal-details-nav" >
                       
                        <li class=""><a href="<?php echo base_url()."index.php/student/"?>"><i class="icon-angle-right"></i> Students </a></li>
                         <li class=""><a href="<?php echo base_url()."index.php/teacher/"?>"><i class="icon-angle-right"></i> Teachers </a></li>
                                                
                    </ul>
                </li>   
                <li class="panel">
                    <a href="#" data-parent="#menu" data-toggle="collapse" class="accordion-toggle" data-target="#school-setup-nav">
                        <i class="icon-tasks"> </i> School Settings     
	   
                        <span class="pull-right">
                          <i class="icon-angle-left"></i>
                        </span>
                       &nbsp; <span class="label label-default">4</span>&nbsp;
                    </a>
                    <ul class="collapse" id="school-setup-nav" >
                        <li class=""><a href="<?php echo base_url()."index.php/classDetails/"?>"><i class="icon-angle-right"></i> Class Details </a></li>
                         <li class=""><a href="<?php echo base_url()."index.php/lessons/adminIndex"?>"><i class="icon-angle-right"></i> Lesson Planing </a></li>
                        <li class=""><a href="<?php echo base_url()."index.php/evaluation/evalIndex"?>"><i class="icon-angle-right"></i> Student Evaluation </a></li>
                         <li class=""><a href="<?php echo base_url()."index.php/setUp/settings"?>"><i class="icon-angle-right"></i> Initial Set up </a></li>
                       
                    </ul>
                </li>  
                <li class="panel">
                    <a href="<?php echo base_url()."index.php/payments/admissionsRegistrations"?>" >
                        <i class="icon-tasks"></i> Registrations                       
                    </a>                   
                </li>
                
                <li class="panel">
                    <a href="#" data-parent="#menu" data-toggle="collapse" class="accordion-toggle" data-target="#fee-management">
                        <i class="icon-tasks"> </i> Fee Management
	   
                        <span class="pull-right"> 
                          <i class="icon-angle-left"></i>
                        </span>
                       &nbsp; <span class="label label-default">2</span>&nbsp;
                    </a>
                    <ul class="collapse" id="fee-management" >
                       
                        <li class=""><a href="<?php echo base_url()."index.php/payments/"?>"><i class="icon-angle-right"></i> Payments  </a></li>
                         <!--<li class=""><a href="<?php echo base_url()."index.php/payments/admissionsRegistrations"?>"><i class="icon-angle-right"></i> Admissions & Registrations </a></li>-->
                        <li class=""><a href="<?php echo base_url()."index.php/payments/allPayments"?>"><i class="icon-angle-right"></i> All Payments </a></li>
                        
                    </ul>
                </li>
                <li class="panel">
                    <a href="#" data-parent="#menu" data-toggle="collapse" class="accordion-toggle" data-target="#events">
                        <i class="icon-tasks"> </i>  Events/Notices
	   
                        <span class="pull-right"> 
                          <i class="icon-angle-left"></i>
                        </span>
                       &nbsp; <span class="label label-default">2</span>&nbsp;
                    </a>
                    <ul class="collapse" id="events" >
                       
                        <li class=""><a href="<?php echo base_url()."index.php/events/"?>"><i class="icon-angle-right"></i> Add Events </a></li>
                         <li class=""><a href="<?php echo base_url()."index.php/events/manageEvents"?>"><i class="icon-angle-right"></i> Manage Events </a></li>
                
                    </ul>
                </li>

                <li class="panel">
                    <a href="#" data-parent="#menu" data-toggle="collapse" class="accordion-toggle" data-target="#users">
                        <i class="icon-tasks"> </i> Users
	   
                        <span class="pull-right"> 
                          <i class="icon-angle-left"></i>
                        </span>
                       &nbsp; <span class="label label-default">3</span>&nbsp;
                    </a>
                    <ul class="collapse" id="users" >
                       
                        <li class=""><a href="<?php echo base_url()."index.php/users/"?>"><i class="icon-angle-right"></i> Manage Users</a></li>
                         <li class=""><a href="<?php echo base_url()."index.php/users/activeUsers"?>"><i class="icon-angle-right"></i> Active Users</a></li>
                        <li class=""><a href="<?php echo base_url()."index.php/users/newUsers"?>"><i class="icon-angle-right"></i> New Users</a></li>
                        
                    </ul>
                </li>
                <li class="panel">
                    <a href="<?php echo base_url()."index.php/reports/"?>" >
                        <i class="icon-tasks"></i> Reports                       
                    </a>                   
                </li>
<!--                <li class="panel">
                    <a href="<?php echo base_url()."index.php/attendance/"?>" >
                        <i class="icon-tasks"></i> Attendance                       
                    </a>                   
                </li>-->

                          
             

            </ul>

        </div>