<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

session_start();

class reset_password extends CI_Controller {

        function __construct() {
        parent::__construct();
        $this->load->model('Generic_model', '', TRUE);
        $this->load->model('system_model', '', TRUE);
    }


    
    public function index() {
        $this->load->view('logins/resetPasswdPage');
    }	

    public function checkUsername() {
        $username = $this->input->post('username');
        $decoded_username = utf8_decode(urldecode($username));
        
        $fieldsUsername = array("id");
        $whereArrUsername = array("username"=>$decoded_username, "status" => 0);
        $dataUsername = $this->Generic_model->getData($fieldsUsername, 'login', $whereArrUsername);
        $count = count($dataUsername);


        if ($count > 0) {
            echo json_encode(TRUE);
        } else {
            echo json_encode(FALSE);
        }
    }
        //verify the user 
        public function verifyUser() {

        $user = $this->input->post('username', TRUE);
        $psw = $this->input->post('password', TRUE);

        $fields = array("username", "password", "email", "group_id", "status");
        $whereArr = array("username" => $user, "password" => sha1($psw),"status" =>0);
        $result = $this->Generic_model->getData($fields, 'login', $whereArr);
        //var_dump($data);die;
        
        if(count($result) == 1){

              $sess_array = array('username' => $result[0]->username,
                'password' => $result[0]->password,
                'group_id' => $result[0]->group_id,
                'status' => $result[0]->status);
            $this->session->set_userdata('logged_in', $sess_array);

            redirect('login/userDirectory');
        } else {
        
            $this->session->set_flashdata('msg', 'OK');
            redirect('login/index');
            }
        }
        
        public function resetPassword() {

        $username = $this->input->post('username', TRUE);
        $decoded_username = utf8_decode(urldecode($username));
        
        $fieldsUsername = array("id");
        $whereArrUsername = array("username"=>$decoded_username, "status" => 0);
        $dataUsername = $this->Generic_model->getData($fieldsUsername, 'login', $whereArrUsername);
//        var_dump($dataUsername);
        $count = count($dataUsername);
//        var_dump($count);
        
        if ($count !== 0) {
                
                $fields = "email";
                    $whereArr = array("username" =>$username,"status" =>0);
                    $emailArr = $this->Generic_model->getData($fields, 'login', $whereArr);
                    $email=$emailArr[0]->email;
                    //generate the user temp_password
                    $this->load->helper('string');
                    $temp_password = random_string('alpha', 8);

                    $temp_pw_hash = sha1($temp_password);

                    //update the user Temp password
                    $dataUser = array("temp_password" =>$temp_pw_hash);
                    $whereArrUser = array("username" =>$username, "status" => 0);
                    $result = $this->Generic_model->updateData("login", $dataUser, $whereArrUser);
//                    var_dump($result);die;
                    if ($result) {
                              // load the My_PHPMailer library : Student Email
                                $this->load->library('My_PHPMailer');

                                $date = date("Y/m/d");
                                $body_message = "<p>Hi,</p>
                                                <p>A reset password request has been recieved for your login at Future MINDS (AMI) Montessori School</p>
                                                <p>To reset your password, please follow this link: <a class='btn btn-primary' href='http://localhost:8080/Project/index.php/reset_password/newUserForm/'>Reset Password</a>.</p>
                                                <p>Your User Name  is :<p > $username </p> </p>
                                                <p>Your Referance Code is :<p style='font-weight: bold;'>$temp_password</p> </p>
                                                <p>Thanks!</p>
                                                <p>System Administrator,</p>
                                                <p>Future MINDS (AMI) Montessori School</p>";

                                $maildata["subject"] = "Reset Password";
                                $maildata["recepients"] = array(array('email' => $email));
//                                var_dump($maildata["recepients"]);
                                $maildata["mailbody"] = $body_message;
                                $maildata["date"] = $date;
                                $maildata["altmailbody"] = "Future MINDS (AMI) Montessori School - Administration<br/><br/>";

                                $mail = new My_PHPMailer();
                                $result_email = $mail->sendcustomemail($maildata);
//                                var_dump($result_email);die;
                                if ($result_email['status']) {
                                    $record = array("record" => "EmailSent");
                                    echo json_encode($record);
                                } else {
                                    $record = array("record" => "EmailNotSent");
                                    echo json_encode($record);
                                }
                    }
            } else {
        
                   $record = array("record" => "NOUSER");
                echo json_encode($record);
                die; 
                }        
        }
          
    
            public function checkNewUsername() {
        $username = $this->input->post('username');
        $decoded_username = utf8_decode(urldecode($username));
        
        $fieldsUsername = array("id");
        $whereArrUsername = array("username"=>$decoded_username, "status" => 0);
        $dataUsername = $this->Generic_model->getData($fieldsUsername, 'login', $whereArrUsername);
        $count = count($dataUsername);


        if ($count > 0) {
            echo json_encode(TRUE);
        } else {
            echo json_encode(FALSE);
        }
    }
         public function newUserForm() {
        $this->load->view('logins/newUserForm');
            }
            
        public function newUserPassword() {
        $psw1 = $this->input->post('password', TRUE);
        $psw1_ltrim = ltrim($psw1," ");
        $psw2 = $this->input->post('password2', TRUE);
        $psw2_ltrim = ltrim($psw2," ");
        $username = $this->input->post("username");
        
        $temp_pw = $this->input->post("temp_password");
        $temp_pw_ltrim = ltrim($temp_pw," ");
        $temp_pw_hash = sha1($temp_pw_ltrim); //geting the hash value of entered tempary pw
//        var_dump($temp_pw_hash);
        
        $fields = array("temp_password",);
        $whereArr = array("username" => $username, "status" =>0);
        $result = $this->Generic_model->getData($fields, 'login', $whereArr);
        $result2=$result[0]->temp_password;
//        var_dump($result[0]->temp_password);

//        var_dump(preg_match('/\s/',$psw1));
                      
//        var_dump(!isset($psw1) || trim($psw1) != '');die;
          if ($temp_pw_hash===$result2){
              
              if (!isset($psw1) || trim($psw1) != '') { //pw not empty
                  
              if (preg_match('/\s/',$psw1)===0){ //pw contains no white spaces
              
                if ($psw1_ltrim===$psw2_ltrim) {

                        $pw_hash = sha1($psw1_ltrim);

                    $dataArr = array(
                            "password" => $pw_hash,
                            "active_status"=>0,
                            "temp_password"=>"",
                            );
                    $whereArr = array("username" => $username,"status"=>0 );
                    $result=$this->Generic_model->updateData('login', $dataArr, $whereArr);

                         if ($result){ //successfully done
                           $record = array("record" => "DONE");
                           echo json_encode($record);
                         }

                    } else {//strings not mathes
                    $record = array("record" => "NOTMATCH");
                           echo json_encode($record);
                    }
                    
                    
              }else{ //pw has white space
                   $record = array("record" => "WHITE");
                           echo json_encode($record);
                          die;
                     }
                     
          }
        }  else { //temp stringnot match
            
            $record = array("record" => "TEMP");
                           echo json_encode($record);
        }
        
        }  
    }
