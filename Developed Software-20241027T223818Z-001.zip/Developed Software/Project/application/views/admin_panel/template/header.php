     <meta charset="UTF-8" />
        <meta content="width=device-width, initial-scale=1.0" name="viewport" />
	<meta content="" name="description" />
	<meta content="" name="author" />
     <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
    <!-- GLOBAL STYLES -->
    <!-- GLOBAL STYLES -->
   
    <link  href="<?=base_url();?>assets/admin_assets/plugins/bootstrap/css/bootstrap.css" rel="stylesheet">
    <link  href="<?=base_url();?>assets/admin_assets/css/main.css" rel="stylesheet">
    <link  href="<?=base_url();?>assets/admin_assets/css/theme.css" rel="stylesheet">
    <link  href="<?=base_url();?>assets/admin_assets/css/MoneAdmin.css" rel="stylesheet">
    <link  href="<?=base_url();?>assets/admin_assets/plugins/Font-Awesome/css/font-awesome.css" rel="stylesheet">
    <!--END GLOBAL STYLES -->

    <!--css to display errors-->
    <style>  
             .error{
                        color: red;
                        font-style: italic;
                     }
    </style>
     