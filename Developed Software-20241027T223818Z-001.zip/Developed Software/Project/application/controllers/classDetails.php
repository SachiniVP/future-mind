<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class classDetails extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('Generic_model', '', TRUE);
         $this->load->model('system_model', '', TRUE);
//        $this->load->model('system_model', '', TRUE);
        /**if (!$this->session->userdata("username")) {
            redirect(base_url() . "index.php/login");
        };**/
        
    }
    
    public function index() {
        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];


            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
                
					$fields = array("class_name");//get the teacher name to select
					$whereArr=array("status" => 0);
					$data['clz']=$this->Generic_model->getData($fields,'class',$whereArr); 
				  
					$this->load->view('admin/School/classes/classDetails',$data);

            } else {
                
               $this->load->view('admin/accessDeniedPage');
            }
       //outer else
        } else {
            redirect('login/index');
        }
    }
    
    public function studentTable($class_idp) { //to load subjects to the form //JQUERY
          if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];


            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
                
                        $class_id = utf8_decode(urldecode($class_idp));
             //           var_dump($class_id);die;
                        $checkavailabilty = $this->system_model->checkStudentsAvail($class_id);
//                        var_dump($checkavailabilty);
                            if ($checkavailabilty === '0'){
                                 
                            $record = array("record1"=>'NONO');
                            echo json_encode($record);
                            die;
                         }
                         else{
                                     $fields=array(       //data table
                                       "child.child_id", 
                                       "first_name",
                                       "last_name",
                                       "date_of_birth",
                                       "middle_name", 
                                       "child_tel_no",
                                       "reg_date",
                                       );
                                    $wherefieldtablefrom = array('child.child_status'=>0,'registration.class_name'=>$class_id,'registration.status'=>0);
                                    $tablefrom = 'child';
                                    $tablejoin = 'registration';
                                    $tablejoincondition = 'child.child_id = registration.child_id';
                                    $result =  $this->Generic_model->join($fields, $wherefieldtablefrom, $tablefrom, $tablejoin, $tablejoincondition);
                           //                      var_dump($result);die;
                                  
                                    $record = array("record" =>$result, "rec1"=> $class_id);
                           //                   var_dump($record);die;
                         echo json_encode($record);}

            } else {
                
               $this->load->view('admin/accessDeniedPage');
            }
       //outer else
        } else {
            redirect('login/index');
        }
    }
    
    public function teachers() {
        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];


            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
                
                $fields = array("class_name");//get the teacher name to select
                $whereArr=array("status" => 0);
                $data['clz']=$this->Generic_model->getData($fields,'class',$whereArr); 

                $this->load->view('admin/School/classes/classDetailsTeachers',$data);

            } else {
                
               $this->load->view('admin/accessDeniedPage');
            }
       //outer else
        } else {
            redirect('login/index');
        }
    }
    
    public function teachersTable($class_idp) { //to load subjects to the form //JQUERY
          if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];


            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
                
                // var_dump($class_id);die;
                 $class_id=utf8_decode(urldecode($class_idp));
            
                $checkavailabilty = $this->system_model->checkClassDetailTeacher($class_id);
        //        var_dump($checkavailabilty);die;
                if ($checkavailabilty > 0) { //if there is a class teacher
                    $fields =array("teacher_id","t_name","fromD","status");//get the Class teachers 
                    $whereArr=array("class_name" =>$class_id,"status"=>0);
                    $result2=$this->Generic_model->getData($fields,'class_teacher',$whereArr);
                    
//                    var_dump($result2);die;
                    $fields ='*';//get subject teachers 
                    $whereArr=array("class_name" =>$class_id,"status"=>0);
                    $result=$this->Generic_model->getData($fields,'subject_teacher',$whereArr); 
                    
                    
                    $record = array("record1"=>'yes',"record" => $result, "record2" => $result2,"rec1"=> $class_id);
                      echo json_encode($record);
                } 
                else{
                    $fields ='*';//get subject teachers 
                    $whereArr=array("class_name" =>$class_id);
                    $teachers=$this->Generic_model->getData($fields,'subject_teacher',$whereArr); 
                    $result=array_filter($teachers, function($v) {
                            return $v->status==0;
                         });
                     $record = array("record" =>$result, "rec1"=> $class_id);
                    echo json_encode($record);     
                         
                }

            } else {
                
               $this->load->view('admin/accessDeniedPage');
            }
       //outer else
        } else {
            redirect('login/index');
        }
                
    }
   
}


