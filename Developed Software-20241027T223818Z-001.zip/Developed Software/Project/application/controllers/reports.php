<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class reports extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('Generic_model', '', TRUE);
        $this->load->model('system_model', '', TRUE);
        /*         * if (!$this->session->userdata("username")) {
          redirect(base_url() . "index.php/login");
          };* */
    }

    public function index() {
        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*"; //get teacher info
                $whereArr = array("user_id" => $username);
                $data['userData'] = $this->Generic_model->getData($fields, 'admins', $whereArr);
                
                        $fields=array(      //Students List to load to form
                                       "child.child_id", 
                                       "first_name",
                                       "last_name",
                                               );
                        $wherefieldtablefrom = array('child.child_status'=>0);
                        $tablefrom = 'child';
                        $tablejoin = 'registration';
                        $tablejoincondition = 'child.child_id = registration.child_id';
                        $data['students_monthlyFee'] =  $this->Generic_model->join($fields, $wherefieldtablefrom, $tablefrom, $tablejoin, $tablejoincondition);

                        //class drop down list
                        $fields = 'class_name'; //To Display in class Details report
                        $whereArr = array("status" => 0);
                        $data['classes'] = $this->Generic_model->getData($fields, 'class', $whereArr);
                        
                        $fields = array("teacher_id","t_name",);//get the teacher name to select
			$whereArr=array("status" => 0);
			$data['clz']=$this->Generic_model->getData($fields,'teacher',$whereArr); 
                        
                        
                $this->load->view('reports/reportIndex2', $data);
            } else {
                $this->load->view('admin/accessDeniedPage');
            }
            //outer else
        } else {
            redirect('login/index');
        }
    }
    
    
    public function classDetailReport() {
        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*"; //get teacher info
                $whereArr = array("user_id" => $username);
                $data['userData'] = $this->Generic_model->getData($fields, 'admins', $whereArr);

                $class_name = $this->input->post("class_name", TRUE);
                $data['class_name']=$class_name;
                
                $class_id=$class_name;
                $checkavailabilty = $this->system_model->checkStudentsAvail($class_id);
                
                if ($checkavailabilty > '0')//report gen only if there are registered students
                {
                $fields=array("*");
                $wherefieldtablefrom = array('child.child_status'=>0,"class_name" => $class_name,'registration.status'=>0);
                $tablefrom = 'child';
                $tablejoin = 'registration';
                $tablejoincondition = 'child.child_id = registration.child_id';
                $results =  $this->Generic_model->join($fields, $wherefieldtablefrom, $tablefrom, $tablejoin, $tablejoincondition);
                $data['studentData'] = $results;
                $count = count($results);
                $data['results_count'] = $count;
//                   var_dump($data);die;
             
                $htmldata = $this->load->view('reports/class_details_students_list', $data, TRUE);

                //Load MPDF From Library
                $this->load->library('mmpdf');
                $mmpdf = $this->mmpdf->load();
                $mmpdf->SetHTMLHeader("");

                $mmpdf->SetFooter("");
                $mmpdf->WriteHTML($htmldata);

                    $mmpdf->Output("Class Detail Report".$class_name.".pdf", 'I');
                }else{
                    redirect('reports/');
                }
            } else {
                $this->load->view('admin/accessDeniedPage');
            }
            //outer else
        } else {
            redirect('login/index');
        }
    }
    
    
    public function classTeachersList() {
        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*"; //get teacher info
                $whereArr = array("user_id" => $username);
                $data['userData'] = $this->Generic_model->getData($fields, 'admins', $whereArr);

                $year = $this->input->post("yearCT", TRUE);
                $data['year'] = $year;
                        
                $fields=array("*");
                $wherefieldtablefrom = array('class_teacher.status'=>0,'year_grade.year'=>$year);
                $tablefrom = 'class_teacher';
                $tablejoin = 'year_grade';
                $tablejoincondition = 'class_teacher.year_grade = year_grade.year_grade';
                $results =  $this->Generic_model->join($fields, $wherefieldtablefrom, $tablefrom, $tablejoin, $tablejoincondition);
                $data['results'] = $results;
                $count = count($results);
                $data['results_count'] = $count;
//                var_dump($data);die;
                
                $htmldata = $this->load->view('reports/class_teachers_list', $data, TRUE);

                //Load MPDF From Library
                $this->load->library('mmpdf');
                $mmpdf = $this->mmpdf->load();
                $mmpdf->SetHTMLHeader("");

                $mmpdf->SetFooter("");
                $mmpdf->WriteHTML($htmldata);

                    $mmpdf->Output("Class Teachers List".$year.".pdf", 'I');

            } else {
                $this->load->view('admin/accessDeniedPage');
            }
            //outer else
        } else {
            redirect('login/index');
        }
    }

    public function allTeachersList() {
        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*"; //get teacher info
                $whereArr = array("user_id" => $username);
                $data['userData'] = $this->Generic_model->getData($fields, 'admins', $whereArr);
                
                    $now = new DateTime();//Foreach to add classes 
                    $date = $now->format("Y-m-d");

                    $where = array("status" => 0);
                    $results = $this->Generic_model->getData('*', 'teacher', $where);
                    $data['teachers'] = $results;
                    $count = count($results);
                    $data['results_count'] = $count;
//                       var_dump($data);die;

                    $htmldata = $this->load->view('reports/teachers_list', $data, TRUE);

                    //Load MPDF From Library
                    $this->load->library('mmpdf');
                    $mmpdf = $this->mmpdf->load();
                    $mmpdf->SetHTMLHeader("");

                    $mmpdf->SetFooter("");
                    $mmpdf->WriteHTML($htmldata);

                        $mmpdf->Output("Teachers Detail Report".$date.".pdf", 'I');
              
            } else {
                $this->load->view('admin/accessDeniedPage');
            }
            //outer else
        } else {
            redirect('login/index');
        }
    }

    public function TxnSummeryReport() {
        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*"; //get teacher info
                $whereArr = array("user_id" => $username);
                $data['userData'] = $this->Generic_model->getData($fields, 'admins', $whereArr);

                $date_range = $this->input->post("daterangep", TRUE);
//                var_dump($date_range);
                
                
                $start_date_s = substr($date_range, 0, 10);
                $start_date = date('Y-m-d', strtotime($start_date_s));
                $data['start_date']=$start_date;
                        
                $end_date_s = substr($date_range, 13, 25);
                $end_date = date('Y-m-d', strtotime($end_date_s));
                $data['end_date']=$end_date;

                $where = array("date <=" => $end_date, "date >=" => $start_date);
                $results = $this->Generic_model->getData('*', 'payment', $where);
                $data['results'] = $results;
                $count = count($results);
                $data['results_count'] = $count;
//                var_dump($data);die;

                $htmldata = $this->load->view('reports/txn_summery_report', $data, TRUE);

                //Load MPDF From Library
                $this->load->library('mmpdf');
                $mmpdf = $this->mmpdf->load();
//                $mmpdf->SetHTMLHeader("");
//                $mmpdf->SetFooter("");
                $mmpdf->WriteHTML($htmldata);

                    $mmpdf->Output("Transaction Summery Report".$start_date."To".$end_date.".pdf", 'I');

            } else {
                $this->load->view('admin/accessDeniedPage');
            }
            //outer else
        } else {
            redirect('login/index');
        }
    }

    
    public function monthlyFeeSummery() {
        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*"; //get teacher info
                $whereArr = array("user_id" => $username);
                $data['userData'] = $this->Generic_model->getData($fields, 'admins', $whereArr);

                $SId = $this->input->post("SId", TRUE);
                $yearM = $this->input->post("yearM", TRUE);
                
                $data['SId']=$SId;
                $data['yearM']=$yearM;
                
                $fields=array('child_id', 'last_name','first_name','middle_name');
                $where = array('child_id' => $SId);
                $data['name'] = $this->Generic_model->getData($fields,'child', $where);
                 
                $where = array("child_id"=>$SId,"year"=>$yearM,"p_type"=>'Monthly Fees');
                $data['results'] = $this->Generic_model->getData('*', 'payment', $where);

                $totalFee = $this->Generic_model->sum('payment_amount', array("child_id"=>$SId,"year"=>$yearM,"p_type"=>'Monthly Fees'), 'payment');
                $data['totalFee'] = $totalFee[0];
//                   var_dump($data);die;
             
                $htmldata = $this->load->view('reports/monthly_fee_summery_report', $data, TRUE);

                //Load MPDF From Library
                $this->load->library('mmpdf');
                $mmpdf = $this->mmpdf->load();
                $mmpdf->SetHTMLHeader("");
                $mmpdf->SetFooter("");
                $mmpdf->WriteHTML($htmldata);

                    $mmpdf->Output("Monthly Fee Summery Report".$SId."-".$yearM.".pdf", 'I');

            } else {
                $this->load->view('admin/accessDeniedPage');
            }
            //outer else
        } else {
            redirect('login/index');
        }
    }
    
    public function registrationList() {
        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*"; //get teacher info
                $whereArr = array("user_id" => $username);
                $data['userData'] = $this->Generic_model->getData($fields, 'admins', $whereArr);

                $year = $this->input->post("yearCT", TRUE);
                $data['year'] = $year;
                        
                $fields=array("*");
                $wherefieldtablefrom = array('reg_year'=>$year);
                $tablefrom = 'registration';
                $tablejoin = 'child';
                $tablejoincondition = 'child.child_id = registration.child_id';
                $results =  $this->Generic_model->join($fields, $wherefieldtablefrom, $tablefrom, $tablejoin, $tablejoincondition);
                $data['results'] = $results;
                $count = count($results);
                $data['results_count'] = $count;
//                var_dump($data);die;
                
                $htmldata = $this->load->view('reports/registration_list', $data, TRUE);

                //Load MPDF From Library
                $this->load->library('mmpdf');
                $mmpdf = $this->mmpdf->load();
                $mmpdf->SetHTMLHeader("");

                $mmpdf->SetFooter("");
                $mmpdf->WriteHTML($htmldata);

                    $mmpdf->Output("Regiations Summery Report".$year.".pdf", 'I');

            } else {
                $this->load->view('admin/accessDeniedPage');
            }
            //outer else
        } else {
            redirect('login/index');
        }
    }
    
    public function lessonPlanReport() {
        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*"; //get teacher info
                $whereArr = array("user_id" => $username);
                $data['userData'] = $this->Generic_model->getData($fields, 'admins', $whereArr);

//                var_dump($_POST);DIE;
                $class = $this->input->post("class_name", TRUE);
                $yearM = $this->input->post("yearM", TRUE);
                $month = $this->input->post("month", TRUE);
                
                $data['class']=$class;
                $data['yearM']=$yearM;
                $data['month']=$month;
                                 
                $where = array('approval_status'=>'Approved','month'=>$month,'year'=>$yearM,'class_nm'=>$class,'status'=>0);
                $asc_field = 'date_range';
                $data['results'] = $this->Generic_model->getDataSortAsc('*', 'lesson_plan', $where,$asc_field);

                $htmldata = $this->load->view('reports/lesson_plan_report', $data, TRUE);

                //Load MPDF From Library
                $this->load->library('mmpdf');
                $mmpdf = $this->mmpdf->load();
                $mmpdf->SetHTMLHeader("");

                $mmpdf->SetFooter("");
                $mmpdf->WriteHTML($htmldata);

                    $mmpdf->Output("Lesson Plans for ".$class."-".$month.".pdf", 'I');

            } else {
                $this->load->view('admin/accessDeniedPage');
            }
            //outer else
        } else {
            redirect('login/index');
        }
    }
    public function progressReport() {
        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*"; //get teacher info
                $whereArr = array("user_id" => $username);
                $data['userData'] = $this->Generic_model->getData($fields, 'admins', $whereArr);

                $date_range = $this->input->post("daterangep", TRUE);
                $class = $this->input->post("monthly_class", TRUE);
                
              
                $start_date_s = substr($date_range, 0, 10);
                $start_date = date('Y-m-d', strtotime($start_date_s));
                        
                $end_date_s = substr($date_range, 13, 25);
                $end_date = date('Y-m-d', strtotime($end_date_s));
                                
                $student = $this->input->post("child_id_monthly", TRUE);
                list($c_id,$cname)=explode(":",$student);
                
                $data['class']=$class;
                $data['date_range']=$date_range;
                $data['cname']=$cname;
                
//                $where = array("e_date <=" => $end_date, "e_date >=" => $start_date, "child_id" => $c_id,"class_nm" =>$class,"status"=>0);
//                $results = $this->Generic_model->getData('*', 'marks', $where);
//                $data['results'] = $results;
//                $count = count($results);
//                $data['results_count'] = $count;
                
                $where = array("e_date <=" => $end_date, "e_date >=" => $start_date, "child_id" => $c_id,"class_nm" =>$class,"status"=>0);
                $groupfield='sub_name';
                $orderfield='e_date';        
                $results = $this->Generic_model->getDataGroupAsc('*', 'marks', $where,$groupfield,$orderfield);
                $data['results2'] = $results;
//                var_dump($data);die;

                $htmldata = $this->load->view('reports/student_progress_report', $data, TRUE);

                //Load MPDF From Library
                $this->load->library('mmpdf');
                $mmpdf = $this->mmpdf->load();
                $mmpdf->SetHTMLHeader("");

                $mmpdf->SetFooter("");
                $mmpdf->WriteHTML($htmldata);

                    $mmpdf->Output("Progress Report".$cname.".pdf", 'I');

            } else {
                $this->load->view('admin/accessDeniedPage');
            }
            //outer else
        } else {
            redirect('login/index');
        }
    }
    
    
}
