<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class parentsController extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('Generic_model', '', TRUE);
        $this->load->model('system_model', '', TRUE);
        /*         * if (!$this->session->userdata("username")) {
          redirect(base_url() . "index.php/login");
          };* */
    }

    public function parentsDashboard() {

        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];
    
            // inner if
            if ($group_id === "30") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("child_id"=>$username);
                $data['studentData']=$this->Generic_model->getData($fields,'child',$whereArr);            
                //other your functional codes  

                $this->load->view('parentsView/parents_dashboard', $data);
            } else {
                $this->load->view('admin/accessDeniedPage');
            }

            //outer else
        } else {
            redirect('login/index');
        }
    }
   //////////////////////User Profile///////////////////////// 
    
    public function studentProfile() {
        
        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];


            // inner if
            if ($group_id === "30") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("child_id" => $username);
                $data['studentData']=$this->Generic_model->getData($fields,'child',$whereArr);   
//                var_dump($data); 
                
                $Child_ID=$username;
                
                $whereArr=array("Child_ID"=>$Child_ID);
                $result_s=$this->Generic_model->getData('*','child',$whereArr);
                $data['userDataStudent']=$result_s[0];

                 // setting up father details
                $fields = '*';
                $whereArr=array("child_id"=>$Child_ID,'relationship'=>'Father');
                $result_s=$this->Generic_model->getData($fields,'parent',$whereArr);
                $data['father']=$result_s[0];

                // setting up mother details
                $fields = '*';
                $whereArr=array("child_id"=>$Child_ID,'relationship'=>'Mother');
                $result_s=$this->Generic_model->getData($fields,'parent',$whereArr);
                $data['mother']=$result_s[0];

                // setting up mother details
                $fields = '*';
                $whereArr=array("child_id"=>$Child_ID,'relationship'=>'Guardian');
                $result_s=$this->Generic_model->getData($fields,'parent',$whereArr);
                $data['guardian']=$result_s[0];
                
//               var_dump($data);
                $this->load->view('parentsView/studentProfile',$data);
                
            } else {
                $this->load->view('admin/accessDeniedPage');
            }

            //outer else
        } else {
            redirect('login/index');
        }
      }
    
    //////////////////////////////////////////EVENTS/////////////////////////////////////////////
     
     public function showEventsT() {

        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];


            // inner if
            if ($group_id === "30") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("child_id" => $username);
                $data['studentData']=$this->Generic_model->getData($fields,'child',$whereArr);           
                
                
                $now = new DateTime();
                $today = $now->format("Y-m-d");
                
                    
                  $fields = "*";//get events
                    $where=array("status" => 0,"target_group <>"=>'TEACHERS ONLY',"e_date >=" => $today);
                    $asc_field = 'e_date';
                   $result['all']=$this->Generic_model->getDataSortAsc($fields,'events',$where,$asc_field); 

                   if(count($result)>0){
                    $record = array("record" =>$result, "recd"=> 'YES');
                    echo json_encode($record);
                    die;
//                                              var_dump($record);die;
                }else{
                    $record = array("recd"=> 'NONO');
                    echo json_encode($record);
                }

            } else {
                $this->load->view('admin/accessDeniedPage');
            }

            //outer else
        } else {
            redirect('login/index');
        }
    }
     
     public function parentsEvents() {

        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];


            // inner if
            if ($group_id === "30") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("child_id" => $username);
                $data['studentData']=$this->Generic_model->getData($fields,'child',$whereArr);             
                
                $fields = "*";//get all events 
                $where=array("status" => 0,"target_group <>"=>'TEACHERS ONLY');
                $asc_field = 'e_date';
                $data['AllEvents']=$this->Generic_model->getDataSortAsc($fields,'events',$where,$asc_field);
               
                $this->load->view('parentsView/parents_events',$data);

            } else {
                $this->load->view('admin/accessDeniedPage');
            }

            //outer else
        } else {
            redirect('login/index');
        }
    }
     
     public function stdnSubejctList() {
     if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "30") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("child_id" => $username);
                $data['studentData']=$this->Generic_model->getData($fields,'child',$whereArr);              
               
                            $data['child_id']=$username;
                
                            $fields = 'class_name';//get the class
                            $whereArr = array("child_id" =>$username);
                            $class_name=$this->Generic_model->getData($fields,'registration',$whereArr);

                            $fields = array('sub_name','t_name','class_name','teacher_id');//get the subjects
                            $whereArr = array("class_name" =>$class_name[0]->class_name,"status"=>0);
                            $data['subjects']=$this->Generic_model->getData($fields,'subject_teacher',$whereArr);
//                            var_dump($data);
                            $this->load->view('parentsView/evalStdntSubjectList',$data); 
				
			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
                    //outer else
                    } else {
                            redirect('login/index');
                    }
        }
    
    
    public function evalStudentActSumery($idp) {
     if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "30") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("child_id" => $username);
                $data['studentData']=$this->Generic_model->getData($fields,'child',$whereArr);              
               
                
                $id = utf8_decode(urldecode($idp));
//                var_dump($id);
                list($sub_name,$teacher_id,$t_name,$class_name,$child_id)= explode(":",$id);
                        
                        $data['sub_name']=$sub_name;
                        $data['t_name']=$t_name;
                        $data['class_name']=$class_name;
                        $data['child_id']=$child_id;
                        
                        $fields=array("first_name","last_name",);
                        $whereArr = array('child_id'=>$child_id);
                        $data['student_name']=$this->Generic_model->getData($fields,'child',$whereArr);
              
//                        var_dump($data);
                       $fields = array( 'score','activity_name','comment','level','e_date');//get activity data load to form
                       $whereArr = array("teacher_id" =>$teacher_id,'sub_name'=>$sub_name,'child_id'=>$child_id);
                       $data['student_marks_table']=$this->Generic_model->getData($fields,'marks',$whereArr);
                      
				 $this->load->view('parentsView/evalStudentActivitySummery',$data); 
				
			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
                    //outer else
                    } else {
                            redirect('login/index');
                    }

     
     }
    
    
     
        }

