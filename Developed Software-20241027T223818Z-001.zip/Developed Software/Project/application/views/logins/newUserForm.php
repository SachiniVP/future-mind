<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!--> <html lang="en"> <!--<![endif]-->

<!-- BEGIN HEAD -->
<head>
     <meta charset="UTF-8" />
    <title> New User's Page</title>
      
    <link href="<?php echo base_url(); ?>assets/jquery-validation-1.15.0/demo/css/screen.css" rel="stylesheet" type="text/css"/>  
      <?php echo $this->load->view('admin_panel/template/header'); ?>
        
    <style>
         body {
                background-image:url('<?php echo base_url('assets/imgs/login.jpg')?>');
                 background-repeat:no-repeat;
                 background-size:cover }
     </style>    
</head>
    <!-- END HEAD -->

    <!-- BEGIN BODY -->
<body >

   <!-- PAGE CONTENT --> 
   <div class="container">
         
       <div class="col-md-12" style="height:50px;"></div> <!--space between menu and label-->
       
       
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
                <div class="login-panel panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Create Login Password</h3>
                    </div>
                    <div class="panel-body">
                        <form name="formNewUser" id="formNewUser" action="<?php echo base_url() .'' ?>" method="post">
                            <fieldset>
                                <label id="white" class="hide" style="color:red;">Remove space from your Password</label>
                                <label id="temp" class="hide" style="color:red;">Please check your Temporary Password</label>
                                <label id="unmatch" class="hide" style="color:red;">New password and Confirm Password not Match</label>
                                <label id="success" class="hide" style="color:blue;">You Have Successfully Created the Login!!</label>
                                <div class="form-group">
                                    <input class="form-control" placeholder="UserName" name="username" id="username" type="text" autofocus  required="true" />
                                    
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Tempary Password" name="temp_password" id="temp_password" type="password" value="" required="true" minlength="8"/>
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="New Password" name="password" id="password" type="password" value="" required="true" minlength="8"/>
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Confirm Password" name="password2" id="password2" type="password" value="" required="true" minlength="8"/>
                                </div>

  <!--%$^%$^REMOVE <A> IN LOGIN--><button type="submit" name="btnSubmit" id="btnSubmit" class="btn btn-success" style="width:100%">Submit</button>
                                <!--<button type="button" name="btnSubmit" id="btnSubmit" class="btn btn-warning" style="width:49%">Register!</button>-->
                                <br/>
                                <br/>
                                <a href="<?php echo base_url(); ?>index.php/login/index" style="color:blueviolet;align:text-center">Back to Login</a>
                                
                                <div class="row">
                                <div class="span6">
                                    <div class="" id="alertMsg"></div>
                                </div>
                            </div>
                            
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>


	  <!--END PAGE CONTENT -->     
      <!-- PAGE LEVEL SCRIPTS -->
            <!-- GLOBAL SCRIPTS -->
            <script src="<?=base_url();?>assets/jquery-2.2.4.js"></script>
            <!--<script src="<?=base_url();?>assets/jquery-3.0.0"></script>-->
            <script src="<?=base_url();?>assets/admin_assets/plugins/bootstrap/js/bootstrap.min.js"></script>
            <script src="<?=base_url();?>assets/admin_assets/plugins/modernizr-2.6.2-respond-1.1.0.min.js"></script>
            <!-- END GLOBAL SCRIPTS -->
            <!--<script src="<?=base_url();?>assets/jquery-ui.js" type="text/javascript"></script>-->
       <!--END PAGE LEVEL SCRIPTS -->
       
     
       <!-- Validation files-->
            <script src="<?=base_url();?>assets/jquery-validation-1.15.0/lib/jquery.mockjax.js"></script>
            <script src="<?=base_url();?>assets/jquery-validation-1.15.0/dist/jquery.validate.js"></script>
            <script src="<?=base_url();?>assets/jquery-validation-1.15.0/dist/additional-methods.js"></script>
            <!-- Validation files--> 

       <!-- Form Validation : -->
        <script>
            $(document).ready(function () {

                $("#formNewUser").validate({
                    rules: {
                        username: {
                            required: true,
                             remote: {
                                url: "http://localhost:8080/Project/index.php/reset_password/checkNewUsername",
                                type: "post",
                                async: true,
                            }
                        },
                            password:{
                                required: true,minlength: "8"
                            },
                            password2:{
                               required: true,minlength: "8"
                            }
                    },
                    messages: {
                        username: {
                            required: "This field is required",
                            remote: "Invalid User Name"
                        }
                    }
                });
            });
        </script>

             <script>
            $(document).ready(function () {
                baseurl = "http://localhost:8080/Project/";
                $("#formNewUser").submit(function (e) {
                    e.preventDefault();
//                    $('#change_classT').modal('hide');
                    var jqXHR = $.ajax({
                        type: "POST",
                        url: baseurl + "index.php/reset_password/newUserPassword",
                        data: $("#formNewUser").serialize(),
                        dataType: 'json',
                        success: function (data) {
//                            console.log(data);
                            if (data.record==="DONE") {
                                $("#success").removeAttr("class", "hide");
                                $("#success").fadeIn(1500);
                                $("#success").delay(2500).fadeOut(1500);
                                setTimeout(function () {
                                    location = baseurl + "index.php/Login/";
                                }, 4000);
                            }
                            else if (data.record === "NOTMATCH") {
                                $("#unmatch").removeAttr("class", "hide");
                                $("#unmatch").fadeIn(1500);
                                $("#unmatch").delay(2500).fadeOut(1500);
                                }
                            else if (data.record === "WHITE") {
                                $("#white").removeAttr("class", "hide");
                                $("#white").fadeIn(1500);
                                $("#white").delay(2500).fadeOut(1500);
                                } 
                            else if (data.record === "TEMP") {
                                $("#temp").removeAttr("class", "hide");
                                $("#temp").fadeIn(1500);
                                $("#temp").delay(2500).fadeOut(1500);
                                }    
                        }
                    });
                });
            });
        </script>
       
       
</body>
    <!-- END BODY -->
</html>
