
<!DOCTYPE html>

 <!-- BEGIN HEAD -->
<head>
    <title>Access Denied Page</title>
    <?php echo $this->load->view('admin_panel/template/header'); ?>
  </head>
     <!-- END HEAD -->

     <!-- BEGIN BODY -->
<body >
     <!--  PAGE CONTENT --> 
 <div class="container">
        <div class="col-lg-8 col-lg-offset-2 text-center">
	  <div class="logo">
	    <h1>ACCESS DENIED!</h1>
          </div>
          <p class="lead text-muted">Oops, an error has occurred. Not allowed!</p>
          <div class="clearfix"></div>
          <div class="clearfix"></div>
            <br />
                <div class="col-lg-6  col-lg-offset-3">
		  <div class="btn-group btn-group-justified">
		      <a href="index.html" class="btn btn-primary">Return Dashboard</a>
                      <a href="index.html" class="btn btn-success">Return Website</a>
		  </div>
                        
                </div>
        </div>
                       
                
        </div>
     <!-- END  PAGE CONTENT --> 

</body>
     <!-- END BODY -->
</html>
