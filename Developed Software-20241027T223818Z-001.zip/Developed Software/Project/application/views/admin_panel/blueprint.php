
<!DOCTYPE html>
<!--Administrator Dashboard-->

   
<!-- BEGIN HEAD-->
<head>
       
    <title>Dashboard</title>
    <?php echo $this->load->view('admin_panel/template/header'); ?>
</head>
<!-- END  HEAD-->    
   
    
    <!-- BEGIN BODY-->
<body class="padTop53" >

     <!-- MAIN WRAPPER -->
    <div id="wrap" style="background-color:#b8b8b8;">
        <!--HEADER SECTION -->
         <?php echo $this->load->view('admin_panel/template/navbar'); ?>
        <!-- END HEADER SECTION -->
        


        <!-- MENU SECTION -->
          <?php echo $this->load->view('admin_panel/template/menubar'); ?>
        <!--END MENU SECTION -->


        <!--PAGE CONTENT -->
        <div id="content" >

            <div class="inner" style="min-height:1200px;background-color:#b8b8b8;">
                <!---breadcrumb--->
                <div class="row">
                    <div class="col-md-12">
                        <div class="col-lg-12">
                            <div class="well-sm">
                                <ul class="breadcrumb" style="background-color:#cccccc">
                                    <li class="#"> Dashboard</li>
                                </ul>
                            </div>
                        </div> <!-- /.col-lg-12 --> 
                    </div> <!-- /.col-md-12 -->
                </div><!-- /.row -->
                <!---END breadcrumb--->
                
              
                
                            
                

            </div>




        </div>
       <!--END PAGE CONTENT -->
       
       

    </div>
     <!--END MAIN WRAPPER -->




</body>
    <!-- END BODY-->
<?php echo $this->load->view('admin_panel/template/footer'); ?>    
</html>

