
<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!--> <html lang="en"> <!--<![endif]-->

    
    
<!-- BEGIN HEAD-->
<head>
       
    <title>BCORE Admin Dashboard Template | Blank Page</title>
    <?php echo $this->load->view('admin_panel/template/header'); ?>
</head>
<!-- END  HEAD-->    
   
    
    <!-- BEGIN BODY-->
<body class="padTop53 " >

     <!-- MAIN WRAPPER -->
    <div id="wrap">
        <!--HEADER SECTION -->
         <?php echo $this->load->view('admin_panel/template/navbar'); ?>
        <!-- END HEADER SECTION -->
        


        <!-- MENU SECTION -->
          <?php echo $this->load->view('admin_panel/template/menubar'); ?>
        <!--END MENU SECTION -->


        <!--PAGE CONTENT -->
        <div id="content">

            <div class="inner" style="min-height:1200px;">
                <div class="row">
                    <div class="col-lg-12">


                        <h2>Blank Page Two</h2>



                    </div>
                </div>

                <hr />




            </div>




        </div>
       <!--END PAGE CONTENT -->
       
       <!-- RIGHT STRIP  SECTION -->
        <div id="right">
         
            <div class="well well-small">
                Calender
            </div>
            <div class="well well-small">
                <div>Upcoming Event 1</div>
                <div>Upcoming Event 2</div>
                <div>Upcoming Event 3</div>
            </div>
          
        </div>
         <!-- END RIGHT STRIP  SECTION -->

    </div>
     <!--END MAIN WRAPPER -->


</body>
    <!-- END BODY-->
<?php echo $this->load->view('admin_panel/template/footer'); ?>    
</html>

