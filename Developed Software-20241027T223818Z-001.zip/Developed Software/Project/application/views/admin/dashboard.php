
<!DOCTYPE html>
<!--Administrator Dashboard-->

<html>   
<!-- BEGIN HEAD-->
<head>
       
    <title>Dashboard</title>
    <?php echo $this->load->view('admin_panel/template/header'); ?>
    <!-- PAGE LEVEL STYLES -->
    <link href="<?=base_url();?>assets/admin_assets/css/layout2.css" rel="stylesheet" />
    <!-- END PAGE LEVEL  STYLES -->
    
    
</head>
<!-- END  HEAD-->    
   
    
    <!-- BEGIN BODY-->
<body class="padTop53" >

     <!-- MAIN WRAPPER -->
    <div id="wrap" style="background-image: url('http://localhost:8080/Project/assets/imgs/bgptn.png'); background-repeat: repeat;">
        <!--HEADER SECTION -->
         <?php echo $this->load->view('admin_panel/template/navbar'); ?>
        <!-- END HEADER SECTION -->
        


        <!-- MENU SECTION -->
          <?php echo $this->load->view('admin_panel/template/menubar'); ?>
        <!--END MENU SECTION -->


        <!--PAGE CONTENT -->
        <div id="content" >

            <div class="inner" style="min-height:1200px;background-color:transparent;">
                <!---breadcrumb--->
                <div class="row">
                    <div class="col-md-12">
                        <div class="col-lg-12">
                            <div class="well-sm">
                                <ul class="breadcrumb">
                                    <li class="#"> Dashboard</li>
                                </ul>
                            </div>
                        </div> <!-- /.col-lg-12 --> 
                    </div> <!-- /.col-md-12 -->
                </div><!-- /.row -->
                <!---END breadcrumb--->
                
                <div class="row" style="margin-top: 20px;">
                <div class="col-sm-4">
                    <div class="panel panel-info">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <img src="<?php echo base_url('assets/imgs/icons/i6.png')?>" alt="Personal Details" />
                                                                    
                                </div>
                            </div>
                        </div>
                        <a href="<?php echo base_url()."index.php/student/"?>">
                            <div class="panel-footer" style="font-weight: bold;" >
                                <span class="pull-left"  >Personal Details</span>
                                <span class="pull-right"><i class="fa icon-circle-arrow-right"></i></span>
                                <div class="clearfix" ></div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="panel panel-info">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                <img src="<?php echo base_url('assets/imgs/icons/i12.png')?>" alt="School Set Up" />    
                                </div>
                             </div>
                        </div>
                        <a href='<?php echo base_url()."index.php/setUp/"?>'>
                            <div class="panel-footer" style="font-weight: bold;" >
                                <span class="pull-left"  >School Settings</span>
                                <span class="pull-right"><i class="fa icon-circle-arrow-right"></i></span>
                                <div class="clearfix" ></div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="panel panel-info">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                 <img src="<?php echo base_url('assets/imgs/icons/i5.png')?>" alt="Admissions" />   
                                </div>
                            </div>
                        </div>
                        <a href="<?php echo base_url()."index.php/payments/admissionsRegistrations"?>">
                            <div class="panel-footer" style="font-weight: bold;" >
                                <span class="pull-left"> Registrations</span>
                                <span class="pull-right"><i class="fa icon-circle-arrow-right"></i></span>
                                <div class="clearfix" ></div>
                            </div>
                        </a>
                    </div>
                </div>
                               
                </div>
                
                            
                <div class="row">
                 
                    <div class="col-sm-4">
                    <div class="panel panel-info">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                 <img src="<?php echo base_url('assets/imgs/icons/i1.png')?>" alt="Fee Management" />   
                                </div>
                            </div>
                        </div>
                        <a href="<?php echo base_url()."index.php/payments/"?>">
                            <div class="panel-footer" style="font-weight: bold;" >
                                <span class="pull-left"  >Fee Management</span>
                                <span class="pull-right"><i class="fa icon-circle-arrow-right"></i></span>
                                <div class="clearfix" ></div>
                            </div>
                        </a>
                    </div>
                </div>   
                    
                <div class="col-sm-4">
                    <div class="panel panel-info">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <img src="<?php echo base_url('assets/imgs/icons/i3.png')?>" alt="Events" />
                                                                    
                                </div>
                            </div>
                        </div>
                        <a href="<?php echo base_url()."index.php/events/"?>">
                            <div class="panel-footer" style="font-weight: bold;" >
                                <span class="pull-left"  >Events/Notifications</span>
                                <span class="pull-right"><i class="fa icon-circle-arrow-right"></i></span>
                                <div class="clearfix" ></div>
                            </div>
                        </a>
                    </div>
                </div>
<!--                <div class="col-sm-3">
                    <div class="panel panel-info">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                <img src="<?php echo base_url('assets/imgs/icons/i9.png')?>" alt="Messages" />    
                                </div>
                             </div>
                        </div>
                        <a href='#'>
                            <div class="panel-footer" style="font-weight: bold;" >
                                <span class="pull-left"  >Messages</span>
                                <span class="pull-right"><i class="fa icon-circle-arrow-right"></i></span>
                                <div class="clearfix" ></div>
                            </div>
                        </a>
                    </div>
                </div>-->
                <div class="col-sm-4">
                    <div class="panel panel-info">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                 <img src="<?php echo base_url('assets/imgs/icons/i8.png')?>" alt="Users" />   
                                </div>
                            </div>
                        </div>
                        <a href="<?php echo base_url()."index.php/users/"?>">
                            <div class="panel-footer" style="font-weight: bold;" >
                                <span class="pull-left"  >Users</span>
                                <span class="pull-right"><i class="fa icon-circle-arrow-right"></i></span>
                                <div class="clearfix" ></div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-sm-3">
<!--                    <div class="panel panel-info">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                 <img src="<?php echo base_url('assets/imgs/icons/i14.png')?>" alt="Settings" />   
                                </div>
                            </div>
                        </div>
                        <a href="#">
                            <div class="panel-footer" style="font-weight: bold;" >
                                <span class="pull-left"  >Settings</span>
                                <span class="pull-right"><i class="fa icon-circle-arrow-right"></i></span>
                                <div class="clearfix" ></div>
                            </div>
                        </a>
                    </div>-->
                </div>
                
                </div>

            </div>




        </div>
       <!--END PAGE CONTENT -->
       
       <!-- RIGHT STRIP  SECTION -->
        <div id="right">
         
            <div class="well well-small" style="background-color: #007ea2;
                                                    font-family: helvetica;
                                                    font-weight: bold;
                                                    font-size: 20px;
                                                    color: #f5f5f5" >
                <div id="showdate"></div>
               
            </div>
            <div class="well well-xm" id="event_well" style="background-color: #a3d34a;overflow: auto; height:425px; width: 100%;">
                     <!--ajax append-->   
            </div>
          
        </div>
         <!-- END RIGHT STRIP  SECTION -->

    </div>
     <!--END MAIN WRAPPER -->
     <?php echo $this->load->view('admin_panel/template/footer'); ?> 
     
     <!--show date-->
                <script>
                var d = new Date();
                document.getElementById("showdate").innerHTML = d.toDateString();
                </script>

                <!--Load Events-->
                <script>
        $(document).ready(function () {
               baseurl = "http://localhost:8080/Project/";
               $.ajax({
                    url: baseurl + "index.php/events/showEvents",
                    dataType: 'json',
                    success: function (data) {
                        if (data.recd="YES") { 
                                $.each(data.record, function (i, obj) {// appr[vedlessonplans forclasses table append
                                          
                                        $(
                                                '<li>'+
                                                       '<a href="<?php echo base_url()."index.php/events/manageEvents"?>">'+
                                                            '<strong>'+obj.header+'</strong>'+
                                                                '<span class="pull-right text-muted">'+
                                                                    '<em>'+obj.e_date+'</em>'+
                                                                '</span>'+
                                                           '</a>'+
                                                    '</li>'+
                                                    '<hr>'
                                                ).appendTo("#event_well").fadeIn("slow");

                                   });
                        }
                       else {} 
                    }
                });
            
        });</script>



</body>
    <!-- END BODY-->
   
</html>

