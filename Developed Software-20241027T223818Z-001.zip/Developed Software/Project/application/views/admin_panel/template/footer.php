   <!-- FOOTER -->
    <div id="footer">
        <p>&copy; SPathirana &nbsp;2016 &nbsp;</p>
    </div>
    <!--END FOOTER -->
     <!-- GLOBAL SCRIPTS -->
    <script src="<?=base_url();?>assets/admin_assets/plugins/jquery-2.0.3.min.js"></script>
     <!--<script src="<?=base_url();?>assets/jquery-3.0.0"></script>-->
     <script src="<?=base_url();?>assets/admin_assets/plugins/bootstrap/js/bootstrap.min.js"></script>
    <script src="<?=base_url();?>assets/admin_assets/plugins/modernizr-2.6.2-respond-1.1.0.min.js"></script> <!--this is also for validatuion-->
    <!-- END GLOBAL SCRIPTS -->
    
    