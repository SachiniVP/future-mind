
<!DOCTYPE html>
<!--Administrator Dashboard-->

   
<!-- BEGIN HEAD-->
<head>
       
    <title>Events and Notifications</title>
    <?php echo $this->load->view('admin_panel/template/header'); ?>
    <!-- PAGE LEVEL STYLES -->
    <link href="<?=base_url();?>assets/admin_assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
    <!-- END PAGE LEVEL  STYLES -->
</head>
<!-- END  HEAD-->    
   
    
    <!-- BEGIN BODY-->
<body class="padTop53" >

     <!-- MAIN WRAPPER -->
    <div id="wrap" style="background-color:#b8b8b8;">
        <!--HEADER SECTION -->
         <?php echo $this->load->view('admin_panel/template/navbar'); ?>
        <!-- END HEADER SECTION -->
        


        <!-- MENU SECTION -->
          <?php echo $this->load->view('parentsView/parents_menubar'); ?>
        <!--END MENU SECTION -->


        <!--PAGE CONTENT -->
        <div id="content" >
            
            <div class="inner" style="min-height:1200px;background-color:transparent">
                <!---breadcrumb--->
                <div class="row">
                    <div class="col-md-12">
                        <div class="col-lg-12">
                            <div class="well-sm">
                                <div style="">
                                    <ul class="breadcrumb"  >
                                     <li> <a href="<?php echo base_url()."index.php/parentsController/parentsDashboard"?>"> Dashboard </a> </li>
                                    <li class="active"> Events & Notifications </li>
                                     </ul>
                                </div>    
                            </div>
                        </div> <!-- /.col-lg-12 --> 
                    </div> <!-- /.col-md-12 -->
                </div><!-- /.row -->
                <!---END breadcrumb--->
                
                
                
                
                <div class="well col-lg-12" style=" background-color: transparent;"> 
                  <div class="row"><!--Class Teacher DataTable--> 
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"> 
                        <div container='fluid'> 
                            <div class="well well-lg">
                                <div class="panel-body"> <!--DataTable-->
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered table-hover" id="dataTables-example" class="display" cellspacing="0" width="100%"> 
                                            <thead>
                                                <tr>
                                                    <th>Header</th>
                                                    <th>Description</th>
                                                    <th>Target</th>
                                                    <!--<th>Added By</th>-->
                                                    <th>Event Date</th>
                                                    
                                                </tr>
                                            </thead>
                                            <tbody center>
                                                <?php
                                                foreach ($AllEvents as $userItem) {
                                                    echo "<tr>";
                                                    echo "<td>" . $userItem->header . "</td>";
                                                    echo "<td>" . $userItem->description . "</td>";
                                                    echo "<td>" . $userItem->target_group . "</td>";
//                                                    echo "<td>" . $userItem->added_by . "</td>";
                                                    echo "<td>" . $userItem->e_date . "</td>";
                                                    }
                                                ?>  
                                            </tbody>
                                        </table>
                                    </div>
                                </div><!--Data TAble-->                          
                            </div>
                        </div> 
                    </div>
                </div><!--Class Teacher DataTable--><!-- END Class Teacher-->
                </div> 
              
            </div>
                         
              
                     
            </div><!--END PAGE CONTENT -->
            
            
            <!-- Edit User Detail Form Modal  -->
                <div id="editUserDetailsModal" data-backdrop="static" data-keyboard="false" class="modal fade" role="dialog" aria-labelledby="gridSystemModalLabel">
                    <div class="modal-dialog modal-lg" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                <h4 class="modal-title" id="gridSystemModalLabel">Edit Event</h4>
                            </div>
                            <form  id="editUserForm" class="form-horizontal" method="POST" action="#">
                
                        <div class="modal-body">
                                    <div class="row" style="margin-bottom: 5%;">
                                        <div class="col-lg-12 col-md-12 col-sm-12">
                                            <div class="container-fluid">
                                                <div class="row">
                                                    <div class="col col-md-6 col-sm-6 hide" id="divmessage_edsubf">
                                                        <div style=" width: 100%; padding: 10px;" id="spnmessage_edsubf" class="alert alert-success" role="alert">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>     
                                    
                                    <div class="col-lg-3 col-md-3 col-sm-3 hide">
                                                <div class="form-group">
                                                    <input type="text" class="form-control" id="log_id" name="log_id" value="" />
                                                </div>
                                            </div>
                                            
                                    <div class='row'>
                                    <div class='col-sm-4'> 
                                            <label  class="control-label"> Header</label>
                                    </div>
                                    <div class='col-sm-8'>
                                        <div class='form-group'>
                                            <input type="text" id="header" name="header" class="form-control" required=""/>
                                        </div>
                                    </div>
                                     </div>
                                    <div class='row'>
                                    <div class='col-sm-4'> 
                                            <label  class="control-label"> Description</label>
                                    </div>
                                   
                                    <div class='col-sm-8'>
                                            <div class='form-group'>
                                                <textarea id="des" name="des" rows="5" cols="10" class="form-control" required=""></textarea>
                                    </div>
                                  </div>
                                    <div class='row'>
                                    <div class='col-sm-4'> 
                                            <label  class="control-label"> Target Group </label>
                                    </div>
                                    <div class='col-sm-5'>
                                         <select class="form-control" id="target_group" name="target_group" required="">
                                                    <option value="">-- Select--</option>
                                                     <option value="1">ALL</option>   
                                                      <option value="2">TEACHERS ONLY</option>   
                                                      <option value="3">PARENTS ONLY</option> 
                                         </select>
                                     </div>
                                    </div></br>
                                    </div>
                                <div class="modal-footer">
                                    <button id="" type="submit" class="hpj btn btn-primary">Update</button>
                                    <button id="cls" type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                </div><!-- /. modal-footer -->
                            </form>
                        </div><!-- /.modal-content -->
                    </div><!-- /.modal-dialog -->
                </div><!-- /.modal -->
                </div>  <!--/. Edit Assign Subject Modal -->
         </div><!--END MAIN WRAPPER -->
    
    
            <!-- PAGE LEVEL SCRIPTS -->
                <?php echo $this->load->view('admin_panel/template/footer'); ?>
            
                 
            <script src="<?=base_url();?>assets/admin_assets/plugins/dataTables/jquery.dataTables.js"></script>
            <script src="<?=base_url();?>assets/admin_assets/plugins/dataTables/dataTables.bootstrap.js"></script>
            <script>
                 $(document).ready(function () {
                     $('#dataTables-example').dataTable();
                 });
            </script>    
            
    
</body> 
<!-- END BODY-->
   
 
</html>

