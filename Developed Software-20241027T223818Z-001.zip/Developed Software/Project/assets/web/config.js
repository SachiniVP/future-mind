baseurl = "http://localhost/CI_CSS_JS/";
