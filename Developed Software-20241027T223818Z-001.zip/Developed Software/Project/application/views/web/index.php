
<!DOCTYPE html>
<html lang="en">

<head>
   
    <title>Home</title>

    <?php echo $this->load->view('web/template-web/web-header'); ?>

     <!-- jQuery -->
     <script src="<?php echo base_url() . "assets/admin-js/jquery.js" ?>"></script>
     <!-- Bootstrap Core JavaScript -->
     <script src="<?php echo base_url() . "assets/admin-js/bootstrap.min.js" ?>"></script>
     <!-- jQueryUI -->
     <script src="<?php echo base_url() . "assets/admin-js/jquery-ui.js" ?>"></script>
     <script src="<?php echo base_url() . "assets/js/config.js" ?>"></script>
     <!-- Script to Activate slider -->
     
     
     <style>
         body {
                 background-image:url('<?php echo base_url('assets/imgs/bg1.jpg')?>');
                 
                 background-size:cover }
     </style> 
     
    
</head>
<body>
    <div class="container-fluid">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">       
    <?php echo $this->load->view('web/template-web/nav-bar'); ?>
      </div>
        
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="margin-top:7%">  
          
          
          
          <!-- Insert to your webpage where you want to display the slider -->
    <div id="amazingslider-wrapper-1" style="display:block;position:relative;max-width:700px;padding-left:0px; padding-right:250px;margin:0px auto 0px;">
        <div id="amazingslider-1" style="display:block;position:relative;margin:0 auto;">
            <ul class="amazingslider-slides" style="display:none;">
                <li><img src="assets/slider/images/s1.jpg" alt="" />
                </li>
                <li><img src="assets/slider/images/s2.jpg" alt="" />
                </li>
                <li><img src="assets/slider/images/s3.jpg" alt="" />
                </li>
                <li><img src="assets/slider/images/s4.jpg" alt="" />
                </li>
                <li><img src="assets/slider/images/s5.jpg" alt="" />
                </li>
                <li><img src="assets/slider/images/s6.jpg" alt="" />
                </li>
                <li><img src="assets/slider/images/s7.jpg" alt="" />
                </li>
            </ul>
            <ul class="amazingslider-thumbnails" style="display:none;">
                <li><img src="assets/slider/images/s1-tn.jpg" alt="s1" /></li>
                <li><img src="assets/slider/images/s2-tn.jpg" alt="s2" /></li>
                <li><img src="assets/slider/images/s3-tn.jpg" alt="s3" /></li>
                <li><img src="assets/slider/images/s4-tn.jpg" alt="s4" /></li>
                <li><img src="assets/slider/images/s5-tn.jpg" alt="s5" /></li>
                <li><img src="assets/slider/images/s6-tn.jpg" alt="s6" /></li>
                <li><img src="assets/slider/images/s7-tn.jpg" alt="s7" /></li>
            </ul>
       
        </div>
    </div>
    <!-- End of body section HTML codes -->
         <hr>
        </div>
        <hr>
       
        
        <div class="container"> 
             <div class='row'>
                <div class='col-sm-2'> 
                   Like Us on
                   <br/>and Stay Connected
                </div>
                <div class='col-sm-2'> 
                   <a href="https://www.facebook.com/FutureMindsMontessoriSchool"><i class="fa fa-facebook-square fa-2x"></i></a>   
                </div> 
                <div class='col-sm-4'>
                    <p>
                   Future MINDS (AMI) Montessori School <br/>No.15,School Lane<br/>Rahula Road<br/>Matara<br/>
                     </p>
                </div>                  
               
                <div class='col-sm-4'> 
                <!--<p><i class="fa fa-phone"></i>      : (+94) 41-2225243</p>-->
                <p><i class="fa fa-mobile"></i>     : (+94) 71-8359158</p>
                <p><i class="fa fa-envelope-o"></i> : <a href="mailto:iebdacedamymatara@yahoo.com">iebdacedamymatara@yahoo.com</a></p>
                <p><i class="fa fa-clock-o"></i> : Monday - Friday: 7:00 AM to 6:00 PM</p> 
                </div>      
            
        </div> 
        
        
        <div class="col-lg-12">
    <?php echo $this->load->view('web/template-web/web-footer'); ?>
    </div>
    </div>
</div>        
</body>

</html>




