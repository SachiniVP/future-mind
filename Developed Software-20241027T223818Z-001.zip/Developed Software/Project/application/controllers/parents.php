<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class parents extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('Generic_model', '', TRUE);
        /**if (!$this->session->userdata("username")) {
            redirect(base_url() . "index.php/login");
        };**/
        
    }
    
    
    public function index() {
    if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
			        $allPID=$this->Generic_model->getData("parent_id",'parent');
				 //     $notBlankPID= $allPID['parent_id'][0] ;
				 //   var_dump($allPID);
				 //   var_dump($allPID['parent_id'][0]);die;
					
					$fields = array(       //data table
						"child_id", 
						"parent_id",
						"p_name",
						"relationship",
						"p_occupation",
						"p_email",
						"p_tel_no",
									  );
					$whereArr=array("p_status" => 0);
					$parents=$this->Generic_model->getData($fields,'parent',$whereArr); //public function getData($fieldset, $tableName, $where = '')
					$data['studentData']=array_filter($parents, function($v) {
							return $v->parent_id!='';
						});
			//            $data['studentData']=array_filter($arr, function($v, $k) {
			//    return $k == 'b' || $v == 4;
			//}, ARRAY_FILTER_USE_BOTH);
			//           var_dump($data['studentData']);die; 
					$this->load->view('admin/parents/index',$data);
			
			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
   //outer else
	} else {
		redirect('login/index');
	}
    }
    
    
    public function viewParent() {
        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
			   $childID=$this->input->get('childID');
			$parentID=$this->input->get('parentID');
		//  var_dump($childID);
				$fields = array(       //data table
					"child_id", 
					"first_name",
					"middle_name",
					"last_name",
					"home_add_l1",
					"home_add_l2",
					"home_add_l3",
					"child_tel_no",
					 );
			   $whereArr=array("child_id"=>$childID);
			   $result_s=$this->Generic_model->getData($fields,'child',$whereArr);
			   $data['Child']=$result_s[0];
		//      var_dump($data['Child']);

			   $fields = '*';
			   $whereArr=array("child_id"=>$childID,'parent_id'=>$parentID);
			   $result_s=$this->Generic_model->getData($fields,'parent',$whereArr);
			   $data['father']=$result_s[0];
		//      var_dump($data['father']);
			   
			 $this->load->view('admin/parents/viewParentForm',$data); 
			
			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
   //outer else
	} else {
		redirect('login/index');
	}  
    }
    
        public function editParentForm() {
        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
			   $childID=$this->input->get('childID');
				$parentID=$this->input->get('parentID');
		//  var_dump($childID);
				$fields = array(       //data table
					"child_id", 
					"first_name",
					"middle_name",
					"last_name",
					"home_add_l1",
					"home_add_l2",
					"home_add_l3",
					"child_tel_no",
					 );
			   $whereArr=array("child_id"=>$childID);
			   $result_s=$this->Generic_model->getData($fields,'child',$whereArr);
			   $data['Child']=$result_s[0];
		//      var_dump($data['Child']);

			   $fields = '*';
			   $whereArr=array("child_id"=>$childID,'parent_id'=>$parentID);
			   $result_s=$this->Generic_model->getData($fields,'parent',$whereArr);
			   $data['father']=$result_s[0];
		//      var_dump($data['father']);
			   
			 $this->load->view('admin/parents/editParentForm',$data);
			
			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
   //outer else
	} else {
		redirect('login/index');
	}   
    }
    
    public function editParent() {
          if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
			     $Child_ID = $this->input->post("st_id",TRUE);
            
				$parentid = $this->input->post("nic",TRUE);
				$title = $this->input->post("title",TRUE);
				$p_name = $this->input->post("name",TRUE);
				$p_occupation = $this->input->post("job",TRUE);
				$p_employer = $this->input->post("employer",TRUE);
				$p_tel_no= $this->input->post("p_tel",TRUE);
				$p_email = $this->input->post("email",TRUE);
				$p_add_l1 = $this->input->post("add_L1",TRUE);
				$p_add_l2 = $this->input->post("add_L2",TRUE);
				$p_add_l3 = $this->input->post("add_L3",TRUE);
					 
		  //Update parent table
			$dataArrF = array(
				"title" => $title,
				"p_name" => $p_name,
				"p_occupation" => $p_occupation,
				"p_employer" => $p_employer,
				"p_tel_no" => $p_tel_no,
				"p_email" => $p_email,
				"p_add_l1" => $p_add_l1,
				"p_add_l2" => $p_add_l2,
				"p_add_l3" => $p_add_l3,);
		 $whereArr=array("Child_ID" => $Child_ID,'parent_id'=>$parentid);
		  $this->Generic_model->updateData("parent",$dataArrF,$whereArr);
		 // var_dump($dataArrF);
		  
		  redirect(base_url() . "index.php/parents/");
			
			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
   //outer else
	} else {
		redirect('login/index');
	}
    }
}


