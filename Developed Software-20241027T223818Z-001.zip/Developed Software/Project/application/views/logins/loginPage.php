<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!--> <html lang="en"> <!--<![endif]-->

<!-- BEGIN HEAD -->
<head>
     <meta charset="UTF-8" />
    <title> Login Page</title>
       <?php // echo $this->load->view('web/template-web/web-header'); ?> 
      <?php echo $this->load->view('admin_panel/template/header'); ?>

    <style>
         body {
                background-image:url('<?php echo base_url('assets/imgs/login.jpg')?>');
                 background-repeat:no-repeat;
                 background-size:cover }
     </style>    
</head>
    <!-- END HEAD -->

    <!-- BEGIN BODY -->
<body >
     <?php // echo $this->load->view('web/template-web/nav-bar'); ?>
   <!-- PAGE CONTENT --> 
   <div class="container">
         
             <div class="col-md-12" style="height:50px;"><a href="<?php echo base_url()?>"><button type="button"  class="btn btn-info">  
                     <i class="fa icon-home"></i>Go To Web Site</button> </a></div> <!--space between menu and label-->
       
       
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
                <div class="login-panel panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Sign In</h3>
                    </div>
                    <div class="panel-body">
                        <form name="formLogin" id="formLogin" action="<?php echo base_url() .'index.php/login/verifyUser' ?>" method="post">
                            <fieldset>
                                <label id="un" class="hide" style="color:red;">Check your UserName and Password</label>
                                <div class="form-group">
                                    <input class="form-control" placeholder="UserID" name="username" id="username" type="text" autofocus  required="true"/>
                                    
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Password" name="password" id="password" type="password" value="" required="true" />
                                    <!--<label id="un" class="hide" style="color:red;">Username not Available</label>-->
                                </div>

  <!--%$^%$^REMOVE <A> IN LOGIN--><button type="submit" name="btnSubmit" id="btnSubmit" class="btn btn-info" style="width:100%">Login</button>
                                <!--<button type="button" name="btnSubmit" id="btnSubmit" class="btn btn-warning" style="width:49%">Register!</button>-->
                                <br/>
                                <br/>
                                <a href="<?php echo base_url(); ?>index.php/reset_password/index" style="color:red;align:text-center">Forgot password?</a>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <a href="<?php echo base_url(); ?>index.php/reset_password/newUserForm" style="color:blue;align:text-center">New User?</a>
                            <div class="row">
                                <div class="span6">
                                    <div class="" id="alertMsg"></div>
                                </div>
                            </div>
                            
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>


	  <!--END PAGE CONTENT -->     
      <!-- PAGE LEVEL SCRIPTS -->
      <!-- GLOBAL SCRIPTS -->
      
            <script src="<?=base_url();?>assets/admin_assets/plugins/jquery-2.0.3.min.js"></script>
            <!--<script src="<?=base_url();?>assets/jquery-3.0.0"></script>-->
            <script src="<?=base_url();?>assets/admin_assets/plugins/bootstrap/js/bootstrap.min.js"></script>
            <script src="<?=base_url();?>assets/admin_assets/plugins/modernizr-2.6.2-respond-1.1.0.min.js"></script>
            <!-- END GLOBAL SCRIPTS -->
       <!--END PAGE LEVEL SCRIPTS -->

       <script>
            $(document).ready(function () {

                if ("<?php echo $this->session->flashdata('msg');?>" === "OK") {

                    $("#un").removeAttr("class", "hide").fadeOut(3000);
                    $("#pw").removeAttr("class", "hide");
                    //$("#un").show();
                    //$("#pw").show();
                }
            });
        </script>
       
       
</body>
    <!-- END BODY -->
</html>
