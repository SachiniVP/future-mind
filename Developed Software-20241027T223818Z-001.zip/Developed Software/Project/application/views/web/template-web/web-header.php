<!--    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">-->
    
    <!-- Bootstrap Core CSS -->
    <link href="<?=base_url();?>assets/web/bootstrap.min.css" rel="stylesheet"/>

    <!-- Custom CSS -->
    <link href="<?=base_url();?>assets/web/modern-business.css" rel="stylesheet"/>

    <!-- Custom Fonts -->
    <link href="<?=base_url();?>assets/web/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/slider/sliderengine/amazingslider-1.css">
