
<!DOCTYPE html>
<!--Administrator Dashboard-->

<html>   
<!-- BEGIN HEAD-->
<head>
       
    <title>Dashboard</title>
    <?php echo $this->load->view('admin_panel/template/header'); ?>
    <!-- PAGE LEVEL STYLES -->
    <link href="<?=base_url();?>assets/admin_assets/css/layout2.css" rel="stylesheet" />
    <!-- END PAGE LEVEL  STYLES -->
    
    
</head>
<!-- END  HEAD-->    
   
    
    <!-- BEGIN BODY-->
<body class="padTop53" >

     <!-- MAIN WRAPPER -->
    <div id="wrap" style="background-image: url('http://localhost:8080/Project/assets/imgs/bgptn.png'); background-repeat: repeat;">
        <!--HEADER SECTION -->
         <?php echo $this->load->view('admin_panel/template/navbar'); ?>
        <!-- END HEADER SECTION -->
        


        <!-- MENU SECTION -->
          <?php echo $this->load->view('parentsView/parents_menubar'); ?>
        <!--END MENU SECTION -->


        <!--PAGE CONTENT -->
        <div id="content" >

            <div class="inner" style="min-height:1200px; background-image: url('http://localhost:8080/Project/assets/imgs/bgptn.png'); background-repeat: repeat;">
                <!---breadcrumb--->
                <div class="row">
                    <div class="col-md-12">
                        <div class="col-lg-12">
                            <div class="well-sm">
                                <ul class="breadcrumb">
                                    <li class="#"> Dashboard</li>
                                </ul>
                            </div>
                        </div> <!-- /.col-lg-12 --> 
                    </div> <!-- /.col-md-12 -->
                </div><!-- /.row -->
                <!---END breadcrumb--->
                
                <div class="row" style="margin-top: 20px;">

                <div class="col-sm-4">
                    <div class="panel panel-info">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                <img src="<?php echo base_url('assets/imgs/icons/kid3.png')?>" alt="Profile" />
                                </div>
                                <div class="col-xs-3">
                                <img src="<?php echo base_url('assets/imgs/icons/kid2.png')?>" alt="Profile" />
                                </div>
                             </div>
                        </div>
                        <a href='<?php echo base_url()."index.php/parentsController/studentProfile"?>'>
                            <div class="panel-footer" style="font-weight: bold;" >
                                <span class="pull-left"  >Profile</span>
                                <span class="pull-right"><i class="fa icon-circle-arrow-right"></i></span>
                                <div class="clearfix" ></div>
                            </div>
                        </a>
                    </div>
                </div>
                       <div class="col-sm-4">
                    <div class="panel panel-info">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                 <img src="<?php echo base_url('assets/imgs/icons/i4.png')?>" alt="Evaluation" />   
                                </div>
                            </div>
                        </div>
                        <a href="<?php echo base_url()."index.php/parentsController/stdnSubejctList"?>">
                            <div class="panel-footer" style="font-weight: bold;" >
                                <span class="pull-left"  >Evaluation</span>
                                <span class="pull-right"><i class="fa icon-circle-arrow-right"></i></span>
                                <div class="clearfix" ></div>
                            </div>
                        </a>
                    </div>
                </div>
                
                <div class="col-sm-4">
                    <div class="panel panel-info">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <img src="<?php echo base_url('assets/imgs/icons/i3.png')?>" alt="Events/Notifications" />
                                                                    
                                </div>
                            </div>
                        </div>
                        <a href="<?php echo base_url()."index.php/parentsController/parentsEvents"?>">
                            <div class="panel-footer" style="font-weight: bold;" >
                                <span class="pull-left"  >Events/Notifications</span>
                                <span class="pull-right"><i class="fa icon-circle-arrow-right"></i></span>
                                <div class="clearfix" ></div>
                            </div>
                        </a>
                    </div>
                </div>
                
                </div>


            </div>




        </div>
       <!--END PAGE CONTENT -->
       
       <!-- RIGHT STRIP  SECTION -->
          <div id="right">
         
            <div class="well well-small" style="background-color: #007ea2;
                                                    font-family: helvetica;
                                                    font-weight: bold;
                                                    font-size: 20px;
                                                    color: #f5f5f5" >
                <div id="showdate"></div>
               
            </div>
            <div class="well well-xm" id="event_well" style="background-color: #fa7f81;overflow: auto; height:425px; width: 100%; font-color:black;">
                     <!--ajax append-->   
            </div>
          
        </div>
         <!-- END RIGHT STRIP  SECTION -->

    </div>
     <!--END MAIN WRAPPER -->
     
     <?php echo $this->load->view('admin_panel/template/footer'); ?>  
                <script>
                var d = new Date();
                document.getElementById("showdate").innerHTML = d.toDateString();
                </script>
                
                
            <!--Load Events-->
                <script>
        $(document).ready(function () {
               baseurl = "http://localhost:8080/Project/";
               $.ajax({
                    url: baseurl + "index.php/parentsController/showEventsT",
                    dataType: 'json',
                    success: function (data) {
                        console.log(data.record.a);
                        
                        if (data.recd="YES") { 
                                $.each(data.record.all, function (i, obj) {// apprvedlessonplans forclasses table append
                                          
                                        $(
                                                '<li>'+
                                                       '<a href="<?php echo base_url()."index.php/parentsController/parentsEvents"?>">'+
                                                            '<strong>'+obj.header+'</strong>'+
                                                                '<span class="pull-right text-muted">'+
                                                                    '<em>'+obj.e_date+'</em>'+
                                                                '</span>'+
                                                           '</a>'+
                                                    '</li>'+
                                                    '<hr>'
                                                ).appendTo("#event_well").fadeIn("slow");

                                   });
                                   $.each(data.record.teachers, function (i, obj) {// appr[vedlessonplans forclasses table append
                                          
                                        $(
                                                '<li>'+
                                                       '<a href="<?php echo base_url()."index.php/teacherController/viewEventsT"?>">'+
                                                            '<strong>'+obj.header+'</strong>'+
                                                                '<span class="pull-right text-muted">'+
                                                                    '<em>'+obj.e_date+'</em>'+
                                                                '</span>'+
                                                           '</a>'+
                                                    '</li>'+
                                                    '<hr>'
                                                ).appendTo("#event_well").fadeIn("slow");

                                   });
                        }
                       else {} 
                    }
                });
            
        });</script>


</body>
    <!-- END BODY-->
  
</html>

