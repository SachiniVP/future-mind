<!DOCTYPE html>
<html lang="en">
    
    <style>
      body {
       background-image:url('<?php echo base_url('assets/imgs/n2.jpg')?>');
       
       background-size:cover; 
       font-family: cursive}
     </style>

<head>
   
    <title>New Admission</title>

    <?php echo $this->load->view('web/template-web/web-header'); ?>

</head>

<body>

    <?php echo $this->load->view('web/template-web/nav-bar'); ?>
   

    <!-- Page Content -->
     <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
     <div class="container">
         <!-- Page Heading/Breadcrumbs -->
        <div class="row">
            <div class="col-lg-12">
                <h2>Enroll Now</h2>
            </div>
        </div>
        <!-- /.row -->

        <div id="page-wrapper" style="margin-top:0px;background-color: #c8c8c8;" class="well">
            <div class="well" style="background-color:transparent">
            <form action="<?php echo base_url(); ?>index.php/admissions/newAdmission" method="POST" id="admission_form" onSubmit="alert('Thank You.Your request is recorded.Please use your Admission Number for further inquiries and confirm your request by making the payment before the deadline');">
             <!--student ID--> 
                <div class='row'>
                    <div class='col-sm-3'> 
                            <label for="admission_id" class="control-label"> Your Admission No:</label>
                    </div>
                    <div class='col-sm-4'>
                        <div class='form-group'>
                            <input type="text"  value="<?php echo "A".$serial; ?>" id="admission_id" name="admission_id"   class="form-control"  readonly/>
                        </div>
                    </div>
                </div>  
             <!--student ID-->  
             </br>
             <!--student name-->    
           <div class='row'>
                <div class='col-sm-3'> 
                        <label for="student_name" class="control-label">Student Name</label><em style=" color: red;">*</em>
                </div>
                <div class='col-sm-8'>
                    <div class='form-group'>
                        <input type="text" id="st_name" name="st_name"   class="form-control"  required="true"  placeholder=""/>
                    </div>
                </div>
           </div>   
             <!--/student name-->
             </br>                                   
             <!--student gender-->
             <div class="row">
                <div class='col-sm-3'> 
                        <label for="student_gender" class="control-label" >Gender</label><em style=" color: red;">*</em>
                </div>
                <div class='col-sm-2'>
                    <div class='form-group'>
                        <input type="radio" id="gender" name="gender"  value="Male" />Male
                    </div>
                </div>
                <div class='col-sm-2'>
                    <div class='form-group'>
                        <input type="radio" id="gender" name="gender"  value="Female" />Female


                    </div>
                </div>
              </div>
             <!--/student gender-->
              </br>


             <!--student DOB-->
             <div class="row">
                <div class='col-sm-3'> 
                        <label for="student_dob" class="control-label">Date of Birth</label><em style=" color: red;">*</em>

                </div>
                 <div class='col-sm-3'>
                    <div class='form-group'>
                        <div id="sandbox-containerDOB" >
                        <div class="input-group date">
                            <input type="text" class="all form-control" id="dob" name="dob" required="required" placeholder="YYYY-MM-DD" readonly="true"><span class="input-group-addon"><i class="fa fa-calendar fa-fw"></i></span>
                        </div>
                        </div>
                   </div>
                </div>
              </div>
             <!--/student DOB-->
              </br>

<!--              school year
             <div class="row">
                <div class='col-sm-3'> 
                        <label for="school_year" class="control-label">Year of Schooling</label>
                </div>
                <div class='col-sm-3'> 
                <div class='form-group'>
                    <input type="number" id="sch_yr"  name="sch_yr"    class="form-control"  required="true"  value="<?php echo date("Y"); ?>"/>
                </div>
                </div>    
              </div>-->
             <!--/school year-->
              </br>
             
              <!--enrolling class-->
             <div class="row">
                <div class='col-sm-3'> 
                        <label for="class" class="control-label">Enrolling Class</label><em style=" color: red;">*</em>
                </div>
                <!--student Dropdown-->
                    <div class='col-sm-4'>
                    <div class='form-group' >

                               <select name="grade"  class="form-control" id="grade" required="true">
                                   <option value="">---select---</option>
                                    <?php foreach($grades as $grade){?>
                                    <option value="<?=$grade['grade_name']?>"><?=$grade['grade_name']?>--<?=$grade['schooling_yr']?></option>
                                    <?php
                                }
                                ?>
                                </select>
                        
                    </div>
                    </div>
                     <!--/student Dropdown-->
             </div>
             <!--/enrolling class-->
              </br>
             
              <!--parent name-->    
               <div class='row'>
                    <div class='col-sm-3'> 
                            <label for="p_name" class="control-label">Parent's Name</label><em style=" color: red;">*</em>
                    </div>
                    <div class='col-sm-8'>
                        <div class='form-group'>
                            <input type="text" id="p_name" name="p_name"   class="form-control"   placeholder="" required="true"/>
                        </div>
                    </div>
                </div> 
               <!--/parent name-->
               </br>
               
               <!---PID-->
                <div class='row'>
                <div class='col-sm-3'> 
                        <label for="Parent_ID" class="control-label">Parent NIC</label><em style=" color: red;">*</em>
                </div>
                <div class='col-sm-4'>
                    <div class='form-group'>
                        <input type="text" value="" id="parent_id" name="parent_id" class="form-control"  placeholder="Insert   NIC *********V" maxlength="10" />
                    </div>
                </div>
                </div> 
                <!---/PID-->
                </br>

                <!--parent job-->    
                   <div class='row'>
                        <div class='col-sm-3'> 
                                <label for="f_job" class="control-label">Designation</label>
                        </div>
                        <div class='col-sm-4'>
                            <div class='form-group'>
                                <input type="text" id="job" name="job"   class="form-control"   placeholder="Eg:Teacher"/>
                            </div>
                        </div>
                    </div> 
                 <!--/parent job--> 
                 
                 <!--parent employer name-->    
                   <div class='row'>
                        <div class='col-sm-3'> 
                                <label for="f_employer" class="control-label">Name of the Employer</label>
                        </div>
                        <div class='col-sm-8'>
                            <div class='form-group'>
                                <input type="text" id="employer" name="employer"   class="form-control"  placeholder="ABC Company Ltd,Matara"/>
                            </div>
                        </div>
                    </div> 
               <!--/parent employer name-->
                </br>

              <!--student Tel No-->
                 <div class="row">
                    <div class='col-sm-3'> 
                            <label for="student_tel_no" class="control-label">Contact Number</label><em style=" color: red;">*</em>
                    </div>
                     <div class='col-sm-4'>
                        <div class='form-group'>
                            <input type="text" id="tel" name="tel"   class="form-control" maxlength="10" placeholder="Number with 10 digits"/>
                        </div>
                    </div>
                  </div>
             <!--/student Tel No-->
                </br>
              <!--parent email-->
                 <div class="row">
                    <div class='col-sm-3'> 
                            <label for="f_email" class="control-label">Email</label><em style=" color: red;">*</em>
                    </div>
                     <div class='col-sm-4'>
                        <div class='form-group'>
                            <input type="email"  id="email" name="email"   class="form-control"  required="true"/>
                        </div>
                    </div>
                  </div>
                 <!--/parent EMAIL-->
                 </br>
              <!--student address-->
                 <div class='row'>
                    <div class='col-sm-3'> 
                            <label for="home_address" class="control-label">Mailing Address</label><em style=" color: red;">*</em>
                    </div>
                    <div class='col-sm-6'>
                        <div class='form-group'>
                            <input type="text" id="add_L1" name="add_L1"   class="form-control"  required="true"  placeholder="Line 1"/>
                        </div>
                    </div>
                 </div>
                 <div class="row">
                   <div class="col-sm-6 col-sm-offset-3"><input type="text" id="add_L2" name="add_L2"   class="form-control"  placeholder="Line 2"/></div>
                 </div> 
                 </br> 
                 <div class="row">
                   <div class="col-sm-6 col-sm-offset-3"><input type="text" id="add_L3" name="add_L3"   class="form-control"  placeholder="Line 3"/></div>
                 </div>
             <!--student address-->
             </br></br>
              <!--applying date-->
             <div class="row">
                <div class='col-sm-3'> 
                        <label for="app_date" class="control-label">Date of Application</label><em style=" color: red;">*</em>
                </div>
                <div class='col-sm-3'> 
                <div class='form-group'>
                    <input type="text" id="app_date"  name="app_date"    class="form-control"  required="true"  value="<?php echo date("Y/m/d");  ?>"/>
                </div>
                </div>    
              </div>
             <!--/applying date-->
              </br> 
                 <div class="row">
                                         <div class="col-sm-offset-7">
                                            <div class="col-sm-3">
                                                    <button type="submit" class="btn btn-success">
                                                        <i class="fa fa-floppy-o fa-fw"></i> Submit
                                                    </button>							
                                            </div>
                                            <div class="col-sm-3">
                                                    <button type="reset" class="btn btn-default">
                                                        <i class="fa fa-pencil fa-fw"></i> Reset
                                                    </button>
                                            </div>
					</div> 
                                     </div>
                
                
                
                
                
            </form>
        
            
            
            
    
        
         </div> 
        </div> 
    
        
        
        <hr>
             <?php echo $this->load->view('web/template-web/web-footer'); ?> 
      </div>
         
    </div>   
    
    <script src="<?=base_url();?>assets/admin_assets/plugins/modernizr-2.6.2-respond-1.1.0.min.js"></script>    
    <script src="<?=base_url();?>assets/admin_assets/plugins/jquery-2.0.3.min.js"></script>
    
    <!-- date picker bootstrap-->
        <link href="<?php echo base_url(); ?>assets/bootstrap-datepicker1.6.1/css/bootstrap-datepicker.css" rel="stylesheet" type="text/css"/>
        <script src="<?php echo base_url(); ?>assets/bootstrap-datepicker1.6.1/js/bootstrap-datepicker.js" type="text/javascript"></script>
        <script src="<?php echo base_url(); ?>assets/bootstrap-datepicker1.6.1/locales/bootstrap-datepicker.en-GB.min.js" type="text/javascript"></script>
        <!--/ Java Script -->
      <script>
          $(document).ready(function () { 
                $('#sandbox-containerDOB .input-group.date').datepicker({
                   format: "yyyy-mm-dd",
                   weekStart: 1,
                   maxViewMode: 2,
                   endDate: '-2y', // minimum age should be 2
                   startDate: '-6y',//maximum age should be 
                   clearBtn: true,
                   calendarWeeks: true,
                   autoclose: true,
                   todayHighlight: true
                });
    
                   });
     </script>
    
    
   <!-- Validation files-->
            <script src="<?=base_url();?>assets/jquery-validation-1.15.0/lib/jquery.mockjax.js"></script>
            <script src="<?=base_url();?>assets/jquery-validation-1.15.0/dist/jquery.validate.js"></script>
            <script src="<?=base_url();?>assets/jquery-validation-1.15.0/dist/additional-methods.js"></script>
            <link href="<?php echo base_url(); ?>assets/jquery-validation-1.15.0/demo/css/screen.css" rel="stylesheet" type="text/css"/>
            <!-- Validation files--> 
       <script>
            $(document).ready(function () {
                //$("#staff_add_form").validate();  // full validation

                function A(value, element) {
                    return /^[a-zA-Z\s]+$/.test(value);
                }
                function numbers(value, element) {
                    return /^[0-9]+$/.test(value);
                }
                function initialsValidation(value, element) {
                    return /^[a-zA-Z.\s]+$/.test(value);
                }

                function initialsNameValidation(value, element) {
                    return /^[a-zA-Z.\s]+$/.test(value);
                }

                function DateFormatValidation(value, element) {
                    return /^[0-9]{4}-(0[1-9]|1[012])-(0[1-9]|1[0-9]|2[0-9]|3[01])+$/.test(value);
                }

                function NICValidation(value, element) {
                    return /^[0-9]{9}[VXvx]+$/.test(value);
                }
                function Year(value, element) {
                      return /^(0[1-9]|1[0-9]|2[0-9]|3[01])+$/.test(value);
                }
                function DisallowSpaces(value, element) {
                    return /^[^-\s][a-zA-Z0-9/_\s-]+$/.test(value);
                }
                
                //custom validation rule - text only
                $.validator.addMethod("textOnly", A, "Please insert alphebetic characters only");
                //custom validation rule - numbers only
                $.validator.addMethod("numbersOnly", numbers, "Please insert numbers only");
                //custom validation rule - text/full stop/spaces
                $.validator.addMethod("initials", initialsValidation, "Please insert alphebetic characters with . or spaces");
                //custom validation rule - text/full stop/spaces
                $.validator.addMethod("initialsName", initialsNameValidation, "Please insert alphebetic characters with . or spaces");
                //custom validation rule - date format YYYY-MM-DD
                $.validator.addMethod("dateFormat", DateFormatValidation, "Please Enter Valid Date Format YYYY-MM-DD");
                //custom validation rule - NIC
                $.validator.addMethod("nic", NICValidation, "Please insert valid NIC format");
                //year     
                $.validator.addMethod("year", Year, "Insert a valid Year");
                //DisAllow Space Validation
                $.validator.addMethod("nosapce", DisallowSpaces , "No Spaces and special characters please");

                $("#admission_form").validate({
                    rules: {
                        st_name: {required: true,textOnly: true,nosapce:true},
                        gender:{required: true},
                        dob: {required: true,dateFormat: true},
                        grade: {required: true,nosapce:true},
                        p_name: {textOnly: true,nosapce:true},
                        parent_id: {nic: true},
                        tel: {required: true,numbersOnly: true, length: "10"},
                        add_L1: {required: true,nosapce:true},
                        add_L3: {required: true,nosapce:true},
                           },
                    messages: {
                        
                    }
                });
            });
        </script>
 
</body>

</html>



