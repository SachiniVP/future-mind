<div id="left">
          
            <div class="media user-media well-small">
           
                <br />
                <div class="media-body" style="height: 80px;">
                    <h6 class="media-heading" style="color:black;font-family: calibri;font-size: medium;"><strong>Welcome</strong></h6>
                   <h5 class="media-heading" style="color:black;font-family: calibri;font-size: medium;"><strong><?php echo $studentData[0]->first_name." ".$studentData[0]->last_name; ?></strong></h5>
                    
                </div>
                <br />
            </div>  
            <ul id="menu" class="collapse" style="font-weight: bolder;font-family: calibri;font-size: medium;">

                
                <li class="panel">
                    <a href="<?php echo base_url()."index.php/parentsController/parentsDashboard"?>" >
                        <i class="icon-table"></i> Dashboard                       
                    </a>                   
                </li>

                <li class="panel">
                    <a href="<?php echo base_url()."index.php/parentsController/studentProfile"?>" >
                        <i class="icon-table"></i> Profile                       
                    </a>                   
                </li>
                
                <li class="panel">
                    <a href="<?php echo base_url()."index.php/parentsController/stdnSubejctList"?>" >
                        <i class="icon-table"></i> Evaluation                       
                    </a>                   
                </li>


                <li class="panel">
                    <a href="<?php echo base_url()."index.php/parentsController/parentsEvents"?>" >
                        <i class="icon-table"></i> Events/Notifications                       
                    </a>                   
                </li>

             

            </ul>

        </div>