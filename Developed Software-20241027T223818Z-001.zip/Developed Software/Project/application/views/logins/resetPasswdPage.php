<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!--> <html lang="en"> <!--<![endif]-->

<!-- BEGIN HEAD -->
<head>
     <meta charset="UTF-8" />
    <title> Reset Password Page</title>
  
      <?php echo $this->load->view('admin_panel/template/header'); ?>
      <link href="<?php echo base_url(); ?>assets/jquery-validation-1.15.0/demo/css/screen.css" rel="stylesheet" type="text/css"/>
           
    <style>
         body {
                background-image:url('<?php echo base_url('assets/imgs/login.jpg')?>');
                 background-repeat:no-repeat;
                 background-size:cover }
     </style>    
</head>
    <!-- END HEAD -->

    <!-- BEGIN BODY -->
<body >

   <!-- PAGE CONTENT --> 
   <div class="container">
         
       <div class="col-md-12" style="height:50px;"></div> <!--space between menu and label-->
       
       
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
                <div class="login-panel panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Reset Password</h3>
                    </div>
                    <div class="panel-body">
                        <label id="nouser" class="hide" style="color:red;">Invalid User Name</label>
                        <label id="notsent" class="hide" style="color:red;">Email Not Sent, Check Your Network Nonnection</label>
                        <label id="email" class="hide" style="color:blue;">Email Sent,Check Your email</label>
                        <form name="formRestPW" id="formRestPW" action="" method="post">
                        <div class="row hide" id="processing_image">
                            <div style="margin-left: 30%; margin-bottom: 2%;">
                                <img style=" float: none;" width="134px" height="38px" src="<?php echo base_url(); ?>assets/imgs/processing-light.gif" alt=""/>
                            </div>
                        </div>    
                            
                            <div class="formgroup" style="border:transparent">
                                <!--<label id="un" class="hide" style="color:red;">Check your UserName </label>-->
                                <div class="form-group">
                                    <input class="form-control" placeholder="UserName" name="username" id="username" type="text" autofocus />
                                </div>
                                

                            <button type="submit" name="btnSubmit" id="btnSubmit" class="btn btn-success" style="width:49%">Reset</button>
                            <a href="<?php echo base_url(); ?>index.php/login/index" class="btn btn-warning" style="width:49%">Back</a> 
                            <!--<button type="button" name="btnSubmit" id="btnSubmit" class="btn btn-warning" style="width:49%">Register!</button>-->
                                 
                            
                            </div>
                        </form>
                    </div>
                    
                    <div class="panel_footer hide" id='email_error_msg'>
                            <div class="row" style="margin-left: 5%;">
                                <div class="col-lg-12 col-md-12 col-sm-12">                                    
                                    <div style="color: red; margin-bottom: 4%; margin-left: -3%;"><strong>Email not sent, check your network connection</strong></div>
                                </div>
                            </div>
                        </div>
                        <div class="panel_footer hide" id='update_error_msg'>
                            <div class="row" style="margin-left: 5%;">
                                <div class="col-lg-12 col-md-12 col-sm-12">                                    
                                    <div style="color: red;"><strong>Unable to Reset the Password</strong></div>
                                </div>
                            </div>
                        </div>
                </div>
            </div>
        </div>
    </div>


	  <!--END PAGE CONTENT -->     
      <!-- PAGE LEVEL SCRIPTS -->
            <!-- GLOBAL SCRIPTS -->
            <script src="<?=base_url();?>assets/jquery-2.2.4.js"></script>
            <!--<script src="<?=base_url();?>assets/jquery-3.0.0"></script>-->
            <script src="<?=base_url();?>assets/admin_assets/plugins/bootstrap/js/bootstrap.min.js"></script>
            <script src="<?=base_url();?>assets/admin_assets/plugins/modernizr-2.6.2-respond-1.1.0.min.js"></script>
            <!-- END GLOBAL SCRIPTS -->
            <script src="<?=base_url();?>assets/jquery-ui.js" type="text/javascript"></script>
       <!--END PAGE LEVEL SCRIPTS -->
       
       <!-- Validation files-->
            <script src="<?=base_url();?>assets/jquery-validation-1.15.0/lib/jquery.mockjax.js"></script>
            <script src="<?=base_url();?>assets/jquery-validation-1.15.0/dist/jquery.validate.js"></script>
            <script src="<?=base_url();?>assets/jquery-validation-1.15.0/dist/additional-methods.js"></script>
            <!-- Validation files--> 

       <!-- Form Validation : -->
        <script>
            $(document).ready(function () {

                $("#formRest").validate({
                    rules: {
                        username: {
                            required: true,
                                         }
                    },
                    messages: {
                        username: {
                            required: "This field is required",
                         }
                    }
                });
            });
        </script>
       
        <!-- reset form submit -->
        <script>
            $(document).ready(function () {
                baseurl = "http://localhost:8080/Project/";
                $("#formRestPW").submit(function (e) {
                    e.preventDefault();
                    if (!$(this).valid())
                        return false;
                    $("#processing_image").removeAttr("class", "hide");
                    $("#processing_image").attr("class", "row");

                    var jqXHR = $.ajax({
                        type: "POST",
                        url: baseurl + "index.php/reset_password/resetPassword",
                        data: $("#formRestPW").serialize(),
                        dataType: 'json',
                        success: function (data) {
     //                            console.log(data);
                            $("#processing_image").attr("class", "hide");
                            if (data.record === "EmailNotSent") {
                               $("#notsent").removeAttr("class", "hide");
                                $("#notsent").fadeIn(1500);
                                $("#notsent").delay(2500).fadeOut(1500);
                                
                            }
                            else if (data.record === "EmailSent") {
                                $("#email").removeAttr("class", "hide");
                                $("#email").fadeIn(1500);
                                $("#email").delay(2500).fadeOut(1500);
                                
                            }
                            else if (data.record === "NOUSER") {
//                                alert("hi");
                                $("#nouser").removeAttr("class", "hide");
                                $("#nouser").fadeIn(1500);
                                $("#nouser").delay(2500).fadeOut(1500);
                            }
                        }
                    });
                });
            });
        </script>
       
</body>
    <!-- END BODY -->
</html>
