<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class teacher extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('Generic_model', '', TRUE);
        /**if (!$this->session->userdata("username")) {
            redirect(base_url() . "index.php/login");
        };**/
        
    }
   
        public function index() {
        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
			   $fields = array(
            "teacher_id", 
            "t_name",
            "t_contact_no",
            "t_email",
            "t_nic", 
            "t_add_l3",
            "t_date_of_join",
                );
        $whereArr=array("status" => 0);
        $data['teacherData']=$this->Generic_model->getData($fields,'teacher',$whereArr); //public function getData($fieldset, $tableName, $where = '')
        
        $this->load->view('admin/teacher/index',$data);
			
			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
   //outer else
	} else {
		redirect('login/index');
	}
     }
        
        public function addTeacherForm() {
       if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
			    $serial = $this->Generic_model->getData('serial', 'serials', array("type" => "teacher"));
                            $serialNo=$serial[0]->serial + 1;
                            $num_padded_serialNo = sprintf("%03d", $serialNo); //adding leadind 0s
                            $d ="T".$num_padded_serialNo;
                          
                            $data['serialNum'] = $d;
                           // var_dump($data);die;
                            $this->load->view('admin/teacher/addTeacherForm', $data);
        
			
			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
   //outer else
	} else {
		redirect('login/index');
	}
    }
      
         
        public function addTeacher() {
        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
	$serial = $this->Generic_model->getData('serial', 'serials', array("type" => "teacher"));
        $serialNo = $serial[0]->serial + 1; 
        $num_padded_serialNo = sprintf("%03d", $serialNo); //adding leadind 0s
        $d ="T".$num_padded_serialNo;
   
        
        $dataArr = array(
            "teacher_id" => $this->input->post("tid"),
            "title" => $this->input->post("title"),
            "t_name" => $this->input->post("t_name"),
            "t_add_l1" => $this->input->post("t_add_L1"),
            "t_add_l2" => $this->input->post("t_add_L2"),
            "t_add_l3" => $this->input->post("t_add_L3"),
            "t_contact_no" => $this->input->post("tel"),
            "t_email" => $this->input->post("email"),
            "t_nic" => $this->input->post("t_nic"),
            "t_qual" => $this->input->post("t_qual"),
            "t_other" => $this->input->post("t_remark"),
            "t_date_of_join" => $this->input->post("doj"),
            "dob" => $this->input->post("dob"),
            "gender" => $this->input->post("gender"),
            );
        
        $this->Generic_model->insertData('teacher', $dataArr);
        $data = array("serial" => $serialNo);
        $whereArr = array("type" => "teacher");
        $this->Generic_model->updateData("serials", $data, $whereArr);
        //var_dump($data);die;
        redirect('teacher/index');
 
			
			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
   //outer else
	} else {
		redirect('login/index');
	}
    }
    
        public function viewTeacher($teacher_id) {
        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
//			               var_dump($teacher_id);
                        $fields = '*';
                        $whereArr=array("teacher_id"=>$teacher_id);
                        $result=$this->Generic_model->getData($fields,'teacher',$whereArr);
                        $data['userData2']=$result[0];
                //        var_dump($data);die;
                        $this->load->view('admin/teacher/viewTeacherForm',$data);
			
			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
   //outer else
	} else {
		redirect('login/index');
	}
    }
    
        public function editTeacherForm($teacher_id) {
       if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
			    //            var_dump($teacher_id);die;
   
        $whereArr=array("teacher_id"=>$teacher_id);
        $result=$this->Generic_model->getData('*','teacher',$whereArr);
        $data['userData2']=$result[0];
        
        $this->load->view('admin/teacher/editTeacherForm',$data);
			
			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
   //outer else
	} else {
		redirect('login/index');
	}
    }

        public function editTeacher() {

            if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
	   $teacher_id = $this->input->post("tid",TRUE);
            $title = $this->input->post("title",TRUE);
            $t_name = $this->input->post("t_name",TRUE);
            $t_contact_no = $this->input->post("tel",TRUE);
            $t_nic = $this->input->post("t_nic",TRUE);
            $t_qual = $this->input->post("t_qual",TRUE);
            $t_email = $this->input->post("email",TRUE);
            $t_add_l1 = $this->input->post("t_add_l1",TRUE);
            $t_add_l2 = $this->input->post("t_add_l2",TRUE);
            $t_add_l3 = $this->input->post("t_add_l3",TRUE);
            $t_other=$this->input->post("t_remark",TRUE);
            $t_date_of_join=$this->input->post("doj",TRUE);
            $dob=$this->input->post("dob",TRUE);
            $gender=$this->input->post("gender",TRUE);
            
       
        $dataArr = array(
            "teacher_id" => $teacher_id,
            "title" => $title,
            "t_name" => $t_name,
            "t_contact_no" => $t_contact_no,
            "t_nic" => $t_nic,
            "t_qual" => $t_qual,
            "t_email" => $t_email,
            "t_add_l1" => $t_add_l1,
            "t_add_l2" => $t_add_l2,
            "t_add_l3" => $t_add_l3,
            "t_other"=>$t_other,
            "t_date_of_join"=>$t_date_of_join,
            "dob"=>$dob,
            "gender"=>$gender,
                );
      $whereArr=array("teacher_id" => $teacher_id);
      $this->Generic_model->updateData("teacher",$dataArr,$whereArr);
     
      redirect('teacher/index');
			
			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
   //outer else
	} else {
		redirect('login/index');
	}
    }

    public function deleteTeacherForm($teacher_id) {
    if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
			   //            var_dump($teacher_id);die;
        $fields = '*';
        $whereArr=array("teacher_id"=>$teacher_id);
        $result=$this->Generic_model->getData($fields,'teacher',$whereArr);
        $data['userData2']=$result[0];
        
        $this->load->view('admin/teacher/deleteTeacherForm',$data);
			
			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
   //outer else
	} else {
		redirect('login/index');
	}
    }
     
    
     public function deleteTeacher($teacher_id) {
     if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
			   // var_dump($teacher_id);die;
        $data=array("status"=>1);
        $WhereArr=array('teacher_id'=>$teacher_id);
        $this->Generic_model->updateData("teacher",$data,$WhereArr);
        redirect(base_url()."index.php/teacher/");
			
			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
   //outer else
	} else {
		redirect('login/index');
	}
        
    }
    
    
        }    
 




