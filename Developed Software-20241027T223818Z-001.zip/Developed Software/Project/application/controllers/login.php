<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

session_start();

class Login extends CI_Controller {

        function __construct() {
        parent::__construct();
        $this->load->model('Generic_model', '', TRUE);
        $this->load->model('system_model', '', TRUE);
    }


    
    public function index() {
        $this->load->view('logins/loginPage');
    }	
	//verify the user 
        public function verifyUser() {

        $user = $this->input->post('username', TRUE);
        $psw = $this->input->post('password', TRUE);

        $fields = array("username", "password", "email", "group_id", "status");
        $whereArr = array("username" => $user, "password" => sha1($psw),"status" =>0);
        $result = $this->Generic_model->getData($fields, 'login', $whereArr);
        //var_dump($data);die;
        
        if(count($result) == 1){

              $sess_array = array('username' => $result[0]->username,
                'password' => $result[0]->password,
                'group_id' => $result[0]->group_id,
                'status' => $result[0]->status);
            $this->session->set_userdata('logged_in', $sess_array);

            redirect('login/userDirectory');
        } else {
        
            $this->session->set_flashdata('msg', 'OK');
            redirect('login/index');
        }
    
        }
        
        //check the user type and redirect to the relevent user group
        public function userDirectory() {
            if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];

            if ($group_id === "10") { //admin
                redirect('dashboard/index');
            }
            else if ($group_id === "20") { //teacher
                redirect('teacherController/teacherDashboard');
            }
            else if ($group_id === "30") { //parents
                redirect('parentsController/parentsDashboard');
            }
            else if ($group_id === "40") { //clerk
                redirect('login/dashboard_librarian');
            }
        } else {


            $this->load->view('template/access_denied');
        }
        }
        
        

    public function logout() {
        $this->session->sess_destroy();
        redirect(base_url() . "index.php/login/");
    }

    }
