
<!DOCTYPE html>
<!--Administrator Dashboard-->

   
<!-- BEGIN HEAD-->
<head>
       
    <title>Lesson Plan Index (Teachers)</title>
    <?php echo $this->load->view('admin_panel/template/header'); ?>
    <!-- PAGE LEVEL STYLES -->
    <link href="<?=base_url();?>assets/admin_assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
    <!-- END PAGE LEVEL  STYLES -->
</head>
<!-- END  HEAD-->    
   
    
    <!-- BEGIN BODY-->
<body class="padTop53" >

     <!-- MAIN WRAPPER -->
    <div id="wrap" style="background-color:#b8b8b8;">
        <!--HEADER SECTION -->
         <?php echo $this->load->view('admin_panel/template/navbar'); ?>
        <!-- END HEADER SECTION -->
        


        <!-- MENU SECTION -->
         <?php echo $this->load->view('teacherViews/teacher_menubar'); ?>
        <!--END MENU SECTION -->


        <!--PAGE CONTENT -->
        <div id="content" >
            
            <div class="inner" style="min-height:1200px;background-color:transparent">
                <!---breadcrumb--->
                <div class="row">
                    <div class="col-md-12">
                        <div class="col-lg-12">
                            <div class="well-sm">
                                <div style="">
                                    <ul class="breadcrumb"  >
                                    <li> <a href="<?php echo base_url()."index.php/teacherController/teacherDashboard"?>"> Dashboard </a> </li>
                                    <li class="#"> School Settings </li>
                                    <li class="#">Lesson Plans(TEACHERS)</li>
                                    <!--<li class="active"> View</li>-->
                                </ul>
                                </div>    
                            </div>
                        </div> <!-- /.col-lg-12 --> 
                    </div> <!-- /.col-md-12 -->
                </div><!-- /.row -->
                <!---END breadcrumb--->
          
                <div class="well" style=" background-color: transparent;">    
                    <div class="col-sm-offset-1"><h3 style="font-family: calibri;margin-top:-10px"> Add / View Lesson Plans</h3> </div> 
            </br> 
                    
                <div class="row"> 
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                 <div class="col-lg-9"> 
                    <div class="well well-lg">
                         <div class="panel-body">
                            <div class="table-responsive">
                               <table class="table table-striped table-bordered table-hover" id="dataTables-example" class="display" cellspacing="0" width="100%">    <thead>
                                        <tr>
                                            <th>Class Name</th>
                                            <th>subject</th>
                                             <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody center>
                                        <?php
                                foreach ($assigns as $userItem) {
                                    echo "<tr>";
                                    echo "<td>" . $userItem->class_name . "</td>";
                                    echo "<td>" . $userItem->sub_name. "</td>";
                                    echo "<td>";
//                                    echo "<a id='" . $userItem->class_name . "' href='#editclassFormModal' data-toggle='modal' class='editClass btn btn-primary btn-circle'><i class='icon-edit'></i></a>";
                                    echo "<a href='". base_url()."index.php/teacherController/lessonPlanForm/".$userItem->teacher_id.":".$userItem->sub_name.":".$userItem->class_name."' > <button type='button' class='btn btn-success' >
                                                       <i class='icon-plus-sign'>New Lesson Plan</i></button></a> ";
                                    echo "<a href='". base_url()."index.php/teacherController/approvedLPs/".$userItem->teacher_id.":".$userItem->sub_name.":".$userItem->class_name."' > <button type='button' class='btn btn-info' >
                                                       <i class='icon-eye-open'>Approved</i></button></a> ";
                                    echo"</td>";
                                }
                                ?>  
                                    </tbody>
                                </table>
                            </div>
                         </div><!--Data TAble-->                          
                    </div>  
                </div> 
                </div>
                </div>
                    
            </div><!-- END Academic Year-->
            
            <div class="well" style=" background-color: transparent;">    
                <div class="col-sm-offset-1"><h3 style="font-family: calibri;margin-top:-10px"> Lesson Plans - Pending Approval</h3> </div> 
            </br>     
             <div class="row"> 
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                 <div class="col-lg-12"> 
                    <div class="well well-lg">
                         <div class="panel-body">
                            <div class="table-responsive">
                               <table class="table table-striped table-bordered table-hover" id="dataTables-example" class="display" cellspacing="0" width="100%">    <thead>
                                        <tr>
                                            <th>Class</th>
                                            <th>Subject</th>
                                            <th>Date Range</th>

                                             <th>Comment</th>
                                             <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody center>
                                        <?php
                                foreach ($records as $userItem) {
                                    echo "<tr>";
                                    echo "<td>" . $userItem->class_nm . "</td>";
                                    echo "<td>" . $userItem->sub_name. "</td>";
                                    echo "<td>" . $userItem->date_range . "</td>";
//                                    echo "<td>" . $userItem->start_date . "</td>";
//                                    echo "<td>" . $userItem->end_date. "</td>";
                                    echo "<td>" . $userItem->comment. "</td>";
                                    echo "<td>";
                                    echo "<a id='" . $userItem->id . "' href='#editLPFormModal' data-toggle='modal' class='editLP btn btn-primary btn-circle'><i class='icon-edit'></i></a>";
                              
                                    echo "<a href='". base_url()."index.php/teacherController/deleteLessonPlan/".$userItem->id."' > <button type='button' class='btn btn-warning btn-circle' id='btnWarning'>
                                                        <i class='icon-trash'></i></button></a> ";
                                     
                                   echo"</td>";
                                   
                                }
                                ?>  
                                    </tbody>
                                </table>
                            </div>
                         </div><!--Data TAble-->                          
                    </div>  
                </div> 
                </div>
                </div> 
            </div><!-- well-->
            
              
              
              
              
              
               </div><!-- Inner-->      
           </div><!--END PAGE CONTENT -->
           
           
           
           
           
           <!-- Edit Lesson Plan Form Modal  -->
                <div id="editLPFormModal" data-backdrop="static" data-keyboard="false" class="modal fade" role="dialog" aria-labelledby="gridSystemModalLabel">
                    <div class="modal-dialog modal-lg" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                <h4 class="modal-title" id="gridSystemModalLabel">Lesson Plan | Edit</h4>
                            </div>
                            <form  id="editLPForm" class="form-horizontal" method="POST" action="<?php echo base_url(); ?>index.php/teacherController/editLPForm">
                
                        <div class="modal-body">
                            <div class="hide">
                                <input  id="LP_id" name="LP_id"  class="form-control hidden" readonly/> 
                            </div>
                        <div class="row">     
                        <div class='col-sm-3'> 
                        <label for="" class="control-label"> Date Range </label>
                        </div>
                                            <div class='col-sm-5'><div class='form-group'>
                                                 <div class="input-group date" >
                                                     <input type="text" class="all form-control" id='daterangep' name="daterangep" readonly=""><span class="input-group-addon"><i class="icon-calendar"></i></span>
                                            </div>
                                            </div></div><label style="color:red;font-style:italic;"> Note: Lessons to be edited allowed for next 3 months only.</label>
                        </div>   
                            
                        <div class='row'> 

                        </br>
                                <div class='row'><!--activity-->
                                    <div class='col-sm-3'> 
                                            <label for="TName" class="control-label">Lesson Plan</label>
                                        </div>
                                    <div class='col-sm-7'>
                                            <div class='form-group'>
                                                <textarea id="activity" name="activity" rows="5" cols="100" class="form-control" ></textarea>
                                            </div>
                                    </div>
                                </div> <!--/activity-->
                                <div class='row'> <!--added on-->
                                    <div class='col-sm-3'> 
                                             <label for="grade_name">Added On</label>
                                    </div>
                                    <div class='col-sm-4'><div class='form-group'>
                                            <input type="text" class="form-control" id="add" name="add" value="" required="" readonly>
                                    </div></div>
                                </div><!--/added on-->
                                <div class='row'><!--comment-->
                                    <div class='col-sm-3'> 
                                            <label for="Comment" class="control-label"> Comment</label>
                                        </div>
                                    <div class='col-sm-7'>
                                            <div class='form-group'>
                                                <textarea id="comment" name="comment" rows="5" cols="50" class="form-control" readonly></textarea>
                                    </div>
                                </div><!--/comment-->
                                </div> 
                         
                        
                                </div>
                                </div><!--//modalbody-->
                                <div class="modal-footer">
                                      <button id="" type="submit" class="hpj btn btn-primary">Update</button>
                                      <button id="cls" type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                </div><!-- /. modal-footer -->
                            </form>
                        </div><!-- /.modal-content -->
                    </div><!-- /.modal-dialog -->
                </div><!-- /.modal -->
                <!--/. Edit Class Form Modal -->

           
           
           
           
           
        </div><!--END MAIN WRAPPER -->
    
    
                <!-- PAGE LEVEL SCRIPTS -->
                <?php echo $this->load->view('admin_panel/template/footer'); ?> 

               
                <!--DATA Table-->
                <script src="<?=base_url();?>assets/admin_assets/plugins/dataTables/jquery.dataTables.js"></script>
                <script src="<?=base_url();?>assets/admin_assets/plugins/dataTables/dataTables.bootstrap.js"></script>
                <script>
                     $(document).ready(function () {
                         $('.table ').dataTable();
                     });
                </script>
                <!-- END PAGE LEVEL SCRIPTS -->  
                
                
             <!--bootstrap date range picker-->
            <script src="<?php echo base_url(); ?>assets/bootstrap-daterangepicker/moment.js" type="text/javascript"></script>
            <script src="<?php echo base_url(); ?>assets/bootstrap-daterangepicker/daterangepicker.js" type="text/javascript"></script>
            <link href="<?php echo base_url(); ?>assets/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet" type="text/css"/>
       
             <!--/ Java Script--> 
            <script>
            $(document).ready(function () {
                mdTemp = new Date(), //setting max date is 3 months from today
                maxDate = new Date(mdTemp.setDate(mdTemp.getDate() + 90));
                
                   $('#daterangep').daterangepicker({
                          "opens": "left",
                          "showWeekNumbers": true,
                          "weekStart": "1" ,
                          "minDate": new Date(),
                           "maxDate": maxDate,
                           isInvalidDate: function(date) {   //disable weekends
                                    return (date.day() == 0 || date.day() == 6);
                                  },
                         locale: {
                                format: 'YYYY-MM-DD'
                            }
                   });
                   });
             </script>

                
                
                
           
                <!-- Validation files-->
                <script src="<?=base_url();?>assets/jquery-validation-1.15.0/lib/jquery.mockjax.js"></script>
                <script src="<?=base_url();?>assets/jquery-validation-1.15.0/dist/jquery.validate.js"></script>
                <script src="<?=base_url();?>assets/jquery-validation-1.15.0/dist/additional-methods.js"></script>
                <!--<link href="<?php echo base_url(); ?>assets/jquery-validation-1.15.0/demo/css/screen.css" rel="stylesheet" type="text/css"/      >-->
                <!-- Validation files-->
                
                <script>
                            $(document).ready(function () {
                               function Year(value, element) {
                                    return /^(0[1-9]|1[0-9]|2[0-9]|3[01])+$/.test(value);
                                }

                                function DateFormatValidation(value, element) {
                                    return /^[0-9]{4}-(0[1-9]|1[012])-(0[1-9]|1[0-9]|2[0-9]|3[01])+$/.test(value);
                                }
                          //custom validation rule - date format YYYY-MM-DD
                                $.validator.addMethod("Year", Year, "Insert a valid Year");
                                $.validator.addMethod("dateFormat", DateFormatValidation, "l");

                    //            $.validator.addMethod("greaterThan",'Must be greater than {0}');
                                    $("#editLPForm").validate({

                                      rules: {
                                         year: {required: true, Year: "Insert a valid Year"},
//                                        fromD: {required: true,
//                                            dateFormat: true},
//                                        ToD: {required: true,dateFormat: true,},
                                        daterangep: {required: true},
                                        activity:{required: true},
                                       },
                                    messages: {
                                        class_name: {required: "Select the class",},
                                        fromD: {required: "This field is required",
                                            dateFormat: "Date format is YYYY-MM-DD"},
                                        ToD: {required: "This field is required",
                                            dateFormat: "Date format is YYYY-MM-DD"},
                                        activity:{required: "Please Add Your Lesson Plan",},
                                      }
                                     });
                           });
                </script> 
               
                
                <!--Load Edit Lesson Plan Modal-->
                    <script> 
               $(".editLP").click(function () {
                baseurl = "http://localhost:8080/Project/";
                p_id = this.id;
                $('#editLPForm')[0].reset();
                $.ajax({
                    url: baseurl + "index.php/teacherController/editLPFormModal/" + p_id,
                    // data: {po_no: po_no},
                    dataType: 'json',
                    success: function (data) {

                        var id = data[0]["id"];
                        var act = data[0]["lesson_plan_des"];
                        var on = data[0]["added_on"];
                        var strt = data[0]["start_date"];
                        var da = data[0]["end_date"];
                        var com = data[0]["comment"];
                        var dater = data[0]["date_range"];
                        
                        $("#activity").val(act);
                        $("#fromD").val(strt);
                        $("#ToD").val(da);
                        $("#LP_id").val(id);
                        $("#add").val(on);
                        $("#comment").val(com);
                        $("#daterangep").val(dater);
                  }
                });
            });
                    </script>
                
          <script> //Delete Button for all on Data Tables
                $(document).ready(function() {
                            $("button#btnWarning").click(function(){
                              return confirm("You are going to REMOVE this delete!!");
                            }); 
                });
          </script>      
                
                
                
                
                
                
</body> 
<!-- END BODY-->
   
 
</html>

