 <!-- Script to Activate slider -->
    
     <img src="<?php echo base_url('assets/slider/engine1/arrows.png')?>"/>
     <img src="<?php echo base_url('assets/slider/engine1/bg.png')?>"/>
     <img src="<?php echo base_url('assets/slider/engine1/bullet.png')?>"/>
     <img src="<?php echo base_url('assets/slider/engine1/pause.png')?>"/>
     <img src="<?php echo base_url('assets/slider/engine1/play.png')?>"/>
     <img src="<?php echo base_url('assets/slider/engine1/triangle.png')?>"/>
     
     <script src="<?php echo base_url() . "assets/slider/engine1/script.js" ?>"></script>
     <script src="<?php echo base_url() . "assets/slider/engine1/wowslider.js" ?>"></script>
     <script src="<?php echo base_url() . "assets/slider/engine1/wowslider.mod.js" ?>"></script>
     
     <link href="<?=base_url();?>assets/slider/engine1/style.mod.css" rel="stylesheet"/>