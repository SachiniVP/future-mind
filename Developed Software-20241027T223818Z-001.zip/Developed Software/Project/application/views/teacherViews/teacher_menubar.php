<div id="left">
          
            <div class="media user-media well-small">
           
                <br />
                <div class="media-body" style="height: 80px;">
                    <h6 class="media-heading" style="color:black;font-family: calibri;font-size: medium;"><strong>Welcome</strong></h6>
                   <h5 class="media-heading" style="color:black;font-family: calibri;font-size: medium;"><strong><?php echo $teacherData[0]->t_name; ?></strong></h5>
                    
                </div>
                <br />
            </div>  
            <ul id="menu" class="collapse" style="font-weight: bolder;font-family: calibri;font-size: medium;">

                
                <li class="panel">
                    <a href="<?php echo base_url()."index.php/teacherController/teacherDashboard"?>" >
                        <i class="icon-table"></i> Dashboard                       
                    </a>                   
                </li>

<!--                <li class="panel">
                    <a href="#" data-parent="#menu" data-toggle="collapse" class="accordion-toggle" data-target="#persaonal-details-nav">
                        <i class="icon-tasks"> </i> Personal Details     
	   
                        <span class="pull-right">
                          <i class="icon-angle-left"></i>
                        </span>
                       &nbsp; <span class="label label-default">2</span>&nbsp;
                    </a>
                    <ul class="collapse" id="persaonal-details-nav" >
                       
                        <li class=""><a href="<?php echo base_url()."index.php/student/"?>"><i class="icon-angle-right"></i> Students </a></li>
                         <li class=""><a href="<?php echo base_url()."index.php/teacher/"?>"><i class="icon-angle-right"></i> Teachers </a></li>
                                                
                    </ul>
                </li>   -->
                <li class="panel">
                    <a href="#" data-parent="#menu" data-toggle="collapse" class="accordion-toggle" data-target="#school-setup-nav">
                        <i class="icon-tasks"> </i> School Settings     
	   
                        <span class="pull-right">
                          <i class="icon-angle-left"></i>
                        </span>
                       &nbsp; <span class="label label-default">3</span>&nbsp;
                    </a>
                    <ul class="collapse" id="school-setup-nav" >
                        <li class=""><a href="<?php echo base_url()."index.php/teacherController/classDetails"?>"><i class="icon-angle-right"></i> Class Details </a></li>
                         <li class=""><a href="<?php echo base_url()."index.php/teacherController/lessonPlanIndex"?>"><i class="icon-angle-right"></i> Lesson Planing </a></li>
                        <li class=""><a href="<?php echo base_url()."index.php/teacherController/evaluationIndex"?>"><i class="icon-angle-right"></i> Student Evaluation </a></li>
                         <!--<li class=""><a href="<?php echo base_url()."index.php/setUp/settings"?>"><i class="icon-angle-right"></i> Initial Set up </a></li>-->
                       
                    </ul>
                </li>  
<!--                <li class="panel">
                    <a href="<?php echo base_url()."index.php/admissions/"?>" >
                        <i class="icon-tasks"></i> Admissions                       
                    </a>                   
                </li>-->
                
<!--                <li class="panel">
                    <a href="#" data-parent="#menu" data-toggle="collapse" class="accordion-toggle" data-target="#fee-management">
                        <i class="icon-tasks"> </i> Fee Management
	   
                        <span class="pull-right"> 
                          <i class="icon-angle-left"></i>
                        </span>
                       &nbsp; <span class="label label-default">4</span>&nbsp;
                    </a>
                    <ul class="collapse" id="fee-management" >
                       
                        <li class=""><a href="<?php echo base_url()."index.php/payments/"?>"><i class="icon-angle-right"></i> Payments  </a></li>
                         <li class=""><a href="<?php echo base_url()."index.php/payments/admissionsRegistrations"?>"><i class="icon-angle-right"></i> Admissions & Registrations </a></li>
                        <li class=""><a href="<?php echo base_url()."index.php/payments/allPayments"?>"><i class="icon-angle-right"></i> All Payments </a></li>
                        
                    </ul>
                </li>-->
                <li class="panel">
                    <a href="<?php echo base_url()."index.php/teacherController/viewEventsT"?>" >
                        <i class="icon-table"></i> Events/Notifications                       
                    </a>                   
                </li>
<!--                <li class="panel">
                    <a href="#" data-parent="#menu" data-toggle="collapse" class="accordion-toggle" data-target="#msg">
                        <i class="icon-tasks"> </i>  Messages
	   
                        <span class="pull-right"> 
                          <i class="icon-angle-left"></i>
                        </span>
                       &nbsp; <span class="label label-default">2</span>&nbsp;
                    </a>
                    <ul class="collapse" id="msg" >
                       
                        <li class=""><a href=""><i class="icon-angle-right"></i> Alerts </a></li>
                         <li class=""><a href=""><i class="icon-angle-right"></i> SMS </a></li>
                        
                    </ul>
                </li>-->
<!--                <li class="panel">
                    <a href="#" data-parent="#menu" data-toggle="collapse" class="accordion-toggle" data-target="#users">
                        <i class="icon-tasks"> </i> Users
	   
                        <span class="pull-right"> 
                          <i class="icon-angle-left"></i>
                        </span>
                       &nbsp; <span class="label label-default">4</span>&nbsp;
                    </a>
                    <ul class="collapse" id="users" >
                       
                        <li class=""><a href=""><i class="icon-angle-right"></i>  </a></li>
                         <li class=""><a href=""><i class="icon-angle-right"></i>  </a></li>
                        <li class=""><a href=""><i class="icon-angle-right"></i>  </a></li>
                        <li class=""><a href=""><i class="icon-angle-right"></i>  </a></li>
                        
                    </ul>
                </li>-->
<!--                <li class="panel">
                    <a href="#" data-parent="#menu" data-toggle="collapse" class="accordion-toggle" data-target="#set">
                        <i class="icon-tasks"> </i> Tools
	   
                        <span class="pull-right"> 
                          <i class="icon-angle-left"></i>
                        </span>
                       &nbsp; <span class="label label-default">4</span>&nbsp;
                    </a>
                    <ul class="collapse" id="set" >
                       
                        <li class=""><a href=""><i class="icon-angle-right"></i>  </a></li>
                         <li class=""><a href=""><i class="icon-angle-right"></i>  </a></li>
                        <li class=""><a href=""><i class="icon-angle-right"></i>  </a></li>
                        <li class=""><a href=""><i class="icon-angle-right"></i>  </a></li>
                        
                    </ul>
                </li>-->
                          
             

            </ul>

        </div>