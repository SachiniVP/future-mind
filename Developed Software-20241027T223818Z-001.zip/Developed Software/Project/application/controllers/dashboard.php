<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class dashboard extends CI_Controller {
        function __construct() {
        parent::__construct();
        $this->load->model('Generic_model', '', TRUE);
        $this->load->model('system_model', '', TRUE);
        /*         * if (!$this->session->userdata("username")) {
          redirect(base_url() . "index.php/login");
          };* */
    }

	
	public function index()
	{
		if ($this->session->userdata('logged_in')) {

                $session_data = $this->session->userdata('logged_in');
                $group_id = $session_data['group_id'];
                $username = $session_data['username'];


                // inner if
                if ($group_id === "10") {
                    //get user info 
                    $fields = "*";//get teacher info
                    $whereArr=array("user_id" => $username);
                    $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
                 
                    $this->load->view('admin/dashboard', $data);

                } else {

                   $this->load->view('admin/accessDeniedPage');
                }
       //outer else
        } else {
            redirect('login/index');
        }
	}
}
