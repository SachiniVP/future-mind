<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class admissions extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('Generic_model', '', TRUE);
        $this->load->model('system_model', '', TRUE);
        /**if (!$this->session->userdata("username")) {
            redirect(base_url() . "index.php/login");
        };**/
        
    }
    
    public function index() {
        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];


            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['teacherData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
                
                $this->load->view('admin/admissions/admissionIndex');

           } else {
                
               $this->load->view('admin/accessDeniedPage');
            }
       //outer else
        } else {
            redirect('login/index');
        }
        
    }
    public function newAdmission() {
        $serial = $this->Generic_model->getData('serial', 'serials', array("type" => "admission"));
        $serialNo = $serial[0]->serial + 1;
        
        
        $dataArr = array(
            "admission_id" => $this->input->post("admission_id"),
            "child_name" => $this->input->post("st_name"),
            "date_of_birth" => $this->input->post("dob"),
            "schooling_year" => $this->input->post("sch_yr"),
            "gender" => $this->input->post("gender"),
            "parent_name" => $this->input->post("p_name"),
            "occupation" => $this->input->post("job"),
            "add_l1" => $this->input->post("add_L1"),
            "add_l2" => $this->input->post("add_L2"),
            "add_l3" => $this->input->post("add_L2"),
            "contact_no" => $this->input->post("tel"),
            "admission_date" => $this->input->post("app_date"),
            "NIC" => $this->input->post("parent_id"),
            "email" => $this->input->post("email"),
            "p_employer" => $this->input->post("employer"),
            "grade_name" => $this->input->post("grade"),
            "A_status"=>"Pending",
            );
//        var_dump($dataArr);die;
         $this->Generic_model->insertData('new_admission', $dataArr);
         
        $data = array("serial" => $serialNo);
        $whereArr = array("type" => "admission");
        $this->Generic_model->updateData("serials", $data, $whereArr);
         redirect (base_url());

    }
    
    
   
}


