<?php

class System_model extends CI_Model {
    
    function checklogin($dataArr) {
        //print_r($dataArr);
        $sql = 'SELECT COUNT( * ) AS numrows
		FROM login
		WHERE user_name = "' . $dataArr['user_name'] . '" AND password= "' . $dataArr['password'] . '" AND status = 0';

        $class = $this->db->query($sql);
        $COUNT = $class->row()->numrows;

        return $COUNT;
    }

    function checkClassData($dataArr) {
        //print_r($dataArr);
        $sql = 'SELECT COUNT( * ) AS numrows
		FROM class
		WHERE year_grade = "' . $dataArr['year_grade'] . '" AND name= "' . $dataArr['name'] . '" AND status = 0';

        $class = $this->db->query($sql);
        $COUNT = $class->row()->numrows;

        return $COUNT;
    }
    
        function checkGradeData($dataArr) {//availability of grade for the School
        //print_r($dataArr);
        $sql = 'SELECT COUNT( * ) AS numrows
		FROM grade
		WHERE grade_name = "' . $dataArr['grade_name'] . '" AND schooling_yr= "' . $dataArr['schooling_yr'] . '" AND status = 0';

        $class = $this->db->query($sql);
        $COUNT = $class->row()->numrows;

        return $COUNT;
    }
    
    
         function checkGrade($dataArr) { //availability of grade for the year
        //print_r($dataArr);
        $sql = 'SELECT COUNT( * ) AS numrows
		FROM year_grade
		WHERE year_grade = "' . $dataArr['year_grade'] . '" AND status = 0';

        $class = $this->db->query($sql);
        $COUNT = $class->row()->numrows;

        return $COUNT;
    }
    
    
     function checkSubjects($dataArr) { //availability of grade for the year
        //print_r($dataArr);
        $sql = 'SELECT COUNT( * ) AS numrows
		FROM subjects
		WHERE year_grade= "' . $dataArr['year_grade'] . '" AND sub_name= "' . $dataArr['sub_name'] . '" AND status = 0';

        $class = $this->db->query($sql);
        $COUNT = $class->row()->numrows;

        return $COUNT;
    }
    
    function checkClassTeacher($data) { //availability of grade for the year
        //print_r($dataArr);
        $sql = 'SELECT COUNT( * ) AS numrows
		FROM class_teacher
		WHERE class_id= "' . $data['class_id'] . '" AND teacher_id= "' . $data['teacher_id'] . '" ';

        $class = $this->db->query($sql);
        $COUNT = $class->row()->numrows;

        return $COUNT;
    }
    
    function checkRestoreClassTeacher($class_id) { //availability of grade for the year
        //print_r($dataArr);
        $sql = 'SELECT COUNT( * ) AS numrows
		FROM class_teacher
		WHERE class_id= "' . $class_id . '" AND status = 0';

        $class = $this->db->query($sql);
        $COUNT = $class->row()->numrows;

        return $COUNT;
    }

    function checkSubjectTeacher($dataArr) { //availability of grade for the year
        //print_r($dataArr);
        $sql = 'SELECT COUNT( * ) AS numrows
		FROM subject_teacher
		WHERE class_name= "' . $dataArr['class_name'] . '" AND sub_name= "' . $dataArr['sub_name']. '" AND status = 0';

        $class = $this->db->query($sql);
        $COUNT = $class->row()->numrows;

        return $COUNT;
    }
    
    
    function updateLessonPlan($dataArr) { //availability of grade for the year
        //print_r($dataArr);
        $sql = 'UPDATE lesson_plan 
                SET start_date = "' . $dataArr['start_date'] . '", end_date = "' . $dataArr['end_date'] . '",  lesson_plan_des= "' . $dataArr['lesson_plan_des'] . '"
                WHERE id = "' . $dataArr['start_date'] . '"';
        $result = $this->db->query($sql);
       return $result;
    }
    
    
    function checkApprovedSubjectLessonPClass($class_id) { //availability of grade for the year
        //print_r($dataArr);
        $sql = 'SELECT COUNT( * ) AS numrows
		FROM lesson_plan
		WHERE class_nm= "' . $class_id . '"AND approval_status="Approved" AND status = 0';

        $class = $this->db->query($sql);
        $COUNT = $class->row()->numrows;

        return $COUNT;
    }
    
    function checkRegistration($data) {
        //print_r($dataArr);
        $sql = 'SELECT COUNT( * ) AS numrows
		FROM registration
		WHERE child_id = "' . $data . '" AND status = 0';

        $class = $this->db->query($sql);
        $COUNT = $class->row()->numrows;

        return $COUNT;
    }
    
    function checkRegAvail($dataArr) {
        //print_r($dataArr);
        $sql = 'SELECT COUNT( * ) AS numrows
		FROM registration
		WHERE child_id = "' . $dataArr['child_id'] . '" AND reg_year = "' . $dataArr['reg_year'] . '"';

        $class = $this->db->query($sql);
        $COUNT = $class->row()->numrows;

        return $COUNT;
    }
    
    function checkStudentsAvail($class_id) { //availability of grade for the year
        //print_r($dataArr);
        $sql = 'SELECT COUNT( * ) AS numrows
		FROM registration
		WHERE class_name= "' . $class_id . '" AND status = 0';

        $class = $this->db->query($sql);
        $COUNT = $class->row()->numrows;

        return $COUNT;
    }
    
    function checkClassDetailTeacher($class_id) { //availability of grade for the year
        //print_r($dataArr);
        $sql = 'SELECT COUNT( * ) AS numrows
		FROM class_teacher
		WHERE class_name= "' . $class_id . '" AND status = 0';

        $class = $this->db->query($sql);
        $COUNT = $class->row()->numrows;

        return $COUNT;
    }
    
    function checkAddMarks($data) { //availability of grade for the year
        //print_r($dataArr);
        $sql = 'SELECT COUNT( * ) AS numrows
		FROM marks
		WHERE activity_id= "' . $data['activity_id'] . '" AND child_id= "' . $data['child_id'] . '"  AND status = 0';

        $class = $this->db->query($sql);
        $COUNT = $class->row()->numrows;

        return $COUNT;
    }
    
    function activityAvail($class_id) { //availability of grade for the year
        //print_r($dataArr);
        $sql = 'SELECT COUNT( * ) AS numrows
		FROM marks
		WHERE class_nm= "' . $class_id . '" AND status = 0';

        $class = $this->db->query($sql);
        $COUNT = $class->row()->numrows;

        return $COUNT;
    }
    function activityAvailStdnt($child_id) { //availability of grade for the year
        //print_r($dataArr);
        $sql = 'SELECT COUNT( * ) AS numrows
		FROM marks
		WHERE child_id= "' . $child_id . '" AND status = 0';

        $class = $this->db->query($sql);
        $COUNT = $class->row()->numrows;

        return $COUNT;
    }
    
    public function insertData($table, $data) {
        $result = $this->db->insert($table, $data);
        return $result;
    }
    
//    function getTeacherEvents() { //availability of grade for the year
//        //print_r($dataArr);
//        $sql = 'SELECT *
//                FROM events
//                ORDER BY e_date
//                WHERE status = 0 AND target_group = ALL ';
//                
//                
//        $result = $this->db->query($sql);
//       return $result;
//    }
    }



