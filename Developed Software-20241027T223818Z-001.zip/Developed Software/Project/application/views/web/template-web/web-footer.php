  <!-- Footer -->
        <footer>
            <div class="row">
                <div class="col-lg-12">
                    <p>Copyright &copy;</p>
                </div>
            </div>
        </footer>

   
    <!-- /.container -->

 
         
    <!-- jQuery -->
     <script src="<?php echo base_url() . "assets/web/jquery.js" ?>"></script>


    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url() . "assets/web/bootstrap.min.js" ?>"></script>
  
   
   
   <!-- jQueryUI -->
     <script src="<?php echo base_url() . "assets/web/jquery-ui.js" ?>"></script>
     
     
     <script src="<?php echo base_url() . "assets/web/config.js" ?>"></script>
     <!-- Insert to your webpage before the </head> -->
    <script src="<?php echo base_url();?>assets/slider/sliderengine/jquery.js"></script>
    <script src="<?php echo base_url();?>assets/slider/sliderengine/amazingslider.js"></script>
    <script src="<?php echo base_url();?>assets/slider/sliderengine/initslider-1.js"></script>
    <!-- End of head section HTML codes -->
     
     
    