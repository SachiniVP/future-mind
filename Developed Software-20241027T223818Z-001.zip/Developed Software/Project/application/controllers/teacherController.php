<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class teacherController extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('Generic_model', '', TRUE);
        $this->load->model('system_model', '', TRUE);
        /*         * if (!$this->session->userdata("username")) {
          redirect(base_url() . "index.php/login");
          };* */
    }

    public function teacherDashboard() {

        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];


            // inner if
            if ($group_id === "20") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("teacher_id" => $username);
                $data['teacherData']=$this->Generic_model->getData($fields,'teacher',$whereArr);            
                
                //other your functional codes  

                $this->load->view('teacherViews/dashboard', $data);
            } else {
                $this->load->view('admin/accessDeniedPage');
            }

            //outer else
        } else {
            redirect('login/index');
        }
    }
   //////////////////////LESSON PLANS///////////////////////// 
    public function lessonPlanIndex() {
        
        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];


            // inner if
            if ($group_id === "20") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("teacher_id" => $username);
                $data['teacherData']=$this->Generic_model->getData($fields,'teacher',$whereArr);  
//                var_dump($data); 
                $TID=$data['teacherData'][0]->teacher_id;
                $fields = "*";//get the subects to be seleceted DATA TABLE
                $whereArr=array("teacher_id"=>$TID,"status" => 0);
                $data['assigns']=$this->Generic_model->getData($fields,'subject_teacher',$whereArr); 
                $fields = "*";//Lesson Plans-Pending DATA TABLE
                $whereArr=array("teacher_id"=>$TID,"status" => 0,"approval_status"=>'Pending Approval');
                $data['records']=$this->Generic_model->getData($fields,'lesson_plan',$whereArr); 

                $this->load->view('teacherViews/lessons/index_2',$data);
            } else {
                $this->load->view('admin/accessDeniedPage');
            }

            //outer else
        } else {
            redirect('login/index');
        }
      }
    
    public function lessonPlanForm($var) {
        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];


            // inner if
            if ($group_id === "20") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("teacher_id" => $username);
                $data['teacherData']=$this->Generic_model->getData($fields,'teacher',$whereArr);  

				$id = utf8_decode(urldecode($var));
			 //   var_dump($idp);   
				 list($t_id,$suject,$class_name)= explode(":",$id);
				  $data['ids']=array($t_id,$suject,$class_name);
		//         var_dump($data['ids']);
				 $this->load->view('teacherViews/lessons/lessonPlanForm',$data);

				} else {
                $this->load->view('admin/accessDeniedPage');
            }

            //outer else
        } else {
            redirect('login/index');
        }
    }
    
    
    public function addLessonPlan() {
        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];


            // inner if
            if ($group_id === "20") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("teacher_id" => $username);
                $data['teacherData']=$this->Generic_model->getData($fields,'teacher',$whereArr);  
                                
                    $date_range = $this->input->post("daterangep", TRUE);
    //                var_dump($date_range);
                    $start_date_s = substr($date_range, 0, 10); //getting startdate from date range picker
                    $start_date = date('Y-m-d', strtotime($start_date_s));
                    
                    $class_nm = $this->input->post("class");
                    $sub_name = $this->input->post("subject");
                    $teacher_id = $this->input->post("teacher_id");

                    $fields = "*";//to check if lesson plan exists
                    $where = array("start_date <=" => $start_date, "end_date >=" => $start_date, "status" => 0, "class_nm" => $class_nm, "sub_name" => $sub_name, "teacher_id" => $teacher_id );
                    $results1=$this->Generic_model->getData($fields,'lesson_plan',$where); 
                    $count = count($results1);
//                    var_dump($count);
                    
                    if ($count > 0) { 
                            $record = array("record" => "NONO");
                            echo json_encode($record);
                        die;      
                    } else {

                    $month=date("F",strtotime($start_date));//Month of the LP
                    $year=date("Y",strtotime($start_date));//year of the LP

                    $end_date_s = substr($date_range, 13, 25);//getting end date from date picker
                    $end_date = date('Y-m-d', strtotime($end_date_s));

//				    var_dump($_POST);die;
                     $now = new DateTime();//Foreach to add classes 
                     $add_date = $now->format("Y-m-d");
                     $dataArr = array(
                            "class_nm" => $this->input->post("class"),
                            "sub_name" => $this->input->post("subject"),
                            "teacher_id" => $this->input->post("teacher_id"),
                            "approval_status" => $this->input->post("lp_status"),
                            "year" => $year,
                            "month" => $month,
                            "end_date" => $end_date,
                            "lesson_plan_des" => $this->input->post("activity"),
                            "added_on" => $add_date,
                            "start_date" => $start_date,
                            "date_range" => $date_range,
                            );
//		        var_dump($dataArr );die;
                    $result2=$this->Generic_model->insertData('lesson_plan', $dataArr);
                         
                        if ($result2){
                        $record = array("record" => 'DONE');
                        echo json_encode($record); }
                        }
//                    redirect(base_url() . 'index.php/teacherController/lessonPlanIndex');

		} else {
                $this->load->view('admin/accessDeniedPage');
            }

            //outer else
        } else {
            redirect('login/index');
        }
    }
    
    public function editLPFormModal($id) {
               if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];


            // inner if
            if ($group_id === "20") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("teacher_id" => $username);
                $data['teacherData']=$this->Generic_model->getData($fields,'teacher',$whereArr);  

		$id_n = utf8_decode(urldecode($id));
                $fields = array("lesson_plan_des", "added_on","id","start_date","end_date","comment","date_range");
                $whereArr = array("id" => $id_n);
                $result = $this->Generic_model->getData($fields, 'lesson_plan', $whereArr);
//                var_dump($result);die;
                echo json_encode($result);

				} else {
                $this->load->view('admin/accessDeniedPage');
            }

            //outer else
        } else {
            redirect('login/index');
        }

                }
       public function editLPForm() {
        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];


            // inner if
            if ($group_id === "20") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("teacher_id" => $username);
                $data['teacherData']=$this->Generic_model->getData($fields,'teacher',$whereArr);  

			
                $id = $this->input->post("LP_id", TRUE);
                $date_range = $this->input->post("daterangep", TRUE);
                //                var_dump($date_range);
                $start_date_s = substr($date_range, 0, 10); //getting startdate from date range picker
                $start_date = date('Y-m-d', strtotime($start_date_s));
                $month=date("F",strtotime($start_date));//Month of the LP
                $year=date("Y",strtotime($start_date));//year of the LP

                $end_date_s = substr($date_range, 13, 25);//getting end date from date picker
                $end_date = date('Y-m-d', strtotime($end_date_s));
                
                $dataArr = array(
                    "lesson_plan_des" => $this->input->post("activity"),
                    "added_on" => $this->input->post("add"),
                    "date_range" => $date_range,
                    "year" => $year,
                    "month" => $month,
                    "end_date" => $end_date,
                    "start_date" => $start_date,
                    );
//                var_dump($dataArr);die;
                $whereArr = array("id" => $id);
                $this->Generic_model->updateData("lesson_plan", $dataArr, $whereArr);
                redirect(base_url() . 'index.php/teacherController/lessonPlanIndex');

				} else {
                $this->load->view('admin/accessDeniedPage');
            }

            //outer else
        } else {
            redirect('login/index');
        }
        }
            
        public function deleteLessonPlan($id) { //add grades for the School
                    if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];


            // inner if
            if ($group_id === "20") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("teacher_id" => $username);
                $data['teacherData']=$this->Generic_model->getData($fields,'teacher',$whereArr);  

				$dataArr=array("status"=>1);//delete Student
				$WhereArr=array('id'=>$id);
			   
				$this->Generic_model->updateData("lesson_plan",$dataArr,$WhereArr);
				
			   redirect(base_url() . 'index.php/teacherController/lessonPlanIndex');
                       
					   } else {
                $this->load->view('admin/accessDeniedPage');
            }

            //outer else
        } else {
            redirect('login/index');
        }
     }
        
        public function approvedLPs($var) {
            if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];


            // inner if
            if ($group_id === "20") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("teacher_id" => $username);
                $data['teacherData']=$this->Generic_model->getData($fields,'teacher',$whereArr);  

				 $id = utf8_decode(urldecode($var));
              //   var_dump($idp);   
              list($t_id,$suject,$class_name)= explode(":",$id);
               $data['ids']=array($t_id,$suject,$class_name);
     //         var_dump($data['ids']);
           $fields = '*';
           $whereArr = array("teacher_id" => $t_id,"sub_name" =>$suject,"class_nm" =>$class_name,"approval_status" =>'Approved',"status"=>0);
           $data['approved']=$this->Generic_model->getData($fields,'lesson_plan',$whereArr);
           $this->load->view('teacherViews/lessons/approvedLessonPlans',$data);
                       
					   } else {
                $this->load->view('admin/accessDeniedPage');
            }

            //outer else
        } else {
            redirect('login/index');
        }
         }
         
          public function viewLPFormModal($id) {
            if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "20") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("teacher_id" => $username);
                $data['teacherData']=$this->Generic_model->getData($fields,'teacher',$whereArr);     
               
			     $id_n = utf8_decode(urldecode($id));
               $fields = array("lesson_plan_des","comment");
                $whereArr = array("id" => $id_n);
                $result = $this->Generic_model->getData($fields, 'lesson_plan', $whereArr);
                echo json_encode($result);  
			
			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
                //outer else
                } else {
                        redirect('login/index');
                }

                }
         
/////////////////////////CLASS DETAILS///////////////////////      
         public function classDetails() {
        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];


            // inner if
            if ($group_id === "20") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("teacher_id" => $username);
                $data['teacherData']=$this->Generic_model->getData($fields,'teacher',$whereArr);  
		
                  $TID=$data['teacherData'][0]->teacher_id;
				$fields = array("class_name");//get the teacher name to select
					$whereArr=array("teacher_id"=>$TID,"status" => 0);
					$data['clz']=$this->Generic_model->getData($fields,'subject_teacher',$whereArr); 
				  
					$this->load->view('teacherViews/classDetails',$data);


                       
                                    } else {
                         $this->load->view('admin/accessDeniedPage');
                 }

                 //outer else
         } else {
                 redirect('login/index');
         }
       }
    
             public function classDetailsStudentList($class_idp) { //to load subjects to the form //JQUERY
             if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];


            // inner if
            if ($group_id === "20") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("teacher_id" => $username);
                $data['teacherData']=$this->Generic_model->getData($fields,'teacher',$whereArr);  
				
				                 // var_dump($class_id);die;
                     $class_id = utf8_decode(urldecode($class_idp));
          //           var_dump($class_id);die;

                                  $fields=array(       //data table
                                    "child.child_id", 
                                    "first_name",
                                    "last_name",
                                    "date_of_birth",
                                    "middle_name", 
                                    "child_tel_no",
                                    "reg_date",
                                    );
                                 $wherefieldtablefrom = array('child.child_status'=>0,'registration.class_name'=>$class_id,'registration.status'=>0);
                                 $tablefrom = 'child';
                                 $tablejoin = 'registration';
                                 $tablejoincondition = 'child.child_id = registration.child_id';
                                 $result =  $this->Generic_model->join($fields, $wherefieldtablefrom, $tablefrom, $tablejoin, $tablejoincondition);
                        //                      var_dump($result);die;
                                   $record = array("record" =>$result, "rec1"=> $class_id);
                        //                   var_dump($record);die;
                                   echo json_encode($record);

                       
                        } else {
                 $this->load->view('admin/accessDeniedPage');
                     }
             //outer else
             } else {
                     redirect('login/index');
             }
          }
///////////////////////////////////EVALUATON///////////////////////////////////
            public function evaluationIndex() {
                if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];
              // inner if
            if ($group_id === "20") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("teacher_id" => $username);
                $data['teacherData']=$this->Generic_model->getData($fields,'teacher',$whereArr);  
		
                $TID=$data['teacherData'][0]->teacher_id;
//		$TName = $this->input->post("TName");
//                list($t_id,$tname)= explode(":",$TName);
//                $data['tname']=$tname;

                $fields = "*";//get the subects to be seleceted DATA TABLE
                $whereArr=array("teacher_id"=>$TID,"status" => 0);
                $data['assigns']=$this->Generic_model->getData($fields,'subject_teacher',$whereArr); 

                $fields = "*";//show activities DATA TABLE
                $whereArr=array("teacher_id"=>$TID,"status" => 0);
                $data['records']=$this->Generic_model->getData($fields,'activities',$whereArr); 

                $this->load->view('teacherViews/evaluation/evaluationIndex',$data);

                       
			   } else {
		$this->load->view('admin/accessDeniedPage');
	}

                                //outer else
                        } else {
                                redirect('login/index');
                        }
           }
           
           
           
           
       public function addActivityForm($var) {
        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];
             // inner if
            if ($group_id === "20") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("teacher_id" => $username);
                $data['teacherData']=$this->Generic_model->getData($fields,'teacher',$whereArr);  
				
				$id = utf8_decode(urldecode($var));
				 //   var_dump($idp);   
				 list($t_id,$suject,$class_name)= explode(":",$id);
				 $data['ids']=array($t_id,$suject,$class_name);
				// var_dump($data['ids']);
				 $this->load->view('teacherViews/evaluation/addActivityForm',$data);

                       
			   } else {
		$this->load->view('admin/accessDeniedPage');
                    }

                    //outer else
            } else {
                    redirect('login/index');
            }
        }
    
        public function addActivity() {
         if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];
            // inner if
            if ($group_id === "20") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("teacher_id" => $username);
                $data['teacherData']=$this->Generic_model->getData($fields,'teacher',$whereArr);  
				
				//    var_dump($_POST);
                        $start_date = $this->input->post("fromD");
                        $month=date("F",strtotime($start_date));//Month of the LP
                        $year=date("Y",strtotime($start_date));//year of the LP
                
                        $now = new DateTime();
                        $add_date = $now->format("Y-m-d");
                        $dataArr = array(
                           "class_nm" => $this->input->post("class"),
                           "sub_name" => $this->input->post("subject"),
                           "teacher_id" => $this->input->post("teacher_id"),
                           "act_name" => $this->input->post("act_name"),
                           "year" => $year,
                           "month" => $month,
                           "activity_des" => $this->input->post("activity"),
                           "added_on" => $add_date,
                           "effect_date" => $start_date,
                           );
//                       var_dump($dataArr ); die;
                       $this->Generic_model->insertData('activities', $dataArr);
                       redirect(base_url() . 'index.php/teacherController/evaluationIndex');
              } else {
                           $this->load->view('admin/accessDeniedPage');
                   }
                  //outer else
            } else {
                    redirect('login/index');
            }
        }

         public function editActivityFormModal($id) {
                   if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "20") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("teacher_id" => $username);
                $data['teacherData']=$this->Generic_model->getData($fields,'teacher',$whereArr);  
				
				 $id_n = utf8_decode(urldecode($id));
                 $fields = array("act_name", "added_on","id","effect_date","activity_des",);
                 $whereArr = array("id" => $id_n);
                 $result = $this->Generic_model->getData($fields, 'activities', $whereArr);
    //                var_dump($result);die;
                 echo json_encode($result);
	                   
			   } else {
		$this->load->view('admin/accessDeniedPage');
                }
                    //outer else
            } else {
                    redirect('login/index');
            }
         }
            public function editActivityModal() {
    if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "20") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("teacher_id" => $username);
                $data['teacherData']=$this->Generic_model->getData($fields,'teacher',$whereArr);  
				
				//              var_dump($_POST);die;
                    $id = $this->input->post("LP_id", TRUE);
                    
                    $start_date = $this->input->post("fromD");
                    $month=date("F",strtotime($start_date));//Month of the LP
                    $year=date("Y",strtotime($start_date));//year of the LP
                    
                    $dataArr = array(
                        "activity_des" => $this->input->post("activity"),
                        "added_on" => $this->input->post("add"),
                        "effect_date" => $start_date,
                        "act_name" => $this->input->post("actN"),
                        "year" => $year,
                        "month" => $month,
                        );
                      $whereArr = array("id" => $id);
//                      var_dump($dataArr);die;
    //                  var_dump($whereArr);
                    $this->Generic_model->updateData("activities", $dataArr, $whereArr);
                    redirect(base_url() . 'index.php/teacherController/evaluationIndex');
	                   
			   } else {
		$this->load->view('admin/accessDeniedPage');
                }
                    //outer else
            } else {
                    redirect('login/index');
            }
            }

            public function deleteEvalActivity($id) { 
                        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "20") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("teacher_id" => $username);
                $data['teacherData']=$this->Generic_model->getData($fields,'teacher',$whereArr);  
				
				$dataArr=array("status"=>1);//delete Student
				$WhereArr=array('id'=>$id);

				$this->Generic_model->updateData("activities",$dataArr,$WhereArr);

			   redirect(base_url() . 'index.php/teacherController/evaluationIndex');
	                   
			   } else {
		$this->load->view('admin/accessDeniedPage');
                            }
                            //outer else
                    } else {
                            redirect('login/index');
                    }
          }      

            public function addMarksForm($var) {
            if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "20") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("teacher_id" => $username);
                $data['teacherData']=$this->Generic_model->getData($fields,'teacher',$whereArr);  
                $TID=$data['teacherData'][0]->teacher_id;
				
                        $id = utf8_decode(urldecode($var));
//            var_dump($idp);  die; 
                        list($actvity_id,$class_name)= explode(":",$id);

                       $fields = '*';//get activity data load to form
                       $whereArr = array("id" =>$actvity_id);
                       $data['act']=$this->Generic_model->getData($fields,'activities',$whereArr);

                       $fields1 = '*';//get activity data load to form
                       $data['level']=$this->Generic_model->getData($fields,'rubrics');

                        $fields=array(      //Students List to load to form
                               "child.child_id", 
                               "first_name",
                               "last_name",
                                       );
                        $wherefieldtablefrom = array('child.child_status'=>0,'registration.class_name'=>$class_name,'registration.status'=>0);
                        $tablefrom = 'child';
                        $tablejoin = 'registration';
                        $tablejoincondition = 'child.child_id = registration.child_id';
                        $data['students'] =  $this->Generic_model->join($fields, $wherefieldtablefrom, $tablefrom, $tablejoin, $tablejoincondition);
   
                        $fields=array(      //Students List to load to data table
                               "child.child_id", 
                               "first_name",
                               "last_name","level","comment","id","score",
                                       );
                        $wherefieldtablefrom = array('child.child_status'=>0,'marks.status'=>0,'marks.teacher_id'=>$TID,"marks.activity_id" =>$actvity_id);
                        $tablefrom = 'child';
                        $tablejoin = 'marks';
                        $tablejoincondition = 'child.child_id = marks.child_id';
                        $data['marks_table'] =  $this->Generic_model->join($fields, $wherefieldtablefrom, $tablefrom, $tablejoin, $tablejoincondition);
                        
                       $fields = '*';//get activity data load to form
                       $whereArr = array("id" =>$actvity_id);
                       $data['act']=$this->Generic_model->getData($fields,'activities',$whereArr);
                        
                      $this->load->view('teacherViews/evaluation/addMarksForm',$data);

                           } else {
                $this->load->view('admin/accessDeniedPage');
                 }
                 //outer else
         } else {
                 redirect('login/index');
                }
        }  

             public function addMarks() {

            if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "20") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("teacher_id" => $username);
                $data['teacherData']=$this->Generic_model->getData($fields,'teacher',$whereArr);  
				
		    $activity_id = $this->input->post("activity_id");      
                    $child_id = $this->input->post("SId");      
                    $data=array('activity_id'=>$activity_id,"child_id" =>$child_id);//to Check Availability for Updation      
                  
                    $checkavailabilty = $this->system_model->checkAddMarks($data);
                if ($checkavailabilty > 0) { 
                    $record = array("record" => "NONO");
                    echo json_encode($record);
                    die;      
                }
                          
                else {          
                    $level = $this->input->post("Level", TRUE);
                    list($levelN,$score)=explode(":",$level);
                    $dataArr = array(
                        "class_nm" => $this->input->post("class"),
                        "sub_name" => $this->input->post("subject"),
                        "child_id" => $this->input->post("SId"),
                        "teacher_id" => $this->input->post("teacher_id"), 
                        "activity_id" => $this->input->post("activity_id"), 
                        "activity_name" => $this->input->post("act_name"),
                        "level" => $levelN,
                        "score" => $score,
                        "comment" => $this->input->post("comment"),
                        "e_date" => $this->input->post("e_date"),
                        );
//                    var_dump($dataArr);
                    $this->Generic_model->insertData('marks', $dataArr);
                    $record = array("record" => "DONE");
                    echo json_encode($record);
                    }
	                   
			   } else {
		$this->load->view('admin/accessDeniedPage');
                                }
                        //outer else
                } else {
                        redirect('login/index');
                    }
                }   
                
                public function editAddMarksFormModal($id) {
                if ($this->session->userdata('logged_in')) {

                $session_data = $this->session->userdata('logged_in');
                $group_id = $session_data['group_id'];
                $username = $session_data['username'];

            // inner if
            if ($group_id === "20") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("teacher_id" => $username);
                $data['teacherData']=$this->Generic_model->getData($fields,'teacher',$whereArr);           
               
			     $id = utf8_decode(urldecode($id));
//          var_dump($id);
                $fields =array('activity_name','id','comment');
                $whereArr = array("id" => $id);
                $result1 = $this->Generic_model->getData($fields, 'marks', $whereArr); 
//                var_dump( $result); 
            
                $fields = array("r_title", "score");//get the teacher name
//                $whereArr = array("status" => 0);
                $result2 = $this->Generic_model->getData($fields, 'rubrics');
           // var_dump( $result1);
                                
                $record = array("record_1" => $result1, "record_2" => $result2);
                echo json_encode($record);
			
            } else {
                      $this->load->view('admin/accessDeniedPage');
                   }
      //outer else
           } else {
                   redirect('login/index');
           }
        }
        
         public function editAddMarks() {
        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "20") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("teacher_id" => $username);
                $data['teacherData']=$this->Generic_model->getData($fields,'teacher',$whereArr);  
				
				//                           var_dump($_POST);
                    $edit_level = $this->input->post("edit_level", TRUE);
                    list($score,$levelN)=explode(":",$edit_level);
                    $marks_id = $this->input->post("marks_id");
                    
                    $dataArr = array(
                    "level" => $levelN,
                    "score" => $score,
                    "comment" => $this->input->post("edit_comment"),
                    );
                  $whereArr = array("id" => $marks_id);
                    $this->Generic_model->updateData("marks", $dataArr, $whereArr);
                    redirect(base_url() . 'index.php/teacherController/evaluationIndex');
				
	                   
			   } else {
		$this->load->view('admin/accessDeniedPage');
                        }
                        //outer else
                } else {
                        redirect('login/index');
                }
            }
       
         public function deleteAddMarks($id) { //add grades for the School
                    if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];


            // inner if
            if ($group_id === "20") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("teacher_id" => $username);
                $data['teacherData']=$this->Generic_model->getData($fields,'teacher',$whereArr);  

				$dataArr=array("status"=>1);//delete Student
				$WhereArr=array('id'=>$id);
			   
				$this->Generic_model->updateData("marks",$dataArr,$WhereArr);
				
			   redirect(base_url() . 'index.php/teacherController/evaluationIndex');
                       
					   } else {
                $this->load->view('admin/accessDeniedPage');
            }
     //outer else
        } else {
            redirect('login/index');
        }
     }
//////////////////////////////////////////EVENTS/////////////////////////////////////////////
     
     public function showEventsT() {

        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];


            // inner if
            if ($group_id === "20") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("teacher_id" => $username);
                $data['teacherData']=$this->Generic_model->getData($fields,'teacher',$whereArr);            
                
                    $now = new DateTime();
                    $today = $now->format("Y-m-d");
                    
                  $fields = "*";//get events
                    $where=array("status" => 0,"target_group <>"=>'PARENTS ONLY',"e_date >=" => $today);
                    $asc_field = 'e_date';
                   $result['all']=$this->Generic_model->getDataSortAsc($fields,'events',$where,$asc_field); 

                   if(count($result)>0){
                    $record = array("record" =>$result, "recd"=> 'YES');
                    echo json_encode($record);
                    die;
//                                              var_dump($record);die;
                }else{
                    $record = array("recd"=> 'NONO');
                    echo json_encode($record);
                }

            } else {
                $this->load->view('admin/accessDeniedPage');
            }

            //outer else
        } else {
            redirect('login/index');
        }
    }
     
     public function viewEventsT() {

        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];


            // inner if
            if ($group_id === "20") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("teacher_id" => $username);
                $data['teacherData']=$this->Generic_model->getData($fields,'teacher',$whereArr);            
                
//                $fields = "*";//get all events 
//                $whereArr=array("status" => 0,"target_group <>"=>'PARENTS ONLY');
//                $asc_field = 'e_date';
//                $data['AllEvents']=$this->Generic_model->getDataSortAsc($fields,'events',$where,$asc_field);
//                $this->load->view('teacherViews/manageEventsT',$data);
                
                $fields = "*";//get teacher info
                $whereArr=array("status" => 0,"target_group <>"=>'PARENTS ONLY');
                $data['AllEvents']=$this->Generic_model->getData($fields,'events',$whereArr);
                $this->load->view('teacherViews/manageEventsT',$data);

            } else {
                $this->load->view('admin/accessDeniedPage');
            }

            //outer else
        } else {
            redirect('login/index');
        }
    }
     
     
     
     
     
     
     
        }

