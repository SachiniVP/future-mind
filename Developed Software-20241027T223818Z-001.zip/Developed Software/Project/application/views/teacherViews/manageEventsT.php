
<!DOCTYPE html>
<!--Administrator Dashboard-->

   
<!-- BEGIN HEAD-->
<head>
       
    <title>Manage Events</title>
    <?php echo $this->load->view('admin_panel/template/header'); ?>
    <!-- PAGE LEVEL STYLES -->
    <link href="<?=base_url();?>assets/admin_assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
    <!-- END PAGE LEVEL  STYLES -->
</head>
<!-- END  HEAD-->    
   
    
    <!-- BEGIN BODY-->
<body class="padTop53" >

     <!-- MAIN WRAPPER -->
    <div id="wrap" style="background-color:#b8b8b8;">
        <!--HEADER SECTION -->
         <?php echo $this->load->view('admin_panel/template/navbar'); ?>
        <!-- END HEADER SECTION -->
        


        <!-- MENU SECTION -->
          <?php echo $this->load->view('teacherViews/teacher_menubar'); ?>
        <!--END MENU SECTION -->


        <!--PAGE CONTENT -->
        <div id="content" >
            
            <div class="inner" style="min-height:1200px;background-color:transparent">
                <!---breadcrumb--->
                <div class="row">
                    <div class="col-md-12">
                        <div class="col-lg-12">
                            <div class="well-sm">
                                <div style="">
                                    <ul class="breadcrumb"  >
                                     <li> <a href="<?php echo base_url()."index.php/teacherController/teacherDashboard"?>"> Dashboard </a> </li>
                                    <li class="active"> Events & Notifications </li>
                                     </ul>
                                </div>    
                            </div>
                        </div> <!-- /.col-lg-12 --> 
                    </div> <!-- /.col-md-12 -->
                </div><!-- /.row -->
                <!---END breadcrumb--->
                
                
                
                
                <div class="well col-lg-12" style=" background-color: transparent;"> 
                  <div class="row"><!--Class Teacher DataTable--> 
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"> 
                        <div container='fluid'> 
                            <div class="well well-lg">
                                <div class="panel-body"> <!--DataTable-->
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered table-hover" id="dataTables-example" class="display" cellspacing="0" width="100%"> 
                                            <thead>
                                                <tr>
                                                    <th>Header</th>
                                                    <th>Description</th>
                                                    <th>Target</th>
                                                    <!--<th>Added By</th>-->
                                                    <th>Event Date</th>
                                                    
                                                </tr>
                                            </thead>
                                            <tbody center>
                                                <?php
                                                foreach ($AllEvents as $userItem) {
                                                    echo "<tr>";
                                                    echo "<td>" . $userItem->header . "</td>";
                                                    echo "<td>" . $userItem->description . "</td>";
                                                    echo "<td>" . $userItem->target_group . "</td>";
//                                                    echo "<td>" . $userItem->added_by . "</td>";
                                                    echo "<td>" . $userItem->e_date . "</td>";
                                                    }
                                                ?>  
                                            </tbody>
                                        </table>
                                    </div>
                                </div><!--Data TAble-->                          
                            </div>
                        </div> 
                    </div>
                </div><!--Class Teacher DataTable--><!-- END Class Teacher-->
                </div> 
              
            </div>
                         
              
                     
            </div><!--END PAGE CONTENT -->
            
            
            
         </div><!--END MAIN WRAPPER -->
    
    
            <!-- PAGE LEVEL SCRIPTS -->
                <?php echo $this->load->view('admin_panel/template/footer'); ?>
            
            
             <script> //Delete Button for all on Data Tables
                $(document).ready(function() {
                            $("button#btnWarning").click(function(){
                              return confirm("You are going to REMOVE this record!!");
                            }); 
                });
                </script>
                
            <script src="<?=base_url();?>assets/admin_assets/plugins/dataTables/jquery.dataTables.js"></script>
            <script src="<?=base_url();?>assets/admin_assets/plugins/dataTables/dataTables.bootstrap.js"></script>
            <script>
                 $(document).ready(function () {
                     $('#dataTables-example').dataTable();
                 });
            </script>    
            
            
                

</body> 
<!-- END BODY-->
   
 
</html>

