<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class setUp extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('Generic_model', '', TRUE);
        $this->load->model('system_model', '', TRUE);
        /**if (!$this->session->userdata("username")) {
            redirect(base_url() . "index.php/login");
        };**/
        
    }
    
    public function index() {
                if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];


            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);               
//                var_dump($data);
                $this->load->view('admin/School/index',$data);

            } else {
                
               $this->load->view('admin/accessDeniedPage');
            }
       //outer else
        } else {
            redirect('login/index');
        }
    }
    
    public function settings() {
        
                if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];


            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
                
               $fields = "grade_name";//get the grade names to add ACademicYear
                $whereArr=array("status" => 0);
                $data['GradeData']=$this->Generic_model->getData($fields,'grade',$whereArr); 
        //        var_dump($data);die;

                $fields ='*';//To Display in DataTable Class
                $whereArr=array("status" => 0);
                $data['class']=$this->Generic_model->getData($fields,'class',$whereArr); 

                $fields ='*';//To Display in DataTable Year_Grade
                $whereArr=array("status" => 0);
                $data['year_grade']=$this->Generic_model->getData($fields,'year_grade',$whereArr); 

                $fields ='*';//To Display in DataTable Subjects
                $whereArr=array("status" => 0);
                $data['subjects']=$this->Generic_model->getData($fields,'subjects',$whereArr); 

                $fields ='*';//To Display in DataTable Grades
                $whereArr1=array("status" => 0);

                $data['grade']=$this->Generic_model->getData($fields,'grade',$whereArr); 

                $now = new DateTime();//Foreach to add classes 
                $year = $now->format("Y");
                $fields ="year_grade";
                $whereArr=array("year" => $year);
                $data['Current_year_grade']=$this->Generic_model->getData($fields,'year_grade',$whereArr);
        //        var_dump($data['grade']);die;


                $this->load->view('admin/School/InitialSetUp/settings',$data);

            } else {
                
               $this->load->view('admin/accessDeniedPage');
            }
       //outer else
        } else {
            redirect('login/index');
        }
    }
    
                public function add_grade() { //add grades for the School
                   if ($this->session->userdata('logged_in')) {

                        $session_data = $this->session->userdata('logged_in');
                        $group_id = $session_data['group_id'];
                        $username = $session_data['username'];


                        // inner if
                        if ($group_id === "10") {
                            //get user info 
                            $fields = "*";//get teacher info
                            $whereArr=array("user_id" => $username);
                            $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            

                            $dataArr = array(
                        "grade_name" => $this->input->post("grade_name"),
                        "schooling_yr" => $this->input->post("description"),
                        );
                    $checkavailabilty = $this->system_model->checkGradeData($dataArr);
                            if ($checkavailabilty > 0) {
                               redirect(base_url().'/index.php/setUp/settings'); 

                            } else {
                               $this->Generic_model->insertData('grade', $dataArr);
                               redirect(base_url().'/index.php/setUp/settings');
                            }

                        } else {

                           $this->load->view('admin/accessDeniedPage');
                        }
                   //outer else
                    } else {
                        redirect('login/index');
                    }
                }

                public function editGradeManageForm($id) {
                       if ($this->session->userdata('logged_in')) {

                        $session_data = $this->session->userdata('logged_in');
                        $group_id = $session_data['group_id'];
                        $username = $session_data['username'];


                        // inner if
                        if ($group_id === "10") {
                            //get user info 
                            $fields = "*";//get teacher info
                            $whereArr=array("user_id" => $username);
                            $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            

                            $id_n = utf8_decode(urldecode($id));
                        //           var_dump($id_n);die;
                                        $fields = array("grade_name", "schooling_yr","id");
                                        $whereArr = array("id" => $id_n);
                                        $result = $this->Generic_model->getData($fields, 'grade', $whereArr);
                                       //var_dump($result);
                                        echo json_encode($result);

                        } else {

                           $this->load->view('admin/accessDeniedPage');
                        }
                   //outer else
                    } else {
                        redirect('login/index');
                    }

                }
    
               public function editGradeManage() {
//            var_dump($_POST);die;
              if ($this->session->userdata('logged_in')) {

                $session_data = $this->session->userdata('logged_in');
                $group_id = $session_data['group_id'];
                $username = $session_data['username'];


                // inner if
                if ($group_id === "10") {
                    //get user info 
                    $fields = "*";//get teacher info
                    $whereArr=array("user_id" => $username);
                    $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            


                    $ID = $this->input->post("id_edgrdf", TRUE);
                    $grade_name = $this->input->post("grade_name_apnd", TRUE);
                    $des = $this->input->post("des", TRUE);
                    
                    if (!isset($grade_name) || trim($grade_name) != '') {
                        
                    $dataArr = array(
    //                    "id" => $ID,
                        "grade_name" => $grade_name,
                        "schooling_yr" => $des
                    );
                    $checkavailabilty = $this->system_model->checkGradeData($dataArr);
                    if ($checkavailabilty > 0) {
                        $record = array("record" => "NONO", "grade_name" => $grade_name, "des" => $des, "id" => $ID);
                        echo json_encode($record);
                    } else {
                        $whereArr = array("id" => $ID);
                        $result = $this->Generic_model->updateData("grade", $dataArr, $whereArr);

                        $record = array("record1" => $result, "grade_name" => $grade_name, "des" => $des, "id" => $ID);
                          echo json_encode($record);
                    }
                }

                } else {
                       $this->load->view('admin/accessDeniedPage');
                       }
          //outer else
               } else {
                       redirect('login/index');
               }
             }
    
      
                public function delete_grade($id) { //add grades for the School
                     if ($this->session->userdata('logged_in')) {

                    $session_data = $this->session->userdata('logged_in');
                    $group_id = $session_data['group_id'];
                    $username = $session_data['username'];


                    // inner if
                    if ($group_id === "10") {
                        //get user info 
                        $fields = "*";//get teacher info
                        $whereArr=array("user_id" => $username);
                        $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            

                                        $data=array("status"=>1);//delete Student
                            $WhereArr=array('id'=>$id);

                            $this->Generic_model->updateData("grade",$data,$WhereArr);

                            redirect(base_url().'/index.php/setUp/settings');


			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
		   //outer else
			} else {
				redirect('login/index');
			}
                }

    
    
    
    
     public function add_grades_year() { //add grades for a particular year
        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];


            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
			   $yr=$this->input->post("yr"); 
                $grade=$this->input->post("grade");
                $yr_grade=$yer.'-'.$grade;
                //var_dump($yr2);
                $dataArr = array(
                    "year" => $this->input->post("yr"),
                    "grade" => $this->input->post("grade"),
                    "year_grade" => $yr_grade,
                     );
                   // var_dump($dataArr);die;  
               $checkavailabilty = $this->system_model->checkGrade($dataArr);
                if ($checkavailabilty > 0) {
                   redirect(base_url().'/index.php/setUp/settings'); 
                    
                } else {
                   $this->Generic_model->insertData('year_grade', $dataArr);
                   redirect(base_url().'/index.php/setUp/settings');
                }
			
            } else {
                    $this->load->view('admin/accessDeniedPage');
                   }
      //outer else
           } else {
                   redirect('login/index');
           }
    }
    
    public function deleteGradesYear($id) { //add grades for the School
                if ($this->session->userdata('logged_in')) {

                    $session_data = $this->session->userdata('logged_in');
                    $group_id = $session_data['group_id'];
                    $username = $session_data['username'];


                    // inner if
                    if ($group_id === "10") {
                        //get user info 
                        $fields = "*";//get teacher info
                        $whereArr=array("user_id" => $username);
                        $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            

                                   $idp = utf8_decode(urldecode($id));
                $data=array("status"=>1);//delete Student
                $WhereArr=array('year_grade'=>$idp);

                $this->Generic_model->updateData("year_grade",$data,$WhereArr);

                redirect(base_url().'/index.php/setUp/settings');
			
            } else {
                   $this->load->view('admin/accessDeniedPage');
                   }
      //outer else
           } else {
                   redirect('login/index');
           }

    }

    
    public function add_classes() { //add classes for a particular year
         if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];


            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
			   $class_name=$this->input->post("class_name"); 
                $yr_grade = $this->input->post("current_year_grade");
                $class_name_new = $yr_grade.'-'.$class_name;
                $dataArr = array(
                    "year_grade" => $yr_grade,
                    "class_name" => $class_name_new,
                    "name"=> $class_name,
                    );
                $checkavailabilty = $this->system_model->checkClassData($dataArr);
                if ($checkavailabilty > 0) {
                   redirect(base_url().'/index.php/setUp/settings'); 
                    
                } else {
                   $this->Generic_model->insertData('class', $dataArr);
                   redirect(base_url().'/index.php/setUp/settings');
                }
          } else {
                $this->load->view('admin/accessDeniedPage');
               }
  //outer else
       } else {
               redirect('login/index');
       }

    }
        
        public function editClassForm($id) {
            if ($this->session->userdata('logged_in')) {

                $session_data = $this->session->userdata('logged_in');
                $group_id = $session_data['group_id'];
                $username = $session_data['username'];


            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
			   $class_id = utf8_decode(urldecode($id));
//           var_dump($class_id);idie;
                $fields = array("class_name", "year_grade","name","id");
                $whereArr = array("class_name" => $class_id);
                $result = $this->Generic_model->getData($fields, 'class', $whereArr);
//                var_dump($result);die;
                echo json_encode($result);
			
            } else {
                  $this->load->view('admin/accessDeniedPage');
                   }
      //outer else
           } else {
                   redirect('login/index');
           }

    }   
           public function editClass() {
            if ($this->session->userdata('logged_in')) {

                        $session_data = $this->session->userdata('logged_in');
                        $group_id = $session_data['group_id'];
                        $username = $session_data['username'];


                        // inner if
                        if ($group_id === "10") {
                            //get user info 
                            $fields = "*";//get teacher info
                            $whereArr=array("user_id" => $username);
                            $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            

                                       //              var_dump($_POST);
                            $grade_name = $this->input->post("apnd", TRUE);
                            $name = $this->input->post("clz_name", TRUE);
                            $class_name = $grade_name.'-'.$name;
                            $id = $this->input->post("id_gn", TRUE);
                            
                            if (!isset($name) || trim($name) != '') {
                            $dataArr = array(
                                "id" => $this->input->post("id_gn", TRUE),
                                "year_grade" => $grade_name,
                                "name" => $name,
                                "class_name" => $class_name,
                            );
                             $checkavailabilty = $this->system_model->checkClassData($dataArr);
                            if ($checkavailabilty > 0) {
                                $record = array("record" => "NONO", "year_grade" => $grade_name, "class_name" => $class_name, "id" => $id);
                                echo json_encode($record);
                            } else {
                                $whereArr = array("id" => $id);
                                $result = $this->Generic_model->updateData("class", $dataArr, $whereArr);

                                $record = array("record1" => $result, "year_grade" => $grade_name, "class_name" => $class_name, "id" => $id);
                                echo json_encode($record);
                            }
                              }

                        } else {

                                  $this->load->view('admin/accessDeniedPage');
                               }
                  //outer else
                       } else {
                               redirect('login/index');
                       }            
                }

            public function deleteClasses($id) { //add grades for the School
            if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
			    $idp = utf8_decode(urldecode($id));
    //            var_dump($idp);die;    
            $data=array("status"=>1);//delete Student
            $WhereArr=array('id'=>$idp);

            $this->Generic_model->updateData("class",$data,$WhereArr);

            redirect(base_url().'/index.php/setUp/settings');
			
			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
		   //outer else
			} else {
				redirect('login/index');
			}
    }

    
    
    public function add_subjects() { //add SUBJECT for GRADES
    if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
		$year_grade=$this->input->post("current_year_grade"); 
                $sub_name = $this->input->post("subject");
                $sub_id= $year_grade.'-'.$sub_name;
                $dataArr = array(
                        "year_grade" => $year_grade,
                        "sub_name" => $sub_name,
                        "sub_id" => $sub_id,
                        );
                $checkavailabilty = $this->system_model->checkSubjects($dataArr);
                    if ($checkavailabilty > 0) {
                       redirect(base_url().'/index.php/setUp/settings'); 

                    } else {
                       $this->Generic_model->insertData('subjects', $dataArr);
                        redirect(base_url().'/index.php/setUp/settings');
                      }


                 } else {
                           $this->load->view('admin/accessDeniedPage');
                        }
           //outer else
                } else {
                        redirect('login/index');
                }   
     }
    
     public function editSubjectForm($id) {
           if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
			   $id = utf8_decode(urldecode($id));
         // var_dump($id);
                $fields = array("sub_name", "year_grade","id");
                $whereArr = array("id" => $id);
                $result = $this->Generic_model->getData($fields, 'subjects', $whereArr);
            echo json_encode($result);
			
        } else {
                  $this->load->view('admin/accessDeniedPage');
               }
  //outer else
       } else {
               redirect('login/index');
       }
    }   
       
    public function editSubject() {
               
    if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
			   //              var_dump($_POST);
                $grade_name = $this->input->post("apnd_grd", TRUE);
                $sub = $this->input->post("subb_name", TRUE);
                $sub_id = $grade_name.'-'.$sub;
                $id = $this->input->post("id_sub", TRUE);
                
                 if (!isset($sub) || trim($sub) != '') {
                $dataArr = array(
                    "id" =>$id,
                    "year_grade" => $grade_name,
                    "sub_name" => $sub,
                    "sub_id" => $sub_id,
                );
                //var_dump($dataArr);
                 $checkavailabilty = $this->system_model->checkSubjects($dataArr);
                if ($checkavailabilty > 0) {
                    $record = array("record" => "NONO", "year_grade" => $grade_name, "sub_name" => $sub, "sub_id" => $sub_id);
                    echo json_encode($record);
                } else {
                    $whereArr = array("id" => $id);
                    $result = $this->Generic_model->updateData("subjects", $dataArr, $whereArr);
                    $record = array("record1" => $result, "year_grade" => $grade_name, "sub_name" => $sub, "sub_id" => $sub_id);
                   echo json_encode($record);
                }
                        }
        } else {
                  $this->load->view('admin/accessDeniedPage');
               }
  //outer else
       } else {
               redirect('login/index');
       }

    }                   
        public function deleteSubjects($id) { //add grades for the School
            if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
			    $idp = utf8_decode(urldecode($id));
//                var_dump($idp);die;    
            $data=array("status"=>1);//delete Student
            $WhereArr=array('id'=>$idp);

            $this->Generic_model->updateData("subjects",$data,$WhereArr);

            redirect(base_url().'/index.php/setUp/settings');
			
			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
		   //outer else
			} else {
				redirect('login/index');
			}
    }
    
    
    ///////////////////Teachers//////////////////////////////
    public function teachers() {
        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
			   $now = new DateTime();//Foreach to add classes 
                            $data['date'] = $now->format("Y-m-d");

                            $fields = "*";//get the class name to select
                            $whereArr=array("status" => 0);
                            $data['class_name']=$this->Generic_model->getData($fields,'class',$whereArr); 
                    //        var_dump($data);

                            $fields = array("t_name","teacher_id");//get the teacher name to select
                            $whereArr=array("status" => 0);
                            $data['TName']=$this->Generic_model->getData($fields,'teacher',$whereArr); 
                            //var_dump($data);die;

                            $fields = '*';//get the class teachers for DATA TABLE
                            $wherefieldtablefrom = array('class_teacher.status'=>0);
                            $tablefrom = 'class_teacher';
                            $tablejoin = 'class';
                            $tablejoincondition = 'class_teacher.class_id = class.id';
                            $data['class_teachers'] =  $this->Generic_model->join($fields, $wherefieldtablefrom, $tablefrom, $tablejoin, $tablejoincondition);
                    //        var_dump($data['class_teachers']);

                            $fields = "*";//class teachers for Data Table
                            $whereArr=array("status" => 0);
                            $data['class_teachers1']=$this->Generic_model->getData($fields,'class_teacher',$whereArr); 

                            $fields = "*";//subject teachers for Data Table
                            $whereArr=array("status" => 0);
                            $data['sub_teachers']=$this->Generic_model->getData($fields,'subject_teacher',$whereArr); 

                            $this->load->view('admin/School/InitialSetUp/teacherAllocation',$data);
			
        } else {
                  $this->load->view('admin/accessDeniedPage');
               }
  //outer else
       } else {
               redirect('login/index');
       }
    }
    
    
    
        public function add_class_teacher() { //add classes for a particular year
            $class_id = $this->input->post("class_id");
            list($c_id,$cname)=explode(":",$class_id);
//            $class_id = $this->input->post("class_id");
//        var_dump($class_id);
            $fields = "year_grade";
            $whereArr=array("id" => $c_id);
            $var=$this->Generic_model->getData($fields,'class',$whereArr);
            $year_grade_1=$var[0]->year_grade;

            $teacher=$this->input->post("TName"); 
            list($t_id,$tname)= explode(":",$teacher);
            
//            $date=$this->input->post("from_date");
//            var_dump($date);
//            $year = substr($date, 0, 4);
//            var_dump($year);die;
           
            $dataArr = array(
           "class_name" => $cname,
            "class_id" => $c_id,
            "teacher_id" => $t_id,
            "t_name"=> $tname, 
            "year_grade"=>$year_grade_1,  
//            "year" => $year,    
            "fromD" => $this->input->post("from_date"),
            );
//            var_dump($dataArr);die;
           $checkavailabilty = $this->system_model->checkRestoreClassTeacher($class_id);
                if ($checkavailabilty > 0) {
                    redirect(base_url().'/index.php/setUp/teachers');
                } else {
                    $this->Generic_model->insertData('class_teacher', $dataArr);
                    redirect(base_url().'/index.php/setUp/teachers');
                } 
    
            }
            
            public function deleteClassTeacher($id) { 
            if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
			   $idp = utf8_decode(urldecode($id));
    //            var_dump($idp);die;    
                $data=array("status"=>1);//delete Student
                $WhereArr=array('class_id'=>$idp);

                $this->Generic_model->updateData("class_teacher",$data,$WhereArr);

                redirect(base_url().'/index.php/setUp/teachers');
			
			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
		   //outer else
			} else {
				redirect('login/index');
			}

             }
    
              public function editClassTeacherForm($id) {
                if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
			     $id = utf8_decode(urldecode($id));
//          var_dump($id);
                $fields =array('class_name','id');
                $whereArr = array("id" => $id);
                $result1 = $this->Generic_model->getData($fields, 'class', $whereArr); 
//                var_dump( $result); 
            
                $fields = array("teacher_id", "t_name");//get the teacher name
                $whereArr = array("status" => 0);
                $result2 = $this->Generic_model->getData($fields, 'teacher', $whereArr);
           // var_dump( $result1);
                                
                $record = array("record_1" => $result1, "record_2" => $result2);
                echo json_encode($record);
			
            } else {
                      $this->load->view('admin/accessDeniedPage');
                   }
      //outer else
           } else {
                   redirect('login/index');
           }
}
            
             public function editClassTeacher() {
                if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
			   //              var_dump($_POST);
                $teacher = $this->input->post("class_tchr");
                list($t_id,$tname)= explode(":", $teacher);
                $class_id = $this->input->post("clz_id", TRUE);
                $fromD = $this->input->post("t_effective_date", TRUE);
                $class_name = $this->input->post("clsT_class_name", TRUE);
               
                if (!isset($fromD) || trim($fromD) != ''){
                
                $data=array('class_id'=>$class_id,"teacher_id" => $t_id);//to Check Availability for Updation
                
                $fields=array("year_grade.year"); //Getting the year of the assigning class
                $wherefieldtablefrom = array('class.status'=>0,'class_name'=>$class_name,"year_grade.status" =>0);
                $tablefrom = 'class';
                $tablejoin = 'year_grade';
                $tablejoincondition = 'class.year_grade = year_grade.year_grade';
                $year_of_the_class_array =  $this->Generic_model->join($fields, $wherefieldtablefrom, $tablefrom, $tablejoin, $tablejoincondition);
                $year_of_the_class = $year_of_the_class_array[0]->year;
//                   var_dump($year_of_the_class);
               
                $fields="*"; //Checking teacher is already assigned to a class fall in the same $year_of_the_class 
                $wherefieldtablefrom = array('class_teacher.status'=>0,"teacher_id" => $t_id,"year_grade.year" => $year_of_the_class);
                $tablefrom = 'class_teacher';
                $tablejoin = 'year_grade';
                $tablejoincondition = 'class_teacher.year_grade = year_grade.year_grade';
                $year_of_the_assigned_class =  $this->Generic_model->join($fields, $wherefieldtablefrom, $tablefrom, $tablejoin, $tablejoincondition);
//                var_dump($year_of_the_assigned_class);
                $count = count($year_of_the_assigned_class);
//                var_dump($count);
               
//                $checkavailabilty = $this->system_model->checkClassTeacher($data); // this is not proper checking
                
                if ($count > 0) { 
                    $record = array("record" => "NONO");
                    echo json_encode($record);
                    die;
                }else{
                        $dataArr=array("status"=>1,"ToD"=>$fromD,);//to Update
                        $WhereArr=array('class_id'=>$class_id);
                        $this->Generic_model->updateData("class_teacher",$dataArr,$WhereArr); //Update TO DATE and make status=0
               
                        $fields = "year_grade";   //Inserting New Class Teacher
                        $whereArr=array("id" => $class_id);
                        $var=$this->Generic_model->getData($fields,'class',$whereArr);
                        $year_grade_1=$var[0]->year_grade;
                 
                        $dataArr2 = array(
                       "class_name" => $class_name,
                        "class_id" => $class_id,
                        "teacher_id" => $t_id,
                        "t_name"=> $tname, 
                        "year_grade"=>$year_grade_1,    
                        "fromD" => $fromD,
                        );
        //            var_dump($dataArr);die;
                        $this->Generic_model->insertData('class_teacher', $dataArr2);
                        $record = array("record" => "DONE");
                        echo json_encode($record);
                        }
              }//isset
			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
		   //outer else
			} else {
				redirect('login/index');
			}
              }

    

       
       public function addSubjectTeacherForm($class_idp) { //to load subjects to the form //JQUERY
        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
                           // var_dump($class_id);die;
                           $class_id = utf8_decode(urldecode($class_idp));
                             // var_dump($class_id);die;
                           $fields = "year_grade";
                           $whereArr=array("class_name" => $class_id);
                           $var2=$this->Generic_model->getData($fields,'class',$whereArr); 
                   //         var_dump($var2);

                           $fields1 = array("sub_id","sub_name");
                           $whereArr1=array("year_grade" => $var2[0]->year_grade,"status"=>0);
                           $subjects=$this->Generic_model->getData($fields1,'subjects',$whereArr1); 
                           $data_count = count($subjects);

                                 if ($data_count !=0) {
                               $record = array("record_2" => "yes", "record" => $subjects);
                               echo json_encode($record);
                           } else {
                               $record = array("record_2" => "NO");
                               echo json_encode($record);
                           }
			
			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
		   //outer else
			} else {
				redirect('login/index');
			}
        
    }
    
                public function addSubjectTeacher() { //add subject Teacher
                    if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
			   $teacher = $this->input->post("teacher");
                    list($t_id,$tname)= explode(":", $teacher);
                    $dataArr = array(
                    "class_name" => $this->input->post("sub_class_name"),
                    "teacher_id" => $t_id,
                    "t_name" => $tname,    
                    "sub_name"=> $this->input->post("subject_insert"),    
                    "fromD"=>$this->input->post("from_date"),
                        );
                    
                    $checkavailabilty = $this->system_model->checkSubjectTeacher($dataArr);
                        if ($checkavailabilty > 0) {
                            redirect(base_url().'/index.php/setUp/teachers');
                        } else {
                            $this->Generic_model->insertData('subject_teacher', $dataArr);
                            redirect(base_url().'/index.php/setUp/teachers');
                        } 
			
            } else {
                      $this->load->view('admin/accessDeniedPage');
                   }
      //outer else
           } else {
                   redirect('login/index');
           }
       }
      
	   
            public function deleteSubjectTeacher($id) { 
            if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
			    $idp = utf8_decode(urldecode($id));
                
                $now = new DateTime();//Foreach to add classes 
                $date = $now->format("Y-m-d");
                  $data=array("status"=>1,"ToD"=>$date,);
                    $WhereArr=array('id'=>$idp);
                $this->Generic_model->updateData("subject_teacher",$data,$WhereArr);
                redirect(base_url().'/index.php/setUp/teachers');
			
			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
		   //outer else
			} else {
				redirect('login/index');
			}

             }
     
    
       
       
    /////////////////////HISTORY////////////////////////////   
       public function history() {
        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
			   $fields = '*';//DEACTIVATED class teachers for DATA TABLE
				$wherefieldtablefrom = array('class_teacher.status'=>1);
				$tablefrom = 'class_teacher';
				$tablejoin = 'class';
				$tablejoincondition = 'class_teacher.class_id = class.id';
				$data['class_teachers'] =  $this->Generic_model->join($fields, $wherefieldtablefrom, $tablefrom, $tablejoin, $tablejoincondition);
				
				$fields = "*";//subject teachers for Data Table
				$whereArr=array("status" => 1);
				$data['sub_teachers']=$this->Generic_model->getData($fields,'subject_teacher',$whereArr); 
				
				$this->load->view('admin/School/InitialSetUp/history',$data);
					
			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
		   //outer else
			} else {
				redirect('login/index');
			}
    }
    
        
                  public function restoreClassTeacher($id) {
                  if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
			   $new_id = utf8_decode(urldecode($id));
                  list($class_id,$t_id)= explode(":", $new_id);
//                  var_dump($class_id);
                $checkavailabilty = $this->system_model->checkRestoreClassTeacher($class_id);
//                var_dump($checkavailabilty);die;
                if ($checkavailabilty > 0) { //whether a new class teacher is assign to this class after Deleting this record
                    $record = array("record" => "NONO");
                    echo json_encode($record);
                } else {
                    $dataArr = array("status" => 0 ,"ToD"=>"0000-00-00");
                    $whereArr = array("class_id" => $class_id,"teacher_id"=>$t_id);
                    $result = $this->Generic_model->updateData("class_teacher", $dataArr, $whereArr);

                    $record = array("record" => "DONE");
                      echo json_encode($record);
                }
			
        } else {
                  $this->load->view('admin/accessDeniedPage');
               }
  //outer else
       } else {
               redirect('login/index');
       }
}
                    
               public function restoreSubjectTeacher($id) {
                if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
			     $new_id = utf8_decode(urldecode($id));
                  list($class_nm,$sub_nm,$tid)= explode(":", $new_id);
               
                  $dataArr = array("class_name" => $class_nm ,"sub_name"=>$sub_nm);
                  $checkavailabilty = $this->system_model->checkSubjectTeacher($dataArr);
                if ($checkavailabilty > 0) { //whether a new class teacher is assign to this class after Deleting this record
                    $record = array("record" => "NONO");
                    echo json_encode($record);
                } else {
                    $dataArr1 = array("status" => 0 ,"ToD"=>"0000-00-00");
                    $whereArr = array("class_name" => $class_nm ,"sub_name"=>$sub_nm,"teacher_id"=>$tid);
                    $result = $this->Generic_model->updateData("subject_teacher", $dataArr1, $whereArr);

                    $record = array("record" => "DONE");
                      echo json_encode($record);
                }
			
            } else {
                      $this->load->view('admin/accessDeniedPage');
                   }
      //outer else
           } else {
                   redirect('login/index');
           }
 }

}


