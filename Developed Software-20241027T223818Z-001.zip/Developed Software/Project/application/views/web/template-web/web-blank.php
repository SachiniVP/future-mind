<!DOCTYPE html>
<html lang="en">

<head>
   
    <title>Web Template</title>

    <?php echo $this->load->view('web/template-web/web-header'); ?>

</head>

<body>

    <?php echo $this->load->view('web/template-web/nav-bar'); ?>
   

    <!-- Page Content -->
    <div class="container">


        <hr>

       

    
  <?php echo $this->load->view('web/template-web/web-footer'); ?>    
      </div>
 
</body>

</html>


