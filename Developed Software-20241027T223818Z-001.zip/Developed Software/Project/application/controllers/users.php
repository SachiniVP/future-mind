<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class users extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('Generic_model', '', TRUE);
        $this->load->model('system_model', '', TRUE);
        /**if (!$this->session->userdata("username")) {
            redirect(base_url() . "index.php/login");
        };**/
        
    }
    
    public function index() {
                if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];


            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);               
//                var_dump($data);
                $this->load->view('admin/users/manageUsers',$data);

            } else {
                
               $this->load->view('admin/accessDeniedPage');
            }
       //outer else
        } else {
            redirect('login/index');
        }
    }
    public function manageUserForm($user_group_idp) { //to load subjects to the form //JQUERY
        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
                           // var_dump($class_id);die;
                           $user_group = utf8_decode(urldecode($user_group_idp));
//                              var_dump($user_group);
                                
                                        if ($user_group === "10" || $user_group === "20" ) {
                                          //get users 
                                          $fields = "teacher_id";//teacher ids
                                          $whereArr=array("status" =>0);
                                          $teachers=$this->Generic_model->getData($fields,'teacher',$whereArr);  
                                          $data_count1 = count($teachers);
                                            if ($data_count1 !=0) {
                                             $record = array("record_2" => "yes", "record" => $teachers);
                                            echo json_encode($record); } die;
                                        }
                                         else if ($user_group === "30") {
                                          //get users 
                                          $fields = "child_id";//teacher ids
                                          $whereArr=array("status" =>0);
                                          $students=$this->Generic_model->getData($fields,'registration',$whereArr);  
                                          $data_count2 = count($students);
                                        if ($data_count2 !=0) {
                                         $record = array("record_2" => "NO", "record" =>$students);
                                         echo json_encode($record);
                                         } 
                                         
                                        }else {
                                         $record = array("record_2" => "NONO");
                                         echo json_encode($record);
                                     }
                                        }
			  else {
				   $this->load->view('admin/accessDeniedPage');
				}
		   //outer else
			} else {
				redirect('login/index');
			}
        }  
            public function checkAvailabilityUsername() {
                $username = $this->input->post('username');
                $decoded_username = utf8_decode(urldecode($username));

                $fieldsUsername = array("id");
                $whereArrUsername = array("username"=>$decoded_username, "status" => 0);
                $dataUsername = $this->Generic_model->getData($fieldsUsername, 'login', $whereArrUsername);
                $count = count($dataUsername);


                if ($count > 0) {
                    echo json_encode(false);
                } else {
                    echo json_encode(true);
                }
            }
    
            public function add_user() { //add grades for the School
                   if ($this->session->userdata('logged_in')) {

                        $session_data = $this->session->userdata('logged_in');
                        $group_id = $session_data['group_id'];
                        $username = $session_data['username'];


                        // inner if
                        if ($group_id === "10") {
                            //get user info 
                            $fields = "*";//get teacher info
                            $whereArr=array("user_id" => $username);
                            $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);
                           
                            $username = $this->input->post("username");
                            
                            $fieldsUsername = array("id"); //restrict if userexists
                            $whereArrUsername = array("username"=>$username, "status" => 0);
                            $dataUsername = $this->Generic_model->getData($fieldsUsername, 'login', $whereArrUsername);
                            $count = count($dataUsername);
//                            var_dump($count);
                            
                            if ($count===0){ //if usernot exists
                                
                                $email = $this->input->post('email', TRUE);
                                $email_ltrim = ltrim($email," ");

                                //generate the user temp_password
                                    $this->load->helper('string');
                                    $temp_password = random_string('alpha', 8);
                                    $temp_pw_hash = sha1($temp_password);

                                 //insert new user    
                                $dataArr = array(
                                        "username" => $username,
                                        "email" =>$email_ltrim,
                                        "temp_password" => $temp_pw_hash,
                                        "group_id" => $this->input->post("user_group"),
                                        );
    //                            $this->Generic_model->insertData('login', $dataArr); //enable thisif you want it without email
    //                               redirect(base_url().'/index.php/users/newUsers');
    //                            die;

                                $result=$this->Generic_model->insertData('login', $dataArr);   
//                                var_dump($result);die;   
                                if ($result) {
                                  // load the My_PHPMailer library : Student Email
                                    $this->load->library('My_PHPMailer');

                                    $date = date("Y/m/d");
                                    $body_message = "<p>Hi,</p>
                                                    <p>A new login is created for you at Future MINDS (AMI) Montessori School</p>
                                                    <p>To change the default password, please follow this link: <a class='btn btn-primary' href='http://localhost:8080/Project/index.php/reset_password/newUserForm/'>New User Form</a>.</p>
                                                    <p>Your User Name  is :<p > $username </p> </p>
                                                    <p>Your Referance Code is :<p style='font-weight: bold;'>$temp_password</p> </p>
                                                    <p>Thanks!</p>
                                                    <p>System Administrator,</p>
                                                    <p>Future MINDS (AMI) Montessori School</p>";

                                    $maildata["subject"] = "Reset Password";
                                    $maildata["recepients"] = array(array('email' => "$email_ltrim"));

                                    $maildata["mailbody"] = $body_message;
                                    $maildata["date"] = $date;
                                    $maildata["altmailbody"] = "Future MINDS (AMI) Montessori School - Administration<br/><br/>";

                                    $mail = new My_PHPMailer();
                                    $result_email = $mail->sendcustomemail($maildata);

                                    if ($result_email['status']) {
                                        $record = array("record1" => "EmailSent");
                                        echo json_encode($record);
                                    } else {
                                        $record = array("record2" => "EmailNotSent");
                                        echo json_encode($record);
                                    }

                                } else {
                                    $record = array("record3" => "LoginTableNOTUPDATE");
                                    echo json_encode($record);
                                }   
                        }     // if user not exists earlier 

                            else {
                                $record = array("record4" => "UserExists");
                                                     echo json_encode($record);
                                           die;    
                              }   
                        
                    } else {

                           $this->load->view('admin/accessDeniedPage');
                        }
                   //outer else
                    } else {
                        redirect('login/index');
                    }
                }
        
                
                
                
    public function activeUsers() {
                if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];


            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);               
//                var_dump($data);
                
                $fields = "*";//get teacher info
                $whereArr=array("status"=>0,"active_status"=>0);
                $data['active_users']=$this->Generic_model->getData($fields,'login',$whereArr); 
                $this->load->view('admin/users/activeUsers',$data);

            } else {
                
               $this->load->view('admin/accessDeniedPage');
            }
       //outer else
        } else {
            redirect('login/index');
        }
    }  
    
                 public function editUserForm($id) {
           if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
                $id = utf8_decode(urldecode($id));
         // var_dump($id);
                $fields = "*";
                $whereArr = array("id" => $id);
                $result = $this->Generic_model->getData($fields, 'login', $whereArr);
            echo json_encode($result);
			
        } else {
                  $this->load->view('admin/accessDeniedPage');
               }
  //outer else
       } else {
               redirect('login/index');
       }
    }   
       
    public function editUser() {
               
    if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
			   //              var_dump($_POST);
                $user_name = $this->input->post("uzername", TRUE);
                $id = $this->input->post("log_id", TRUE);
                $email = $this->input->post("emailid", TRUE);
                $email_ltrim = ltrim($email, " ");
                
                if (!isset($email) || trim($email) != '') { //not empty

                $dataArr = array(
                    "email" => $email_ltrim,
                 );
                //var_dump($dataArr);
                    $whereArr = array("id" => $id);
                    $result = $this->Generic_model->updateData("login", $dataArr, $whereArr);
                    $record = array("record1" => $result, "username" => $user_name);
                   echo json_encode($record);
                }
			
        } else {
                  $this->load->view('admin/accessDeniedPage');
               }
  //outer else
       } else {
               redirect('login/index');
       }

    }
            
             public function delete_user($id) { //add grades for the School
                     if ($this->session->userdata('logged_in')) {

                    $session_data = $this->session->userdata('logged_in');
                    $group_id = $session_data['group_id'];
                    $username = $session_data['username'];


                    // inner if
                    if ($group_id === "10") {
                        //get user info 
                        $fields = "*";//get teacher info
                        $whereArr=array("user_id" => $username);
                        $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            

                           $data=array("status"=>1);//delete Student
                            $WhereArr=array('id'=>$id);

                            $this->Generic_model->updateData("login",$data,$WhereArr);

                            redirect(base_url().'/index.php/users/activeUsers');


			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
		   //outer else
			} else {
				redirect('login/index');
			}
                }
        public function newUsers() {
                if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];


            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);               
//                var_dump($data);
                
                $fields = "*";//get teacher info
                $whereArr=array("status"=>0,"active_status"=>1);
                $data['active_users']=$this->Generic_model->getData($fields,'login',$whereArr); 
                $this->load->view('admin/users/newUsers',$data);

            } else {
                
               $this->load->view('admin/accessDeniedPage');
            }
       //outer else
        } else {
            redirect('login/index');
        }
        }  
    

}


