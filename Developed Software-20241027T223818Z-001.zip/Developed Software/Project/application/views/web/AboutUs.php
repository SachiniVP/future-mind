<!DOCTYPE html>
<html lang="en">

<head>
   
    <title>AboutUs</title>

    <?php echo $this->load->view('web/template-web/web-header'); ?>

    
          <style>
                     #cnt1 {            
                         background-color:rgba(215, 212, 212, 0.88);
                         width:100%;
                         margin-bottom:70px;
                     }

                     .feature{
                         padding: 20px 0;
                        text-align: center;
                     }
                     .feature > div > div{
                        padding: 10px;
                        border: 1px solid transparent;
                        border-radius: 4px;
                        transition: 0.2s;
                     }
                     .feature > div:hover > div{
                        margin-top: -10px;
                        border: 1px solid rgb(128, 128, 128);
                        box-shadow: rgba(0, 0, 0, 0.1) 0px 5px 5px 5px;
                        background: rgba(232, 215, 215, 0.10);
                        transition: 0.3s;}
                      body {
                       background-image:url('<?php echo base_url('assets/imgs/n2.jpg')?>');
                       background-repeat:no-repeat;
                       background-size:cover; 
                       font-family: cursive}  
                     
        </style>
    
</head>

<body>

    <?php echo $this->load->view('web/template-web/nav-bar'); ?>
   
    <div id="wrapper">
    <!-- Page Content -->
    <div class="container">
        <!-- Page Heading/Breadcrumbs -->
        <div class="row">
            <div class="col-lg-12">
                <h2>About Us</h2>
            </div>
        </div>
        <!-- /.row -->
        <div class="container" id="cnt1">
            <div class="row feature">
                <div class="col-md-4" >
                    <div style="background-color:#2c78bc">
                        <img src="<?php echo base_url('assets/imgs/1.200x200.jpg')?>" alt="Texto Alternativo" class="img-circle img-thumbnail">
                        <h2><b>Our Mission</b></h2>
                        <p style="font-weight:600">
                            "We focused on quality early childhood education and development by moulding and guiding children physically,
                            mentally,spiritually and socially in unison,forming a sound foundation to cultivate thier own natural desire to
                            learn and become law-abiding well-disciplined future citizens."

                        </p>

                    </div>
                </div>

                <div class="col-md-4">
                    <div style="background-color:#9ab91e">
                        <img src="<?php echo base_url('assets/imgs/2.200x200.jpg')?>" alt="Texto Alternativo" class="img-circle img-thumbnail">
                        <h3><b>We groom your kids with;</b></h3>
                        <p style="font-weight:600">
                             Spoken English / Elocution <br/>
                             Assisting to lay a foundation for proper English <br/>
                             Computer Knowledge <br/>
                             Music <br/>
                             Swimming <br/>
                             Personality Development <br/>
                             Better Discipline <br/>
                             Self Confidence <br/>
                             Good Concentration 

                        </p>

                    </div>
                </div>

                <div class="col-md-4">
                    <div style="background-color:#ed5c01">
                        <img src="<?php echo base_url('assets/imgs/3.200x200.jpg')?>" alt="Texto Alternativo" class="img-circle img-thumbnail">
                        <h2><b>Our Teachers</b></h2>
                        <p style="font-weight:600" >
                        <h4>Experiences</h4>
                        <p style="font-weight:600" >Former teachers of AMI Montessori schools, Colombo and leading International schools </p>

                        <h4>Qualifications</h4>
                        <p style="font-weight:600" >AMI Training - Montessori method of education for nursery and primary school <br/>
                        Teachers of Spoken English <br/>
                        IWMS (Institute of Western Music & Speech) <br/>
                        LAMDA (UK) - Elocution </br>
                        Child Psychology

                        </p>

                    </div>
                </div>
            </div>
        </div>


        <hr>

       

    
  <?php echo $this->load->view('web/template-web/web-footer'); ?>    
      </div>
    </div>
</body>

</html>


