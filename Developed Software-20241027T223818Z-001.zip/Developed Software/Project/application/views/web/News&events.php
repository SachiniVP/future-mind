<!DOCTYPE html>
<html lang="en">

<head>
   
    <title>News & Events</title>

    <title>Gallery</title>

    <?php echo $this->load->view('web/template-web/web-header'); ?>
    
    <style>
      body {
       background-image:url('<?php echo base_url('assets/imgs/n2.jpg')?>');
       background-size:cover; 
       font-family: cursive}
     </style>

    
    
  
</head>

<body style="background-image:url('<?php echo base_url('assets/imgs/n2.jpg')?>');background-repeat:no-repeat;font-family: cursive">

    <?php echo $this->load->view('web/template-web/nav-bar'); ?>
   
<!-- Page Content -->
    <div class="container">

       

 
    
    </div>
        <!-- /.row -->

 <hr>

       

    
  <?php echo $this->load->view('web/template-web/web-footer'); ?>    
      
 
</body>

</html>


