
<!DOCTYPE html>
<!--Administrator Dashboard-->

   
<!-- BEGIN HEAD-->
<head>
       
    <title>Student Activity Summery</title>
    <?php echo $this->load->view('admin_panel/template/header'); ?>
    <!-- PAGE LEVEL STYLES -->
    <link href="<?=base_url();?>assets/admin_assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
    <!-- END PAGE LEVEL  STYLES -->
</head>
<!-- END  HEAD-->    
   
    
    <!-- BEGIN BODY-->
<body class="padTop53" >

     <!-- MAIN WRAPPER -->
    <div id="wrap" style="background-color:#b8b8b8;">
        <!--HEADER SECTION -->
         <?php echo $this->load->view('admin_panel/template/navbar'); ?>
        <!-- END HEADER SECTION -->
        


        <!-- MENU SECTION -->
          <?php echo $this->load->view('parentsView/parents_menubar'); ?>
        <!--END MENU SECTION -->


        <!--PAGE CONTENT -->
        <div id="content" >
            
            <div class="inner" style="min-height:1200px;background-color:transparent">
                <!---breadcrumb--->
                <div class="row">
                    <div class="col-md-12">
                        <div class="col-lg-12">
                            <div class="well-sm">
                                <div style="">
                                    <ul class="breadcrumb"  >
                                    <li> <a href="<?php echo base_url()."index.php/parentsController/parentsDashboard"?>"> Dashboard </a> </li>
                                    <li><a href="<?php echo base_url()."index.php/parentsController/stdnSubejctList"?>">Students Subject List</a></li> 
                                     <li class="active">Student Activities Summery</li>
                                    </ul>
                                </div>    
                            </div>
                        </div> <!-- /.col-lg-12 --> 
                    </div> <!-- /.col-md-12 -->
                </div><!-- /.row -->
                <!---END breadcrumb--->
                

          
               <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="row"> 
                  <div class="col-lg-9">
                    <div class="well" style=" background-color: #d6d4d4;">
                           <div class='row'>
                                    <div class='col-sm-5'> 
                                            <label for="Activity Name" class="control-label">Student Name</label>
                                        </div>
                                    <div class='col-sm-5'>
                                            
                                            <div class='form-group'>
                                                <input  id="act_name" name="act_name" value="<?php echo $student_name[0]->first_name." ".$student_name[0]->last_name ; ?>" class="form-control" readonly/>
                                           <?php // echo $assigns[0]->t_name ; ?>
                                            </div>
                                     </div>
                         </div> 
                        
                        <div class='row'>
                                    <div class='col-sm-5'> 
                                            <label for="TName" class="control-label"> Class</label>
                                        </div>
                                    <div class='col-sm-5'>
                                            
                                            <div class='form-group'>
                                                <input  id="class" name="class" value="<?php echo $class_name ; ?>" class="form-control" readonly/>
                                           <?php // echo $assigns[0]->t_name ; ?>
                                            </div>
                                     </div>
                         </div> 
                        <div class='row'>
                                    <div class='col-sm-5'> 
                                            <label for="TName" class="control-label"> Subject </label>
                                        </div>
                                    <div class='col-sm-5'>

                                            <div class='form-group'>
                                                <input id="subject" name="subject" value="<?php echo $sub_name; ?>"  class="form-control" readonly/>
                                           <?php // echo $assigns[0]->t_name ; ?>
                                            </div>
                                     </div>
                         </div> 
                        <div class='row'>
                                    <div class='col-sm-5'> 
                                            <label for="Effective" class="control-label">Teacher</label>
                                        </div>
                                    <div class='col-sm-5'>
                                            
                                            <div class='form-group'>
                                                <input  id="e_date" name="e_date" value="<?php echo $t_name; ?>" class="form-control" readonly/>
                                           <?php // echo $assigns[0]->t_name ; ?>
                                            </div>
                                     </div>
                         </div> 

                      </div>  
                   </div> 
      
               </br>        
               <div class="row"> 
                <div class="col-lg-11">
                    <div class="well" style=" background-color: #d6d4d4;">
                              <div class="row"> 
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="well well-lg">
                         <div class="panel-body">
                            <div class="table-responsive">
                               <table class="table table-striped table-bordered table-hover" id="dataTables-example" class="display" cellspacing="0" width="100%">    <thead>
                                        <tr>
                                            <th>Activity Date</th>
                                            <th>Activity Name</th>
                                             <th> Level </th>
                                             <th> Comment </th>
                                              <!--<th>Action</th>-->
                                        </tr>
                                    </thead>
                                    <tbody center>
                                        <?php
                                foreach ($student_marks_table as $userItem) {
                                    echo "<tr>";
                                    echo "<td>" . $userItem->e_date . "</td>";
                                    echo "<td>" . $userItem->activity_name . "</td>";
                                    echo "<td>" . $userItem->level . "</td>";
                                    echo "<td>" . $userItem->comment . "</td>";
//                                    echo "<td></td>";
//                                     echo "<td>";
//                                    echo "<a id='" . $userItem->id . "' href='#editAddMarkFormModal' data-toggle='modal' class='editMarks btn btn-primary btn-circle'><i class='icon-edit'></i></a>";
//                              
//                                    echo "<a href='". base_url()."index.php/teacherController/deleteAddMarks/".$userItem->id."' > <button type='button' class='btn btn-warning btn-circle' id='btnWarning'>
//                                                      <i class='icon-trash'></i></button></a> ";
//                                     
//                                   echo"</td>";
                                   
                                }
                                ?>  
                                    </tbody>
                                </table>
                            </div>
                         </div><!--Data TAble-->                          
                    </div>  
                </div>
                </div> 
                    </div>
                 </div><!---->
            </div><!--/ Data tale row-->
        
             
             <div class="well" style="background-color: #d6d4d4;">    
                 <div class="col-lg-12"> 
                     <div class="well well-lg">
                        <canvas id="chart" width="1000" height="500"></canvas>
                    </div>  
                </div> 

                </div> 
            </div><!-- well-->
           </div> 
         </div>   
                

                     
            
           </div><!--END PAGE CONTENT -->
        </div><!--END MAIN WRAPPER -->
   
    
                <!-- PAGE LEVEL SCRIPTS -->
                <?php echo $this->load->view('admin_panel/template/footer'); ?> 
                

                
               <script src="<?=base_url();?>assets/admin_assets/plugins/dataTables/jquery.dataTables.js"></script>
                <script src="<?=base_url();?>assets/admin_assets/plugins/dataTables/dataTables.bootstrap.js"></script>
                <script>
                     $(document).ready(function () {
                         $('#dataTables-example').dataTable();
                     });
                </script>
        <script src="<?= base_url(); ?>assets/Chart.js"></script>  
        <script src="<?= base_url(); ?>assets/Chart.bundle.min.js"></script>    
        <script>
        var ctx = document.getElementById("chart").getContext("2d");
        var data = {
            labels: [<?php foreach ($student_marks_table as $chart_item) {echo "'$chart_item->activity_name',";} ?>],
            datasets: [
               {
                    label: "",
                    fill: true,
                    lineTension: 0.1,
                    backgroundColor: "rgba(75,192,192,0.4)",
                    borderColor: "rgba(75,192,192,1)",
                    borderCapStyle: 'butt',
                    borderDash: [],
                    borderDashOffset: 0.0,
                    borderJoinStyle: 'miter',
                    pointBorderColor: "rgba(75,192,192,1)",
                    pointBackgroundColor: "#fff",
                    pointBorderWidth: 1,
                    pointHoverRadius: 5,
                    pointHoverBackgroundColor: "rgba(75,192,192,1)",
                    pointHoverBorderColor: "rgba(220,220,220,1)",
                    pointHoverBorderWidth: 2,
                    pointRadius: 5,
                    pointHitRadius: 5,
                    data: [<?php foreach ($student_marks_table as $chart_item){echo "'$chart_item->score',";} ?>],
                    spanGaps: false,
                }]
        };

        var myLineChart = new Chart(ctx, {
            type: 'line',
            data: data,

            options: {
                // Elements options apply to all of the options unless overridden in a dataset
                // In this case, we are setting the border of each bar to be 2px wide and green

                responsive: true,
                legend: {
                    display:false,
                    position: 'bottom',
                },
                title: {
                    display: true,
                    text: '<?php echo $student_name[0]->first_name." ".$student_name[0]->last_name." ".$sub_name." ".$class_name ?>'
                },
                scales: {
                      yAxes: [{
                            display: true,
                            scaleLabel: 
                                    {
                                    display: true,
                                    labelString: 'LEVELS'
                                  },
                                  
                           ticks: {
                                   callback: function(value, index, values) {
                                       if((value)===5){
                                         return 'Excellent';}
                                       if((value)===4){
                                         return 'Very Good';}
                                       if((value)===3){
                                         return 'Good';}
                                       if((value)===2){
                                         return 'Average';}
                                       if((value)===1){
                                         return 'Need Improvement';}
                                       if((value)===0){
                                         return 'Not Applicable';
                                       } else {
                                         return value;
                                       }},
                                min: 0,
                                max: 5,
                                beginAtZero: true,
                                stepSize:1                                
                            }
                        }]
                  }
            }
        });

    </script> 
                
                 <script>
        $(document).ready(function () {
             $('#clz_nm').change(function () {
                abcd = this.value;
                baseurl = "http://localhost:8080/Project/";
                $.ajax({
                    //type: "GET",
                    url: baseurl + "index.php/evaluation/activityAvail/" + abcd,
                    // data: {grade_id: grade_id},
                    dataType: 'json',
                     success: function (data) {
                        
                        if (data.record1 === "NONO") { //this is kept for future use
                                $("#spnmessage_edgrdf").removeAttr("class", "alert alert-danger");
                                $("#spnmessage_edgrdf").attr("class", "alert alert-danger");
                                $("#spnmessage_edgrdf").html('<p><strong>No Student registered For This Class yet</strong></p>');
                                $("#divmessage_edgrdf").removeAttr("class", "hide");
                                $("#divmessage_edgrdf").fadeIn(1500);
                                $("#divmessage_edgrdf").delay(2500).fadeOut(1500);
                                setTimeout(function () {
                                    location.reload();
                                }, 4000);
                        }else{
                              location = baseurl + "index.php/lessons/"+ abcd;
                        }
                    }
                });
            });
        });</script>
                 
                 <!-- END PAGE LEVEL SCRIPTS --> 
</body> 
<!-- END BODY-->
   
 
</html>

