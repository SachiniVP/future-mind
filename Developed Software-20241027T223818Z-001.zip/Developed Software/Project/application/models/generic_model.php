<?php

class Generic_model extends CI_Model {

    public function verifyUserLogin($username, $password) {
        
        //$query = $this->db->query("SELECT * FROM login WHERE username='$username' AND password='$password'");
        $whereArr = array("username" => $username, "password" => $password);
        $columnArr = array("id", "username");
        $query = $this->getusers('login', $columnArr, $whereArr);

        if ($query->num_rows > 0) {
            $result = $query->result();

            $newdata = array(
                'username' => $username,
                'logged_in' => TRUE,
            );
           // $this->session->set_userdata($newdata);
            
            return $result[0]->username;
        } else {
            return false;
        }
    }

        public function verification($fieldset, $tableName, $where = '') {

        date_default_timezone_set('Asia/Colombo');
        $date = date('m/d/Y h:i:s a', time());

        $this->db->select($fieldset)->from($tableName)->where($where);
        $abc = $this->db->get();


        if ($abc->num_rows() > 0) {
            foreach ($abc->result() as $row) {
                $userData = array('user' => $row->username, "logtime" => $date,"psw"=>$row->password);
                $this->session->set_userdata('login_user', $userData);
                redirect(base_url() . 'index.php/dashboard');
            }
        } else {
            echo "invalid";
        }
    }
    
    public function getData($fieldset, $tableName, $where = '') {
        if ($where == "") {
            $this->db->select($fieldset)->from($tableName);
        } else  {
            $this->db->select($fieldset);
            $this->db->from($tableName);
            $this->db->where($where);
//            $this->db->where($where2);
        }
        $query = $this->db->get();
        return $query->result();
                 }
                 
     

    function getdataActiveRecords($tableName = '', $columns_arr = '', $whereArr = '') {
        if (!$tableName) {
            return array();
        }

        if (!empty($columns_arr)) {
            $this->db->select(implode(',', $columns_arr), FALSE);
        }

        $this->db->from($tableName);
        if (!empty($whereArr)) {
            $this->db->where($whereArr);
        }

        $query = $this->db->get();
        return $query->result();
             }

    
    function insertData($tablename, $data_arr) {
        $result = $this->db->insert($tablename, $data_arr);
        return $result;
             }
    
    
    function insertBatch($tablename, $data_arr) {
        $result = $this->db->insert_batch($tablename, $data_arr);
        return $result;
              }
              
//    function insertBatch($tablename, $data_arr) {
//        $query = $this->db->query("YOUR QUERY");
//
//                foreach ($query->result() as $row)
//                {
//                   echo $row->title;
//                   echo $row->name;
//                   echo $row->body;
//                }
//                  
//                $query = $this->db->get('mytable');
//
//                foreach ($query->result() as $row)
//                {
//                    echo $row->title;
//                }
//    }
//    
    public function updateData($tableName,$dataArra,$whereArr) {
     
        $this->db->where($whereArr);
        $result=$this->db->update($tableName, $dataArra);
        return $result;
        
             }
  
    public function join($fields, $wherefieldtablefrom, $tablefrom, $tablejoin, $tablejoincondition) {
        if ($wherefieldtablefrom == "") {
            $this->db->select($fields); // $this->db->select('*');
            $this->db->from($tablefrom); // $this->db->from('table1');
            $this->db->join($tablejoin, $tablejoincondition); // $this->db->join('table2', 'table1.col1 = table2.col1');
            //$query = $this->db->get();
//            if ($query->num_rows() == 1) {
//                $data = $query->row();
//            } else if ($query->num_rows() > 1) {
//                $data = $query->result_array();
//            }
        } else {
            $this->db->select($fields); // $this->db->select('*');
            $this->db->from($tablefrom); // $this->db->from('table1');
            $this->db->join($tablejoin, $tablejoincondition); // $this->db->join('table2', 'table1.col1 = table2.col1');
            $this->db->where($wherefieldtablefrom); // $this->db->where('table1.col1', 2);
            //$query = $this->db->get();
//            if ($query->num_rows() == 1) {
//                $data = $query->row();
//            } else if ($query->num_rows() > 1) {
//                $data = $query->result_array();
//            }
        }
        $query = $this->db->get();
        return $query->result();
             }
    
     public function pop_records($column,$table,$where) { //my own
        $data_room_type = array();
        $this->db->select($column);
        $this->db->from($table);
        $this->db->where($where);
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            foreach ($query->result_array() as $row) {
                $data[] = $row;
            }
        }
        return $data;
            }   
    
      
    public function sum($field, $wherefield, $table) {
        if ($wherefield == "") {

            $this->db->select_sum($field);
            $this->db->from($table);
        } else {
            $this->db->select_sum($field)->where($wherefield);
            $this->db->from($table);
        }
        $query = $this->db->get();
        return $query->result();
    }
    
     public function getDataSortAsc($fieldset, $tableName, $where, $asc_field) {
        if ($where == "") {
            $this->db->select($fieldset)->from($tableName);
        } else {
            $this->db->select($fieldset)->from($tableName)->where($where);
        }
        $this->db->order_by($asc_field, "asc");
        $query = $this->db->get();
        return $query->result();
    }

     public function getDataGroupAsc($fieldset, $tableName, $where = '', $groupfield, $orderfield) {
        if ($where == "") {
            $this->db->select($fieldset)->from($tableName);
            $this->db->group_by($groupfield);            
        } else {
            $this->db->select($fieldset)->from($tableName)->where($where);
            $this->db->group_by($groupfield);
        }
        $this->db->order_by($orderfield,'asc');
        $query = $this->db->get();
        return $query->result();
    }
    
    
    
    
    
    
    
    
    
    
    
    function getusers($tableName = '', $columns_arr = '', $whereArr = '') {
        if (!$tableName) {
            return array();
        }

        if (!empty($columns_arr)) {
            $this->db->select(implode(',', $columns_arr), FALSE);
        }

        $this->db->from($tableName);
        if (!empty($whereArr)) {
            $this->db->where($whereArr);
        }

        $query = $this->db->get();
        return $query;
    }

      
    
    public function getDataold($table, $column = '', $where = '') {
        if (!$table) {
            return array();
        }
        if (!$column) {
            $query = $this->db->query("SELECT " . $column . " FROM " . $table . ";");
        }

        if (!empty($column) && !empty($where)) {
            $query = $this->db->query("SELECT " . $column . " FROM " . $table . " WHERE " . $where . ";");
        }

        if (!empty($where)) {
            $query = $this->db->query("SELECT * FROM " . $table . " WHERE " . $where . ";");
        }

        $query = $this->db->query("SELECT * FROM " . $table . ";");

        return $query->result();
    }
    
    function updateDataold($tablename, $data_arr, $where_arr, $orArr = '') {
        if (!empty($orArr)) {
            $this->db->or_where($orArr);
        } else {
            $this->db->where($where_arr);
        }

        $result = $this->db->update($tablename, $data_arr);

        return $result;
    }
    
    
    
}
 
    