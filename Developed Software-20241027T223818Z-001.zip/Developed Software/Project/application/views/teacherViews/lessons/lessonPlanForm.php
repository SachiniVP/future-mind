
<!DOCTYPE html>

   
<!-- BEGIN HEAD-->
<head>
       
    <title>Add New Lesson Plan</title>
    <?php echo $this->load->view('admin_panel/template/header'); ?>
    <!-- PAGE LEVEL STYLES -->
    <link href="<?=base_url();?>assets/admin_assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
    <!-- END PAGE LEVEL  STYLES -->
</head>
<!-- END  HEAD-->    
   
    
    <!-- BEGIN BODY-->
<body class="padTop53" >

     <!-- MAIN WRAPPER -->
    <div id="wrap" style="background-color:#b8b8b8;">
        <!--HEADER SECTION -->
         <?php echo $this->load->view('admin_panel/template/navbar'); ?>
        <!-- END HEADER SECTION -->
        


        <!-- MENU SECTION -->
          <?php echo $this->load->view('teacherViews/teacher_menubar'); ?>
        <!--END MENU SECTION -->


        <!--PAGE CONTENT -->
        <div id="content" >
            
            <div class="inner" style="min-height:1200px;background-color:transparent">
                <!---breadcrumb--->
                <div class="row">
                    <div class="col-md-12">
                        <div class="col-lg-12">
                            <div class="well-sm">
                                <div style="">
                                    <ul class="breadcrumb"  >
                                    <li> <a href="<?php echo base_url()."index.php/teacherController/teacherDashboard"?>"> Dashboard </a> </li>
                                    <li class="#"> School Settings </li>
                                    <li><a href="<?php echo base_url() . "index.php/teacherController/lessonPlanIndex" ?>">Lesson Plans(TEACHERS)</a></li>
                                    <li class="active"> New Lesson Plan</li>
                                </ul>
                                </div>    
                            </div>
                        </div> <!-- /.col-lg-12 --> 
                    </div> <!-- /.col-md-12 -->
                </div><!-- /.row -->
                <!---END breadcrumb--->
          
            <div class="well" style=" background-color: transparent;">    
           <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
               <form action="" id="lesson_plan_form" method="POST" ">
                <div class="row"> 
                <div class="col-lg-9">
                    <div class="well" style=" background-color: #d6d4d4;">
                                    <!--Return Msg Div-->
                                    <div class="row">  
                                        <div class="col col-md-9 col-sm-9 hide" id="divmessage_edexm">
                                            <div style=" width: 100%; padding: 5px;" id="spnmessage_edexm" class="alert alert-success" role="alert">
                                            </div>
                                        </div>
                                    </div>
                        <div class='row'>
                                    <div class='col-sm-5'> 
                                            <label for="TName" class="control-label"> Class</label>
                                        </div>
                                    <div class='col-sm-5'>
                                            
                                            <div class='form-group'>
                                                <input  id="class" name="class" value="<?php echo $ids[2] ; ?>" class="form-control" readonly/>
                                           <?php // echo $assigns[0]->t_name ; ?>
                                            </div>
                                     </div>
                         </div> 
                        <div class='row'>
                                    <div class='col-sm-5'> 
                                            <label for="TName" class="control-label"> Subject </label>
                                        </div>
                                    <div class='col-sm-5'>

                                            <div class='form-group'>
                                                <input id="subject" name="subject" value="<?php echo $ids[1] ; ?>"  class="form-control" readonly/>
                                           <?php // echo $assigns[0]->t_name ; ?>
                                            </div>
                                     </div>
                         </div> 
                    </div> 
                </div>
                    <div class="hidden">
                      <input  id="teacher_id" name="teacher_id" value="<?php echo $ids[0] ; ?>" class="form-control" readonly/> 
                      <input id='lp_status' name='lp_status' value='Pending Approval'/>
                    </div>
                    
                    
                    
                    
                </div><!--Academic Year-->
           
                </br>        
               <div class="row"> 
                <div class="col-lg-11">
                    <div class="well" style=" background-color: #d6d4d4;">
<!--                               <div class='row'>
                                   <div class='col-sm-3'></div>
                                    <div class='col-sm-1'> Year
                                            <label for="year" class="control-label"> Year</label>
                                    </div>
                                    <div class='col-sm-3'><div class='form-group'>
                                                <input  id="year" name="year" value="<?php echo date('Y'); ?>" class="form-control"/>
                                        </div></div>
                                    
                                    <div class='col-sm-1'>  Month
                                            <label for="month" class="control-label"> Month</label>
                                    </div>
                                    
                                    <div class='col-sm-3'><div class='form-group'>
                                                <select id="month" name="month" class="form-control">
                                                <option value="<?php echo date('F');?>" selected> <?php echo date('F');?></option>
                                                <option value="January" >January</option>
                                                <option value="February">February</option>
                                                <option value="March" >March</option>
                                                <option value="April">April</option>
                                                <option value="May" >May</option>
                                                <option value="June">June</option>
                                                <option value="July" >July</option>
                                                <option value="August">August</option>
                                                <option value="September" >September</option>
                                                <option value="October">October</option>
                                                <option value="November" >November</option>
                                                <option value="December">December</option>
                                                 </select>
                                     </div></div>
                               </div>-->
                       
                        </br>  
                        <div class="row">     
                        <div class='col-sm-3'> 
                        <label for="" class="control-label"> Date Range</label>
                        </div>
                                            <div class='col-sm-4'><div class='form-group'>
                                                 <div class="input-group date" >
                                                     <input type="text" class="all form-control" id='daterangep' name="daterangep" readonly=""><span class="input-group-addon"><i class="icon-calendar"></i></span>
                                                </div> 
                                                </div></div><label style="color:red;font-style:italic;"> Note: Lessons to be planned allowed for next 3 months only.</label>
                        </div>   
                         </br>
                        
                             <div class='row'>
                                    <div class='col-sm-3'> 
                                            <label for="TName" class="control-label"> Lesson Plan</label>
                                        </div>
                                    <div class='col-sm-7'>
                                            <div class='form-group'>
                                              <textarea id="activity" name="activity" rows="10" cols="100" class="form-control"></textarea>
                                    </div>
                                </div>
                                </div> 
                         
                    </div>
                    <div class="col-sm-offset-11">
                        <div class="col-sm-3">
                        <button class="btn btn-success btn-lg pull-right" type="submit"> SUBMIT </button>
                        </div>    
                    </div>     
                 </div><!---->
            </div><!-- END Activity part-->
            
               
            </form>
        </div><!--form div-->
              
            
            
              
              
              
              
              
               </div><!-- Inner-->      
            </div><!-- content-->
           </div><!--END PAGE CONTENT -->
        </div><!--END MAIN WRAPPER -->
    
    
                <!-- PAGE LEVEL SCRIPTS -->
                <?php echo $this->load->view('admin_panel/template/footer'); ?> 
                
     
           <!--bootstrap date range picker-->
            <script src="<?php echo base_url(); ?>assets/bootstrap-daterangepicker/moment.js" type="text/javascript"></script>
            <script src="<?php echo base_url(); ?>assets/bootstrap-daterangepicker/daterangepicker.js" type="text/javascript"></script>
            <link href="<?php echo base_url(); ?>assets/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet" type="text/css"/>
       
             <!--/ Java Script--> 
            <script>
          $(document).ready(function () {
                
                mdTemp = new Date(), //setting max date is 3 months from today
                maxDate = new Date(mdTemp.setDate(mdTemp.getDate() + 90));
              
                 $('#daterangep').daterangepicker({
                  "opens": "left",
                  "showWeekNumbers": true,
                  "weekStart": "1" ,
                  "minDate": new Date(),
                   "maxDate": maxDate,
                   isInvalidDate: function(date) {   //disable weekends
                            return (date.day() == 0 || date.day() == 6);
                          },
                 locale: {
                        format: 'YYYY-MM-DD'
                    }
                             });
                             });
             </script>
     
            <!-- DATA TABLES bootstrap-->
           <script src="<?=base_url();?>assets/admin_assets/plugins/dataTables/jquery.dataTables.js"></script>
           <script src="<?=base_url();?>assets/admin_assets/plugins/dataTables/dataTables.bootstrap.js"></script>
           <script>
                $(document).ready(function () {
                    $('#dataTables-example').dataTable();
                });
           </script>

            <!-- Validation files-->
           <script src="<?=base_url();?>assets/jquery-validation-1.15.0/lib/jquery.mockjax.js"></script>
           <script src="<?=base_url();?>assets/jquery-validation-1.15.0/dist/jquery.validate.js"></script>
           <script src="<?=base_url();?>assets/jquery-validation-1.15.0/dist/additional-methods.js"></script>
           <link href="<?php echo base_url(); ?>assets/jquery-validation-1.15.0/demo/css/screen.css" rel="stylesheet" type="text/css"/      >
           <!-- Validation files-->


              <script>
                   $(document).ready(function () {
                       //$("#staff_add_form").validate();  // full validation


                       function Year(value, element) {
                           return /^(0[1-9]|1[0-9]|2[0-9]|3[01])+$/.test(value);
                       }

                       function DateFormatValidation(value, element) {
                           return /^[0-9]{4}-(0[1-9]|1[012])-(0[1-9]|1[0-9]|2[0-9]|3[01])+$/.test(value);
                       }

                    //custom validation rule - date format YYYY-MM-DD
                       $.validator.addMethod("Year", Year, "Insert a valid Year");
                       $.validator.addMethod("dateFormat", DateFormatValidation, "l");

           //            $.validator.addMethod("greaterThan",'Must be greater than {0}');
                           $("#lesson_plan_form").validate({

                             rules: {
                                year: {required: true, Year: "Insert a valid Year"},
//                               fromD: {required: true,
//                                   dateFormat: true},
//                               ToD: {required: true,dateFormat: true,},
                               daterangep: {required: true},
                               activity:{required: true},
                              },
                           messages: {
                               class_name: {required: "Select the class",},
//                               fromD: {required: "This field is required",
//                                   dateFormat: "Date format is YYYY-MM-DD"},
//                               ToD: {required: "This field is required",
//                                   dateFormat: "Date format is YYYY-MM-DD"},
                               daterangep: {required: "Please select a date range"},
                               activity:{required: "Please Add Your Lesson Plan",},
                             }
                            });
                  });
               </script>  
        
         <!--Add Lesson Plan Form Submit-->      
         <script>
          $(document).ready(function () {
            baseurl = "http://localhost:8080/Project/";
            $("#lesson_plan_form").submit(function (e) {
                e.preventDefault();
//                    $('#change_classT').modal('hide');
                var jqXHR = $.ajax({
                    type: "POST",
                    url: baseurl + "index.php/teacherController/addLessonPlan",
                    data: $("#lesson_plan_form").serialize(),
                    dataType: 'json',
                    success: function (data) {
                        //console.log(data);
                        if (data.record === "DONE") {
                            $("#spnmessage_edexm").removeAttr("class", "alert alert-danger");
                            $("#spnmessage_edexm").attr("class", "alert alert-success");
                            $("#spnmessage_edexm").html('<p><strong> Successfully added </strong></p>');
                            $("#divmessage_edexm").removeAttr("class", "hide");
                            $("#divmessage_edexm").fadeIn(1500);
                            $("#divmessage_edexm").delay(2500).fadeOut(1500);
                            setTimeout(function () {
                                location = baseurl + "index.php/teacherController/lessonPlanIndex/";
                            }, 4000);
                            
                        } else if (data.record === "NONO") {
                            $("#spnmessage_edexm").removeAttr("class", "alert alert-success");
                            $("#spnmessage_edexm").attr("class", "alert alert-danger");
                            $("#spnmessage_edexm").html('<p><strong> You have already added a Lesson for this subject in these days.Check the Date Range. </strong></p>');
                            $("#divmessage_edexm").removeAttr("class", "hide");
                            $("#divmessage_edexm").fadeIn(1500);
                            $("#divmessage_edexm").delay(5000).fadeOut(1500);

                        }
                    }
                });
            });
        });
    </script>


           <!-- /Java Script -->
                <!-- END PAGE LEVEL SCRIPTS -->  
</body> 
<!-- END BODY-->
   
 
</html>

