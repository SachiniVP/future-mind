<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class payments extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('Generic_model', '', TRUE);
        $this->load->model('system_model', '', TRUE);
        /*         * if (!$this->session->userdata("username")) {
          redirect(base_url() . "index.php/login");
          };* */
    }

    public function index() {
        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*"; //get teacher info
                $whereArr = array("user_id" => $username);
                $data['userData'] = $this->Generic_model->getData($fields, 'admins', $whereArr);

                $serial = $this->Generic_model->getData('serial', 'serials', array("type" => "txn"));
                $data['serial'] = $serial[0]->serial + 1;

                $fields = 'admission_id'; //Display active New Addmission Requests
                $whereArr = array("A_status" => 'Pending');
                $data['admissions'] = $this->Generic_model->getData($fields, 'new_admission', $whereArr);


                //child drop down list
                $fields = array('child_id','first_name','last_name'); //To Display all Children (all registered as well as not registered too
                $whereArr = array("child_status" => 0);
                $data['child_ids'] = $this->Generic_model->getData($fields, 'child', $whereArr);

                //child drop down list
                $fields = 'child_id'; //To Display all Children registered
                $whereArr = array("status" => 0);
                $data['Reg_child_ids'] = $this->Generic_model->getData($fields, 'registration', $whereArr);

                //class drop down list
                $fields = 'class_name'; //To Display in DataTable Subjects
                $whereArr = array("status" => 0);
                $data['classes'] = $this->Generic_model->getData($fields, 'class', $whereArr);
                $this->load->view('admin/payments/paymentIndex', $data);
            } else {
                $this->load->view('admin/accessDeniedPage');
            }
            //outer else
        } else {
            redirect('login/index');
        }
    }

    public function monthlyClasses($class_idp) { //to load classes for manthly fee form
        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*"; //get teacher info
                $whereArr = array("user_id" => $username);
                $data['userData'] = $this->Generic_model->getData($fields, 'admins', $whereArr);

                // var_dump($class_id);die;
                $class_id = utf8_decode(urldecode($class_idp));
                // var_dump($class_id);die;
                
                $fields=array(      //Students List to load to form
                            "child.child_id", 
                            "first_name",
                            "last_name",
                                    ); 
                $wherefieldtablefrom = array("class_name" => $class_id, "status" => 0);
                $tablefrom = 'child';
                $tablejoin = 'registration';
                $tablejoincondition = 'child.child_id = registration.child_id';
                $var2 = $this->Generic_model->join($fields, $wherefieldtablefrom, $tablefrom, $tablejoin, $tablejoincondition);
//                      
//                $fields = "child_id";
//                $whereArr = array("class_name" => $class_id, "status" => 0);
//                $var2 = $this->Generic_model->getData($fields, 'registration', $whereArr);
                echo json_encode($var2);
            } else {
                $this->load->view('admin/accessDeniedPage');
            }
            //outer else
        } else {
            redirect('login/index');
        }
    }

    public function renewalClasses($year) { //to load classes for renewal form
        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*"; //get teacher info
                $whereArr = array("user_id" => $username);
                $data['userData'] = $this->Generic_model->getData($fields, 'admins', $whereArr);

                // var_dump($class_id);die;
                $year = utf8_decode(urldecode($year));


                $fields = 'class_name'; //get the class teachers for DATA TABLE
                $wherefieldtablefrom = array('year_grade.year' => $year, 'class.status' => 0);
                $tablefrom = 'year_grade';
                $tablejoin = 'class';
                $tablejoincondition = 'class.year_grade = year_grade.year_grade';
                $var3 = $this->Generic_model->join($fields, $wherefieldtablefrom, $tablefrom, $tablejoin, $tablejoincondition);
                $record1 = array("record" => $var3);
                echo json_encode($record1);
            } else {
                $this->load->view('admin/accessDeniedPage');
            }
            //outer else
        } else {
            redirect('login/index');
        }
    }

    public function newAdmission() {

        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*"; //get teacher info
                $whereArr = array("user_id" => $username);
                $data['userData'] = $this->Generic_model->getData($fields, 'admins', $whereArr);

                $serial = $this->Generic_model->getData('serial', 'serials', array("type" => "txn"));
                $serialNo = $serial[0]->serial + 1;
                $data['serial'] = $serialNo;
                
                $txn_id = $this->input->post("Txn_id");

                $dataArr = array(
                    "payment_date" => $this->input->post("today"),
                    "payment_amount" => $this->input->post("amt"),
                    "reg_child_id" => $this->input->post("child_id"),
                    "A_status" => 'Confirmed',
                );
                $admission = $this->input->post("admission_no", TRUE);
                $whereArr = array("admission_id" => $admission);
                //       var_dump( $dataArr);
                $this->Generic_model->updateData("new_admission", $dataArr, $whereArr);

                $dataArr2 = array(
                    "child_id" => $this->input->post("child_id"),
                    "class_name" => $this->input->post("renewal_class"),
                    "reg_year" => $this->input->post("renewal_class"),
                    "reg_date" => $this->input->post("today"),
                );
                //        var_dump($dataArr2);
                $this->Generic_model->insertData('registration', $dataArr2);

                $dataArr3 = array(
                    "txn_id" =>  $txn_id,
                    "child_id" => $this->input->post("child_id"),
                    "p_type" => $this->input->post("p_type"),
                    "class_name" => $this->input->post("renewal_class"),
                    "date" => $this->input->post("today"),
                    "payment_by" => $this->input->post("person"),
                    "payment_amount" => $this->input->post("amt"),
                    "year" => $this->input->post("renewal_class"),
                    "addedby" => $username,
                );
                //        var_dump($dataArr3);die;
                $result2=$this->Generic_model->insertData('payment', $dataArr3);
                
                if ($result2) {
                    $fields=array(      //elements to load in the receipt
                               "child.child_id", "last_name","first_name","class_name",
                               "p_type","txn_id","date","year","payment_by","payment_amount","addedby",
                                       );
                    $wherefieldtablefrom = array('txn_id' => $txn_id);
                    $tablefrom = 'child';
                    $tablejoin = 'payment';
                    $tablejoincondition = 'child.child_id = payment.child_id';
                    $data['results'] =  $this->Generic_model->join($fields, $wherefieldtablefrom, $tablefrom, $tablejoin, $tablejoincondition);

                    $htmldata = $this->load->view('reports/payments/renewal_reg_payment_receipt',$data,TRUE);

                    //Load MPDF From Library
                    $this->load->library('mmpdf');
                    $mmpdf = $this->mmpdf->load();
                    $mmpdf->SetHTMLHeader("");
                    
                    $mmpdf->SetFooter("");
                    $mmpdf->WriteHTML($htmldata);

                  $mmpdf->Output("assets/pdf/payment_slip_" . $txn_id . ".pdf", 'F');
                }

                $data = array("serial" => $serialNo);
                $whereArr = array("type" => "txn");
                $this->Generic_model->updateData("serials", $data, $whereArr);

                redirect(base_url() . '/index.php/payments/');
            } else {
                $this->load->view('admin/accessDeniedPage');
            }
            //outer else
        } else {
            redirect('login/index');
        }
    }

    public function Renewal() {

        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*"; //get teacher info
                $whereArr = array("user_id" => $username);
                $data['userData'] = $this->Generic_model->getData($fields, 'admins', $whereArr);

                $serial = $this->Generic_model->getData('serial', 'serials', array("type" => "txn"));
                $serialNo = $serial[0]->serial + 1;
                $data['serial'] = $serialNo;

                $child_id = $this->input->post("child_id");
                $reg_year = $this->input->post("renewal_year");
                $txn_id = $this->input->post("Txn_id");
                 
                $dataArr = array(
                    "child_id" => $child_id,
                    "reg_year" => $reg_year,
                );
//        var_dump($dataArr);
                $checkavailabilty_1 = $this->system_model->checkRegAvail($dataArr); //whether this child is already reg for selected year
//        var_dump($checkavailabilty_1);
                if ($checkavailabilty_1 > 0) {
                    $record = array("record2" => "NONO", "child_id" => $child_id, "reg_year" => $reg_year);
                    echo json_encode($record);
                } else {
                    $checkavailabilty = $this->system_model->checkRegistration($child_id); //
                    if ($checkavailabilty > 0) { //setting previous class deactivating
                        $data = array("status" => 1); //delete Student
                        $WhereArr = array('child_id' => $child_id);
                        $this->Generic_model->updateData("registration", $data, $WhereArr);
                    }

                    $dataArr2 = array(
                        "child_id" => $child_id,
                        "class_name" => $this->input->post("renewal_class"),
                        "reg_year" => $reg_year,
                        "reg_date" => $this->input->post("today"),
                    );
//                            var_dump($dataArr2);
                    $result = $this->Generic_model->insertData('registration', $dataArr2);

                    $dataArr3 = array(
                        "txn_id" =>  $txn_id,
                        "child_id" => $child_id,
                        "p_type" => $this->input->post("p_type"),
                        "class_name" => $this->input->post("renewal_class"),
                        "date" => $this->input->post("today"),
                        "payment_by" => $this->input->post("person"),
                        "payment_amount" => $this->input->post("amt"),
                        "year" => $reg_year,
                        "addedby" => $username,
                    );
//                        var_dump($dataArr3);
                    $result2 = $this->Generic_model->insertData('payment', $dataArr3);
//                    var_dump($result2);
                    if ($result2) {
                    $fields=array(      //elements to load in the receipt
                               "child.child_id", "last_name","first_name","class_name",
                               "p_type","txn_id","date","year","payment_by","payment_amount","addedby",
                                       );
                    $wherefieldtablefrom = array('txn_id' => $txn_id);
                    $tablefrom = 'child';
                    $tablejoin = 'payment';
                    $tablejoincondition = 'child.child_id = payment.child_id';
                    $data['results'] =  $this->Generic_model->join($fields, $wherefieldtablefrom, $tablefrom, $tablejoin, $tablejoincondition);
// var_dump($data);
                    $htmldata = $this->load->view('reports/payments/renewal_reg_payment_receipt',$data,TRUE);

                    //Load MPDF From Library
                    $this->load->library('mmpdf');
                    $mmpdf = $this->mmpdf->load();
                    $mmpdf->SetHTMLHeader("");
                    
                    $mmpdf->SetFooter("");
                    $mmpdf->WriteHTML($htmldata);

                  $mmpdf->Output("assets/pdf/payment_slip_" . $txn_id . ".pdf", 'F');
                }

                    $data = array("serial" => $serialNo);
                    $whereArr = array("type" => "txn");
                    $this->Generic_model->updateData("serials", $data, $whereArr);

                    $record = array("record1" => $result, "child_id" => $child_id, "reg_year" => $reg_year);
                    echo json_encode($record);
                }
//         redirect(base_url() . '/index.php/payments/');
            } else {
                $this->load->view('admin/accessDeniedPage');
            }
            //outer else
        } else {
            redirect('login/index');
        }
    }

    public function miscFee() {

        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*"; //get teacher info
                $whereArr = array("user_id" => $username);
                $data['userData'] = $this->Generic_model->getData($fields, 'admins', $whereArr);

                $serial = $this->Generic_model->getData('serial', 'serials', array("type" => "txn"));
                $serialNo = $serial[0]->serial + 1;
                $data['serial'] = $serialNo;
//        var_dump($_POST);die;
                $txn_id = $this->input->post("Txn_id");
                $dataArr4 = array(
                    "date" => $this->input->post("today"),
                    "txn_id" => $txn_id,
                    "p_type" => $this->input->post("p_type"),
                    "description" => $this->input->post("detail"),
                    "class_name" => $this->input->post("monthly_class"),
                    "child_id" => $this->input->post("child_id_monthly"),
                    "payment_by" => $this->input->post("person"),
                    "year" => $this->input->post("year"),
                    "payment_amount" => $this->input->post("amt"),
                    "addedby" => $username
                );
//                                    var_dump($dataArr4);
                $result2 = $this->Generic_model->insertData('payment', $dataArr4);
                if ($result2) {
                    $fields=array(      //elements to load in the receipt
                               "child.child_id", "last_name","first_name",
                               "p_type","txn_id","date","description","payment_by","payment_amount","addedby",
                                       );
                        $wherefieldtablefrom = array('txn_id' => $txn_id);
                        $tablefrom = 'child';
                        $tablejoin = 'payment';
                        $tablejoincondition = 'child.child_id = payment.child_id';
                        $data['results'] =  $this->Generic_model->join($fields, $wherefieldtablefrom, $tablefrom, $tablejoin, $tablejoincondition);

                    $htmldata = $this->load->view('reports/payments/misc_payment_receipt',$data,TRUE);

                    //Load MPDF From Library
                    $this->load->library('mmpdf');
                    $mmpdf = $this->mmpdf->load();
                    $mmpdf->SetHTMLHeader("");
                    
                    $mmpdf->SetFooter("");
                    $mmpdf->WriteHTML($htmldata);

                  $mmpdf->Output("assets/pdf/payment_slip_" . $txn_id . ".pdf", 'F');
                }

                $data = array("serial" => $serialNo);
                $whereArr = array("type" => "txn");
                $this->Generic_model->updateData("serials", $data, $whereArr);

                redirect(base_url() . '/index.php/payments/');
            } else {
                $this->load->view('admin/accessDeniedPage');
            }
            //outer else
        } else {
            redirect('login/index');
        }
    }

    public function monthlyFee() {

        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*"; //get teacher info
                $whereArr = array("user_id" => $username);
                $data['userData'] = $this->Generic_model->getData($fields, 'admins', $whereArr);

                $serial = $this->Generic_model->getData('serial', 'serials', array("type" => "txn"));
                $serialNo = $serial[0]->serial + 1;
                $data['serial'] = $serialNo;

                $now = new DateTime(); //Foreach to add classes 
                $year = $now->format("Y");

                $month = $this->input->post("month", TRUE);
                $month = implode(",", $month); // convert select arr to string
//       var_dump( $month);die;
//      var_dump($username);
//                var_dump($_POST);
//                var_dump($this->input->post("month"));die;
                $txn_id = $this->input->post("Txn_id");
                $dataArr5 = array(
                    "date" => $this->input->post("today"),
                    "txn_id" => $txn_id,
                    "p_type" => $this->input->post("p_type"),
                    "class_name" => $this->input->post("monthly_class"),
                    "child_id" => $this->input->post("child_id_monthly"),
                    "payment_by" => $this->input->post("person"),
                    "year" => $this->input->post("year"),
                    "payment_amount" => $this->input->post("amt"),
                    "month" => $month,
                    "addedby" => $username,
                );

                $result2 = $this->Generic_model->insertData('payment', $dataArr5);
//        $this->load->view('newEmptyPHP');die;
//        var_dump($result2);
                if ($result2) {
                    
                        $fields=array(      //elements to load in the receipt
                               "child.child_id", "last_name","first_name",
                               "p_type","txn_id","date","month","payment_by","payment_amount","addedby",
                                       );
                        $wherefieldtablefrom = array('txn_id' => $txn_id);
                        $tablefrom = 'child';
                        $tablejoin = 'payment';
                        $tablejoincondition = 'child.child_id = payment.child_id';
                        $data['results'] =  $this->Generic_model->join($fields, $wherefieldtablefrom, $tablefrom, $tablejoin, $tablejoincondition);

                    $htmldata = $this->load->view('reports/payments/monthly_payment_receipt',$data,TRUE);

                    //Load MPDF From Library
                    $this->load->library('mmpdf');
                    $mmpdf = $this->mmpdf->load();
                    $mmpdf->SetHTMLHeader("");
                    
                    $mmpdf->SetFooter("");
                    $mmpdf->WriteHTML($htmldata);

//                    $mmpdf->Output("student_list.pdf", 'I');
                  $mmpdf->Output("assets/pdf/payment_slip_" . $txn_id . ".pdf", 'F');
                }
//        
                $data = array("serial" => $serialNo);
                $whereArr = array("type" => "txn");
                $this->Generic_model->updateData("serials", $data, $whereArr);

                redirect(base_url() . '/index.php/payments/');
            } else {
                $this->load->view('admin/accessDeniedPage');
            }
            //outer else
        } else {
            redirect('login/index');
        }
    }

    public function allPayments() {
        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*"; //get teacher info
                $whereArr = array("user_id" => $username);
                $data['userData'] = $this->Generic_model->getData($fields, 'admins', $whereArr);

                $fields = '*';
                $whereArr = array();
                $data['Tnxs'] = $this->Generic_model->getData($fields, 'payment', $whereArr); //public function getData($fieldset, $tableName, $where = '')
//      var_dump( $data['Tnxs']);die;      
                $this->load->view('admin/payments/allPayments', $data);
            } else {
                $this->load->view('admin/accessDeniedPage');
            }
            //outer else
        } else {
            redirect('login/index');
        }
    }

    public function printReceipt($idp) {
        $id = utf8_decode(urldecode($idp));

        $fieldUser = "*";
        $tableUser = "payment";
        $wherefieldUser = array("txn_id" => $id);
        //$wherefieldUser = array('user_id' => $user_id);
        $userData = $this->Generic_model->getData($fieldUser, $tableUser, $wherefieldUser);
        $data['studentData'] = $userData;

        //$htmldata = $this->load->view('reports/student_id_cards', $data, TRUE);
        $this->load->view('reports/payments/student_payment_receipt', $data);

//            $this->load->view(base_url(('assets/admin_assets/img/logo.png')));
    }

    
    public function admissionsRegistrations() {
        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*"; //get teacher info
                $whereArr = array("user_id" => $username);
                $data['userData'] = $this->Generic_model->getData($fields, 'admins', $whereArr);

                $fields = "*"; //subject teachers for Data Table
                $data['registrations'] = $this->Generic_model->getData($fields, 'registration');

                $fields = "*"; //subject teachers for Data Table
                $whereArr = array("status" => 0);
                $data['newRegistrations'] = $this->Generic_model->getData($fields, 'new_admission', $whereArr);

                $this->load->view('admin/payments/admissionsRegistrations', $data);
            } else {
                $this->load->view('admin/accessDeniedPage');
            }
            //outer else
        } else {
            redirect('login/index');
        }
    }
    
}
