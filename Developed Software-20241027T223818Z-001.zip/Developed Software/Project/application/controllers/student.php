<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class student extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('Generic_model', '', TRUE);
        /**if (!$this->session->userdata("username")) {
            redirect(base_url() . "index.php/login");
        };**/
        
    }
   
    public function index() {
        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
            $whereArr=array("child_status" => 0);
            $data['studentData']=$this->Generic_model->getData("*",'child',$whereArr); //public function getData($fieldset, $tableName, $where = '')

            $this->load->view('admin/student/index',$data);

			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
   //outer else
	} else {
		redirect('login/index');
	}
    }
    
    
    public function addStudentForm() {
     if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
			   $serial = $this->Generic_model->getData('serial', 'serials', array("type" => "student"));
				$data['serial'] = $serial[0]->serial + 1;
				 // var_dump($data);die;
				 $this->load->view('admin/student/addStudentForm', $data);   
						
			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
   //outer else
	} else {
		redirect('login/index');
	}
    }
    
    public function addStudent() {
        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
			   $serial = $this->Generic_model->getData('serial', 'serials', array("type" => "student"));
				$serialNo = $serial[0]->serial + 1;
				
                                $child_id = $this->input->post("st_id");
                                $first_name = $this->input->post("st_first_name");
                                $middle_name = $this->input->post("st_mid_name");
                                $last_name = $this->input->post("st_last_name");
                                $gender = $this->input->post("gender");
                                $schooling_year = $this->input->post("sch_yr");
                                $home_add_l1 = $this->input->post("add_L1");
                                $home_add_l2 = $this->input->post("add_L2");
                                $home_add_l3 = $this->input->post("add_L3");
                                $child_tel_no = $this->input->post("home_tel");
                                $emergency_con_person = $this->input->post("emergancy_name");
                                $emergency_tel_no = $this->input->post("emergancy_no");
                                $immune_des = $this->input->post("immune_details");
                                $allergy = $this->input->post("allergy");
                                $allery_type = $this->input->post("allergy_des");
                                $date_of_birth = $this->input->post("dob");
                                $date_of_immune = $this->input->post("i_date");
                                $father_id = $this->input->post("fnic");
                                $mother_id = $this->input->post("mnic");
                                $guardian_id = $this->input->post("gnic"); 
                                $P_title = $this->input->post("P_title");
                                $p_type = $this->input->post("p_type");   
                                $f_name = $this->input->post("f_name");
                                $f_job = $this->input->post("f_job");
                                $f_employer = $this->input->post("f_employer");
                                $f_tel = $this->input->post("f_tel");
                                $f_email = $this->input->post("f_email");
                                $f_add_L1 = $this->input->post("f_add_L1");
                                $f_add_L2 = $this->input->post("f_add_L2");
                                $f_add_L3 = $this->input->post("f_add_L3");
                                $m_title = $this->input->post("m_title");
                                $m_type = $this->input->post("m_type"); 
                                $m_name = $this->input->post("m_name");
                                $m_job = $this->input->post("m_job");
                                $m_employer = $this->input->post("m_employer");
                                $m_tel = $this->input->post("m_tel");
                                $m_email = $this->input->post("m_email");
                                $m_add_L1 = $this->input->post("m_add_L1");
                                $m_add_L2 = $this->input->post("m_add_L2");
                                $m_add_L3 = $this->input->post("m_add_L3");
                                $g_title = $this->input->post("g_title");
                                $g_type = $this->input->post("g_type"); 
                                $g_name = $this->input->post("g_name");
                                $g_job = $this->input->post("g_job");
                                $g_employer = $this->input->post("g_employer");
                                $g_tel = $this->input->post("g_tel");
                                $g_email = $this->input->post("g_email");
                                $g_add_L1 = $this->input->post("g_add_L1");
                                $g_add_L2 = $this->input->post("g_add_L2");
                                $g_add_L3 = $this->input->post("g_add_L3");
                                
                                $child_id_ltrim = ltrim($child_id, " ");
                                $first_name_ltrim = ltrim($first_name, " ");
                                $middle_name_ltrim = ltrim($middle_name, " ");
                                $last_name_ltrim = ltrim($last_name, " ");
                                $gender_ltrim = ltrim($gender, " ");
                                $schooling_year_ltrim = ltrim($schooling_year, " ");
                                $home_add_l1_ltrim = ltrim($home_add_l1, " ");
                                $home_add_l2_ltrim = ltrim($home_add_l2, " ");
                                $home_add_l3_ltrim = ltrim($home_add_l3, " ");
                                $child_tel_no_ltrim = ltrim($child_tel_no, " ");
                                $emergency_con_person_ltrim = ltrim($emergency_con_person, " ");
                                $emergency_tel_no_ltrim = ltrim($emergency_tel_no, " ");
                                $immune_des_ltrim = ltrim($immune_des, " ");
                                $allergy_ltrim = ltrim($allergy, " ");
                                $allery_type_ltrim = ltrim($allery_type, " ");
                                $date_of_birth_ltrim = ltrim($date_of_birth, " ");
                                $date_of_immune_ltrim = ltrim($date_of_immune, " ");
                                $father_id_ltrim = ltrim($father_id, " ");
                                $mother_id_ltrim = ltrim($mother_id, " ");
                                $guardian_id_ltrim = ltrim($guardian_id, " "); 
                                $P_title_ltrim = ltrim($P_title, " ");
                                $p_type_ltrim = ltrim($p_type, " ");
                                $f_name_ltrim = ltrim($f_name, " ");
                                $f_job_ltrim = ltrim($f_job, " ");
                                $f_employer_ltrim = ltrim($f_employer, " ");
                                $f_tel_ltrim = ltrim($f_tel, " ");
                                $f_email_ltrim = ltrim($f_email, " ");
                                $f_add_L1_ltrim = ltrim($f_add_L1, " ");
                                $f_add_L2_ltrim = ltrim($f_add_L2, " ");
                                $f_add_L3_ltrim = ltrim($f_add_L3, " ");
                                $m_title_ltrim = ltrim($m_title, " ");
                                $m_type_ltrim = ltrim($m_type, " ");
                                $m_name_ltrim = ltrim($m_name, " ");
                                $m_job_ltrim = ltrim($m_job, " ");
                                $m_employer_ltrim = ltrim($m_employer, " ");
                                $m_tel_ltrim = ltrim($m_tel, " ");
                                $m_email_ltrim = ltrim($m_email, " ");
                                $m_add_L1_ltrim = ltrim($m_add_L1, " ");
                                $m_add_L2_ltrim = ltrim($m_add_L2, " ");
                                $m_add_L3_ltrim = ltrim($m_add_L3, " ");
                               $g_title_ltrim = ltrim($g_title, " ");
                                $g_type_ltrim = ltrim($g_type, " ");
                                $g_name_ltrim  = ltrim($g_name, " ");
                                $g_job_ltrim = ltrim($g_job, " "); 
                                $g_employer_ltrim = ltrim($g_employer, " ");
                                $g_tel_ltrim = ltrim($g_tel, " ");
                                $g_email_ltrim = ltrim($g_email, " "); 
                                $g_add_L1_ltrim = ltrim($g_add_L1, " "); 
                                $g_add_L2_ltrim = ltrim($g_add_L2, " "); 
                                $g_add_L3_ltrim = ltrim($g_add_L3, " "); 

                                
                                
				
				$dataArr = array(
					"child_id" => $child_id_ltrim,
					"first_name" => $first_name_ltrim,
					"middle_name" => $middle_name_ltrim,
					"last_name" =>$last_name_ltrim,
					"gender" => $gender_ltrim,
					"schooling_year" => $schooling_year_ltrim,
					"home_add_l1" => $home_add_l1_ltrim,
					"home_add_l2" => $home_add_l2_ltrim,
					"home_add_l3" => $home_add_l3_ltrim,
					"child_tel_no" => $child_tel_no_ltrim,
					"emergency_con_person" => $emergency_con_person_ltrim,
					"emergency_tel_no" => $emergency_tel_no_ltrim,
					"immune_des" => $immune_des_ltrim,
					"allergy" => $allergy_ltrim,
					"allery_type" => $allery_type_ltrim,
					"date_of_birth" => $date_of_birth_ltrim,
					"date_of_immune" => $date_of_immune_ltrim,
					"father_id" => $father_id_ltrim,
					"mother_id" => $mother_id_ltrim,
					"guardian_id" => $guardian_id_ltrim, 
						);
				   
					
				$this->Generic_model->insertData('child', $dataArr);
				
				
				
				
				$dataArrF = array(
					array(
					"parent_id" => $father_id_ltrim,
					"title" => $P_title_ltrim,
					"relationship" => $p_type_ltrim,   
					"p_name" => $f_name_ltrim,
					"p_occupation" => $f_job_ltrim,
					"p_employer" => $f_employer_ltrim,
					"p_tel_no" => $f_tel_ltrim,
					"p_email" => $f_email_ltrim,
					"p_add_l1" => $f_add_L1_ltrim,
					"p_add_l2" => $f_add_L2_ltrim,
					"p_add_l3" => $f_add_L3_ltrim,
					"child_id" => $child_id_ltrim,
                                            ),
					array(
					"parent_id" => $mother_id_ltrim,
					"title" => $m_title_ltrim,
					"relationship" => $m_type_ltrim, 
					"p_name" => $m_name_ltrim,
					"p_occupation" => $m_job_ltrim,
					"p_employer" => $m_employer_ltrim,
					"p_tel_no" => $m_tel_ltrim,
					"p_email" => $m_email_ltrim,
					"p_add_l1" => $m_add_L1_ltrim,
					"p_add_l2" => $m_add_L2_ltrim,
					"p_add_l3" => $m_add_L3_ltrim,
					"child_id" => $child_id_ltrim, 
                                        	),
				   
					array(
					"parent_id" => $guardian_id_ltrim,
					"title" => $g_title_ltrim,
					"relationship" => $g_type_ltrim, 
					"p_name" => $g_name_ltrim,
					"p_occupation" => $g_job_ltrim,
					"p_employer" => $g_employer_ltrim,
					"p_tel_no" => $g_tel_ltrim,
					"p_email" => $g_email_ltrim,
					"p_add_l1" => $g_add_L1_ltrim,
					"p_add_l2" => $g_add_L2_ltrim,
					"p_add_l3" => $g_add_L3_ltrim,
					"child_id" => $child_id_ltrim,
                                		),
						);
				
				$this->Generic_model->insertBatch('parent', $dataArrF);
			   
		//       $dataArrRel = array(
		//            "gid" => $this->input->post("gpid"),
		//            "mid" => $this->input->post("mpid"),
		//            "fid" => $this->input->post("fpid"),
		//            "child_id" => $this->input->post("st_id"),
		//            );
		 // var_dump($dataArrF);die;     
		//////            
		//        $this->Generic_model->insertData('relationship', $dataArrRel);
		//        
				$data = array("serial" => $serialNo);
				$whereArr = array("type" => "student");
				$this->Generic_model->updateData("serials", $data, $whereArr);
			
				redirect(base_url().'/index.php/student');
			
			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
   //outer else
	} else {
		redirect('login/index');
	}

    }
    
    
    
    public function viewStudent($Child_ID) {
    if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
								
					$whereArr=array("Child_ID"=>$Child_ID);
					$result_s=$this->Generic_model->getData('*','child',$whereArr);
					$data['userDataStudent']=$result_s[0];
//							
					 // setting up father details
					$fields = '*';
					$whereArr=array("child_id"=>$Child_ID,'relationship'=>'Father');
					$result_s=$this->Generic_model->getData($fields,'parent',$whereArr);
					$data['father']=$result_s[0];
					
					// setting up mother details
					$fields = '*';
					$whereArr=array("child_id"=>$Child_ID,'relationship'=>'Mother');
					$result_s=$this->Generic_model->getData($fields,'parent',$whereArr);
					$data['mother']=$result_s[0];
					
					// setting up mother details
					$fields = '*';
					$whereArr=array("child_id"=>$Child_ID,'relationship'=>'Guardian');
					$result_s=$this->Generic_model->getData($fields,'parent',$whereArr);
					$data['guardian']=$result_s[0];
				   // var_dump($data);die;
							
					$this->load->view('admin/student/viewStudentForm',$data);
						
			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
   //outer else
	} else {
		redirect('login/index');
	}
    }
    
     public function editStudentForm($Child_ID) {
   if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
			    //        var_dump($Child_ID);die;
	
                $whereArr=array("Child_ID"=>$Child_ID);
                $result_s=$this->Generic_model->getData('*','child',$whereArr);
                $data['userDataStudent']=$result_s[0];

                // setting up father details
                $fields = '*';
                $whereArr=array("child_id"=>$Child_ID,'relationship'=>'Father');
                $result_s=$this->Generic_model->getData($fields,'parent',$whereArr);
                $data['father']=$result_s[0];

                // setting up mother details
                $fields = '*';
                $whereArr=array("child_id"=>$Child_ID,'relationship'=>'Mother');
                $result_s=$this->Generic_model->getData($fields,'parent',$whereArr);
                $data['mother']=$result_s[0];

                // setting up mother details
                $fields = '*';
                $whereArr=array("child_id"=>$Child_ID,'relationship'=>'Guardian');
                $result_s=$this->Generic_model->getData($fields,'parent',$whereArr);
                $data['guardian']=$result_s[0];
			//       var_dump($data);die;
							
					$this->load->view('admin/student/editStudentForm',$data);
			
			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
   //outer else
	} else {
		redirect('login/index');
	}
    }
    
    public function editStudent() {
      
            if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
			   $Child_ID = $this->input->post("st_id",TRUE);
            
				$First_Name = $this->input->post("st_first_name",TRUE);
				$Middle_Name = $this->input->post("st_mid_name",TRUE);
				$Last_Name = $this->input->post("st_last_name",TRUE);
				$Gender = $this->input->post("gender",TRUE);
				$Schooling_Year = $this->input->post("sch_yr",TRUE);
				$Home_add_L1 = $this->input->post("add_L1",TRUE);
				$Home_add_L2 = $this->input->post("add_L2",TRUE);
				$Home_add_L3 = $this->input->post("add_L3",TRUE);
				$Child_Tel_No = $this->input->post("home_tel",TRUE);
				$Emergency_Con_Person = $this->input->post("emergancy_name",TRUE);
				$Emergency_Tel_No = $this->input->post("emergancy_no",TRUE);
				$Immune_Des = $this->input->post("immune_details",TRUE);
				$Allergy = $this->input->post("allergy",TRUE);
				$Allery_Type = $this->input->post("allergy_des",TRUE);
				$Date_Of_Birth = $this->input->post("dob",TRUE);
				$Date_Of_Immune = $this->input->post("i_date",TRUE);
				$father_id = $this->input->post("fnic",TRUE);
				$mother_id = $this->input->post("mnic",TRUE);
				$guardian_id = $this->input->post("gnic",TRUE);
			   
				$parentid = $this->input->post("fnic",TRUE);
				$title = $this->input->post("p_title",TRUE);
				$p_name = $this->input->post("f_name",TRUE);
				$p_occupation = $this->input->post("f_job",TRUE);
				$p_employer = $this->input->post("f_employer",TRUE);
				$p_tel_no= $this->input->post("f_tel",TRUE);
				$p_email = $this->input->post("f_email",TRUE);
				$p_add_l1 = $this->input->post("f_add_L1",TRUE);
				$p_add_l2 = $this->input->post("f_add_L2",TRUE);
				$p_add_l3 = $this->input->post("f_add_L3",TRUE);
							
				$mid = $this->input->post("mnic",TRUE);
				$mtitle = $this->input->post("m_title",TRUE);
				$m_name = $this->input->post("m_name",TRUE);
				$m_occupation = $this->input->post("m_job",TRUE);
				$m_employer = $this->input->post("m_employer",TRUE);
				$m_tel_no= $this->input->post("m_tel",TRUE);
				$m_email = $this->input->post("m_email",TRUE);
				$m_add_l1 = $this->input->post("m_add_L1",TRUE);
				$m_add_l2 = $this->input->post("m_add_L2",TRUE);
				$m_add_l3 = $this->input->post("m_add_L3",TRUE);
				
				$gid = $this->input->post("gnic",TRUE);
				$gtitle = $this->input->post("g_title",TRUE);
				$g_name = $this->input->post("g_name",TRUE);
				$g_occupation = $this->input->post("g_job",TRUE);
				$g_employer = $this->input->post("g_employer",TRUE);
				$g_tel_no= $this->input->post("g_tel",TRUE);
				$g_email = $this->input->post("g_email",TRUE);
				$g_add_l1 = $this->input->post("g_add_L1",TRUE);
				$g_add_l2 = $this->input->post("g_add_L2",TRUE);
				$g_add_l3 = $this->input->post("g_add_L3",TRUE);
				
		   //Update stdnt table
			$dataArr = array(
				"Child_ID" => $Child_ID,
				"First_Name" => $First_Name,
				"Middle_Name" => $Middle_Name,
				"Last_Name" => $Last_Name,
				"Gender" => $Gender,
				"Schooling_Year" => $Schooling_Year,
				"Home_add_L1" => $Home_add_L1,
				"Home_add_L2" => $Home_add_L2,
				"Home_add_L3" => $Home_add_L3,
				"Child_Tel_No" => $Child_Tel_No,
				"Emergency_Con_Person" => $Emergency_Con_Person,
				"Emergency_Tel_No" => $Emergency_Tel_No,
				"Immune_Des" => $Immune_Des,
				"Allergy" => $Allergy,
				"Allery_Type" => $Allery_Type,
				"Date_Of_Birth" => $Date_Of_Birth,
				"Date_Of_Immune" => $Date_Of_Immune,
				"father_id" => $father_id,
				"mother_id" => $mother_id,
				"guardian_id" => $guardian_id,
								);
		  $whereArr=array("Child_ID" => $Child_ID);
		  $this->Generic_model->updateData("child",$dataArr,$whereArr);
		 
		  //Update parent table
			$dataArrF = array(
				"parent_id" => $parentid,
				"title" => $title,
				"p_name" => $p_name,
				"p_occupation" => $p_occupation,
				"p_employer" => $p_employer,
				"p_tel_no" => $p_tel_no,
				"p_email" => $p_email,
				"p_add_l1" => $p_add_l1,
				"p_add_l2" => $p_add_l2,
				"p_add_l3" => $p_add_l3,);
		 $whereArr=array("Child_ID" => $Child_ID,'relationship'=>'Father');
		  $this->Generic_model->updateData("parent",$dataArrF,$whereArr);
		 // var_dump($dataArrF);
		  $dataArrM = array(
				"parent_id" => $mid,
				"title" => $mtitle,
				"p_name" => $m_name,
				"p_occupation" => $m_occupation,
				"p_employer" => $m_employer,
				"p_tel_no" => $m_tel_no,
				"p_email" => $m_email,
				"p_add_l1" => $m_add_l1,
				"p_add_l2" => $m_add_l2,
				"p_add_l3" => $m_add_l3,);
		  
		  $whereArr=array("Child_ID" => $Child_ID,'relationship'=>'Mother');
		  $this->Generic_model->updateData("parent",$dataArrM,$whereArr);
		 // var_dump($dataArrM);
		   $dataArrG = array(
				"parent_id" => $gid,
				"title" => $gtitle,
				"p_name" => $g_name,
				"p_occupation" => $g_occupation,
				"p_employer" => $g_employer,
				"p_tel_no" => $g_tel_no,
				"p_email" => $g_email,
				"p_add_l1" => $g_add_l1,
				"p_add_l2" => $g_add_l2,
				"p_add_l3" => $g_add_l3,);
		  // var_dump($dataArrG);die;
		  $whereArr=array("Child_ID" => $Child_ID,'relationship'=>'Guardian');
		  $this->Generic_model->updateData("parent",$dataArrG,$whereArr);
		  
		  redirect(base_url() . "index.php/student/");
			
			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
   //outer else
	} else {
		redirect('login/index');
	}
    }
    
        public function deleteStudentForm($Child_ID) {
   if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
			    //        var_dump($Child_ID);die;
				$fields = array(
					"Child_ID" ,
					"First_Name",
					"Middle_Name" ,
					"Last_Name" ,
					"Gender" ,
					"Schooling_Year" ,
					"Home_add_L1" ,
					"Home_add_L2",
					"Home_add_L3" ,
					"Child_Tel_No" ,
					"Emergency_Con_Person" ,
					"Emergency_Tel_No" ,
					"Immune_Des",
					"Allergy",
					"Allery_Type" ,
					 "Date_Of_Birth" ,
					 "Date_Of_Immune",
					"father_id",
					"mother_id",
					"guardian_id"
							  );
				
				$whereArr=array("child_id"=>$Child_ID);
				$result_s=$this->Generic_model->getData($fields,'child',$whereArr);
				$data['userDataStudent']=$result_s[0];
				//var_dump($data[userDataStudent]) ;die;      
				 // setting up father details
				$fields = '*';
				$whereArr=array("child_id"=>$Child_ID,'relationship'=>'Father');
				$result_s=$this->Generic_model->getData($fields,'parent',$whereArr);
				$data['father']=$result_s[0];
				
				// setting up mother details
				$fields = '*';
				$whereArr=array("child_id"=>$Child_ID,'relationship'=>'Mother');
				$result_s=$this->Generic_model->getData($fields,'parent',$whereArr);
				$data['mother']=$result_s[0];
				
				// setting up mother details
				$fields = '*';
				$whereArr=array("child_id"=>$Child_ID,'relationship'=>'Guardian');
				$result_s=$this->Generic_model->getData($fields,'parent',$whereArr);
				$data['guardian']=$result_s[0];
			   // var_dump($data);die;
						
				$this->load->view('admin/student/deleteStudentForm',$data);
			
			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
   //outer else
	} else {
		redirect('login/index');
	}
    }
    
    public function deleteStudent() {
        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
			   $childID=$this->input->get('childID');
				$parentID1=$this->input->get('fatherID');
				$parentID2=$this->input->get('motherID');
				$parentID3=$this->input->get('guardianID');
		  //var_dump($data);die;
		  //      var_dump($Child_ID);die;
				
				$data=array("child_status"=>1);//delete Student
				$WhereArr=array('child_id'=>$childID);
				$this->Generic_model->updateData("child",$data,$WhereArr);
				
				$data=array("p_status"=>1);//delete father
				$WhereArr=array('child_id'=>$childID,parent_id=>$parentID1);
				$this->Generic_model->updateData("parent",$data,$WhereArr);
				
				$data=array("p_status"=>1);//delete mother
				$WhereArr=array('child_id'=>$childID,parent_id=>$parentID2);
				$this->Generic_model->updateData("parent",$data,$WhereArr);
				
				$data=array("p_status"=>1);//delete guardian
				$WhereArr=array('child_id'=>$childID,parent_id=>$parentID3);
				$this->Generic_model->updateData("parent",$data,$WhereArr);
				
				redirect(base_url()."index.php/student/");
			
			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
   //outer else
	} else {
		redirect('login/index');
	}
        
        
    }
   
}




