
<!DOCTYPE html>
<!--Administrator Dashboard-->

   
<!-- BEGIN HEAD-->
<head>
       
    <title>Class Details-Students</title>
    <?php echo $this->load->view('admin_panel/template/header'); ?>
    <!-- PAGE LEVEL STYLES -->
    <link href="<?=base_url();?>assets/admin_assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
    <!-- END PAGE LEVEL  STYLES -->
</head>
<!-- END  HEAD-->    
   
    
    <!-- BEGIN BODY-->
<body class="padTop53" >

     <!-- MAIN WRAPPER -->
    <div id="wrap" style="background-color:#b8b8b8;">
        <!--HEADER SECTION -->
         <?php echo $this->load->view('admin_panel/template/navbar'); ?>
        <!-- END HEADER SECTION -->
        


        <!-- MENU SECTION -->
          <?php echo $this->load->view('teacherViews/teacher_menubar'); ?>
        <!--END MENU SECTION -->


        <!--PAGE CONTENT -->
        <div id="content" >
            
            <div class="inner" style="min-height:1200px;background-color:transparent">
                <!---breadcrumb--->
                <div class="row">
                    <div class="col-md-12">
                        <div class="col-lg-12">
                            <div class="well-sm">
                                <div style="">
                                    <ul class="breadcrumb"  >
                                    <li> <a href="<?php echo base_url()."index.php/teacherController/teacherDashboard"?>"> Dashboard </a> </li>
                                    <li class="#"> School Settings </li>
                                    <li class="active">Class Details - Students</li>
                                     </ul>
                                </div>    
                            </div>
                        </div> <!-- /.col-lg-12 --> 
                    </div> <!-- /.col-md-12 -->
                </div><!-- /.row -->
                <!---END breadcrumb--->
                

                
                
                
                
               <div class="well" style=" background-color: transparent;">    
               <div class="col-sm-offset-1"><h3 style="font-family: calibri;margin-top:-10px"> View Students List</h3> </div> 
            </br>         
                <div class="row"> <!--Class selector-->
                <div class="col-lg-9">
                  <div class="container-fluid">
                                                <div class="row">
                                                    <div class="col col-md-6 col-sm-6 hide" id="divmessage_edgrdf">
                                                        <div style=" width: 100%; padding: 10px;" id="spnmessage_edgrdf" class="alert alert-success" role="alert">
                                                        </div>
                                                    </div>
                                                </div>
                   </div>
                    <div class="well" style=" background-color: #d6d4d4;">
                     <form action="<?php echo base_url(); ?>index.php/lessons/teachersIndex" id="add_grade_year_form" method="POST" >
                        
                                <div class='row'>
                                    <div class='col-sm-5'> 
                                            <label for="TName" class="control-label"> Class Name</label>
                                        </div>
                                    <div class='col-sm-5'>
                                        <select class="form-control" id="clz_nm" name="clz_nm" required="">
                                                <option value="">- select -</option>
                                                <?php
                                                foreach ($clz as $userItem) {

                                                    echo "<option value='" . $userItem->class_name. "'>" . $userItem->class_name. "</option>";
                                                }
                                                ?>
                                            </select>
                                     </div>
                                    </div> 
                       </form>  
                    </div> 
                </div>
                </div><!--Class selector-->
            
                <div container='fluid'>
            <div class="row hide" id="tble">
                    <div class="panel panel-default">
                        <div class="panel-heading" id="panel_head">
                      <!--panel Header-->
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body" style="padding-top: 1%; padding-left: 0%; padding-right: 0%; padding-bottom: 0%;">
                            <div class="col-md-12 table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="mytable1">
                                    <thead>                                                   
                                        <tr>
                                            <th>Student_ID</th>
                                            <th>Name</th>
                                            <th>Date Of Birth</th>
                                            <th>Contact No</th>
                                            <th>Registered DAte</th>
                                            <!--<th>Action</th>-->
                                        </tr>
                                    </thead>
                                    <tbody id="transfer_body1">

                                    </tbody>
                                </table>
                            </div><!-- /.table-responsive -->
                        </div><!-- /.panel-body -->
                        <div id="bmn1" class="panel-footer">
                        </div>                                                
                    </div><!-- /.panel -->
      
            </div>
               </div>    
              </div>
            </div>
                         
              
                     
            </div><!--END PAGE CONTENT -->
         </div><!--END MAIN WRAPPER -->
    
    
                <!-- PAGE LEVEL SCRIPTS -->
                <?php echo $this->load->view('admin_panel/template/footer'); ?> 
                <script src="<?=base_url();?>assets/admin_assets/plugins/dataTables/jquery.dataTables.js"></script>
                <script src="<?=base_url();?>assets/admin_assets/plugins/dataTables/dataTables.bootstrap.js"></script>
                <script>
                     $(document).ready(function () {
                         $('#dataTables-example').dataTable();
                     });
                </script>
                <!-- END PAGE LEVEL SCRIPTS -->  
                
                
                <script>
        $(document).ready(function () {
            $('#clz_nm').change(function () {
                abcd = this.value;
                baseurl = "http://localhost:8080/Project/";
              //alert(abcd);
                $("#JQ_header").remove();
                $("#tble").fadeOut("slow");
                $(".rec_id1").remove().fadeOut('slow');
               $.ajax({
                    //type: "GET",
                    url: baseurl + "index.php/teacherController/classDetailsStudentList/" + abcd,
                    // data: {grade_id: grade_id},
                    dataType: 'json',
                    beforeSend: function() {
//                        alert('dssa');
                        $('.rec_id1').val('');
                        },
                    success: function (data) {
                        
                        if (data.record1 === "NONO") { //this is kept for future use
                                $("#spnmessage_edgrdf").removeAttr("class", "alert alert-danger");
                                $("#spnmessage_edgrdf").attr("class", "alert alert-danger");
                                $("#spnmessage_edgrdf").html('<p><strong>There are No Approved Lesson Plans For This Class</strong></p>');
                                $("#divmessage_edgrdf").removeAttr("class", "hide");
                                $("#divmessage_edgrdf").fadeIn(1500);
                                $("#divmessage_edgrdf").delay(2500).fadeOut(1500);
                                setTimeout(function () {
                                    location.reload();
                                }, 40009999999);
                        }
                        
                        
                        
                       else {
                              $('<h3 id="JQ_header">Students Registered for ' + data.rec1 + '</h3>').appendTo("#panel_head");
                                     $("#tble").fadeIn("slow");
                                     $("#tble").removeAttr("class", "hide");
                                     $.each(data.record, function (i, obj) {// appr[vedlessonplans forclasses table append
                                          
                                        $('<tr class="rec_id1">' +
//                                                '<td><input id="abc1' + i + '" name="std_id[]" value="' + obj.id + '" type="checkbox" class="abc1 checkthis" /></td>' +
                                                '<td>' + obj.child_id + '</td>' +
                                                '<td>' + obj.first_name + "&nbsp"+ obj.middle_name +"&nbsp"+ obj.last_name +'</td>' +
                                                '<td>' + obj.date_of_birth + '</td>' +
                                                '<td>' + obj.child_tel_no + '</td>' +
                                                '<td>' + obj.reg_date + '</td>' +
                                                '</tr>').appendTo("#transfer_body1").fadeIn("slow");

                                        $("[data-toggle=tooltip]").tooltip();
                                    });
                                    $('#mytable1').dataTable();
//                                    $('#mytable1').dataTable({
//                                      "bLengthChange": false,   
//                                    });
                         } 
                    }
                });
            });
        });</script>
                
                
                                <!--Load Edit Lesson Plan Modal-->
                    <script> 
                        $(document).ready(function(){
                            
                             $(".editLP").click(function () {
                baseurl = "http://localhost:8080/Project/";
                p_id = this.id;
//                $('#editLPForm')[0].reset();
                $.ajax({
                    url: baseurl + "index.php/lessons/editLPFormModal/" + p_id,
                    // data: {po_no: po_no},
                    dataType: 'json',
                    
                    success: function (data) {
                        alert(data);
                        var id = data.record[0]["id"];
                        var act = data.record[0]["lesson_plan_des"];
                        var on = data.record[0]["added_on"];
                        var strt = data.record[0]["start_date"];
                        var da = data.record[0]["end_date"];
                        var com = data.record[0]["comment"];
                        
                        $("#activity").val(act);
                        $("#fromD").val(strt);
                        $("#ToD").val(da);
                        $("#LP_id").val(id);
                        $("#add").val(on);
                        $("#comment").val(com);
                  }
                });
            });
                        });
              
                    </script>

</body> 
<!-- END BODY-->
   
 
</html>

