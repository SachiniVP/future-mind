
<!DOCTYPE html>
<!--Administrator Dashboard-->

   
<!-- BEGIN HEAD-->
<head>
       
    <title>View Student Form</title>
    <?php echo $this->load->view('admin_panel/template/header'); ?>
</head>
<!-- END  HEAD-->    
   
    
    <!-- BEGIN BODY-->
<body class="padTop53" >

     <!-- MAIN WRAPPER -->
    <div id="wrap" style="background-color:#b8b8b8;">
        <!--HEADER SECTION -->
         <?php echo $this->load->view('admin_panel/template/navbar'); ?>
        <!-- END HEADER SECTION -->
        


        <!-- MENU SECTION -->
          <?php echo $this->load->view('parentsView/parents_menubar'); ?>
        <!--END MENU SECTION -->


        <!--PAGE CONTENT -->
        <div id="content" >

            <div class="inner" style="min-height:1200px;background-color:transparent;">
                <!---breadcrumb--->
                <div class="row">
                    <div class="col-md-12">
                        <div class="col-lg-12">
                            <div class="well-sm">
                                <ul class="breadcrumb">
                                    <li> <a href="<?php echo base_url()."index.php/parentsController/parentsDashboard"?>"> Dashboard </a> </li>
                                    <li class="#"> Profile </li>
                                </ul>
                            </div>
                        </div> <!-- /.col-lg-12 --> 
                    </div> <!-- /.col-md-12 -->
                </div><!-- /.row -->
                <!---END breadcrumb--->
                
                
                <!--add student form-->
                
                <h3 style="font-family:serif;margin-top:-10px"> Personal Details</h3>
                <div class="well" style="background-color: #d6d4d4;">
                     
                    
                <div class="form-group">
                <!--student ID--> 
                                <div class='row'>
                                    <div class='col-sm-3'> 
                                            <label for="student_id" class="control-label">Student ID</label>
                                    </div>
                                    <div class='col-sm-4'>
                                        <div class='form-group'>
                                            <input type="text" value="<?php echo $userDataStudent->child_id ; ?>" id="st_id" name="st_id"   class="form-control"  readonly/>
                                        </div>
                                    </div>
                                </div>  
                 <!--student ID-->
                </div>
                <div class="form-group">
                 <!--student name-->    
                                   <div class='row'>
                                        <div class='col-sm-3'> 
                                                <label for="student_name" class="control-label">Student Name</label>
                                        </div>
                                        <div class='col-sm-4'>
                                            <div class='form-group'>
                                                <input type="text" readonly value="<?php echo $userDataStudent->first_name ; ?>" id="st_first_name" name="st_first_name"   class="form-control"  required="true"  placeholder="First Name"/>
                                            </div>
                                        </div>
                                        <div class='col-sm-4'>
                                            <div class='form-group'>
                                                <input type="text" readonly value="<?php echo $userDataStudent->middle_name ; ?>" id="st_mid_name" name="st_mid_name"    class="form-control"  placeholder="Middle Name"/>
                                            </div>
                                        </div>
                                    </div>
                                     <div class="row">
                                       <div class="col-sm-6 col-sm-offset-3"><input type="text" readonly value="<?php echo $userDataStudent->last_name ; ?>" id="st_last_name" name="st_last_name"  class="form-control"  placeholder="Last Name"/></div>
                                     </div> 
                                     <!--/student name-->
                </div>
                
                <div class="form-group">
                             
                                  <!--student gender-->
                                     <div class="row">
                                        <div class='col-sm-3'> 
                                                <label for="student_gender" class="control-label" >Gender</label>
                                        </div>
                                        <div class='col-sm-2'>
                                            <div class='form-group'>
                                               
                                                <input type="text" id="" name="gender"  value="<?php echo $userDataStudent->gender;?>"   class="form-control" readonly />
                                            </div>
                                        </div>
                                        
                                      </div>
                                     <!--/student gender-->
                                      </br>
                  <!--/student gender-->
                </div>
              
                <div class="form-group">
                <!--student DOB-->
                                     <div class="row">
                                        <div class='col-sm-3'> 
                                                <label for="student_dob" class="control-label">Date of Birth</label>
                                                
                                        </div>
                                         <div class='col-sm-3'>
                                            <div class='form-group'>
                                                <input type="date" readonly value="<?php echo $userDataStudent->date_of_birth;?>" id="dob" name="dob" class="form-control"  Placeholder="YYYY-MM-DD" />
                                                
                                            </div>
                                        </div>
                                      </div>
                 <!--/student DOB--> 
                </div>
                
                <div class="form-group">
                 <!--school year-->
                                     <div class="row">
                                        <div class='col-sm-3'> 
                                                <label for="school_year" class="control-label">Year of Schooling</label>
                                        </div>
                                        <div class='col-sm-3'> 
                                        <div class='form-group'>
                                            <input type="number" readonly value="<?php echo $userDataStudent->schooling_year ; ?>" id="sch_yr"  name="sch_yr"  maxlength="4"  class="form-control"  required="true"  />
                                        </div>
                                        </div>    
                                      </div>
                 <!--/school year-->
                </div>
                
                <div class="form-group">
                <!--student address-->
                                     <div class='row'>
                                        <div class='col-sm-3'> 
                                                <label for="home_address" class="control-label">Home Address</label>
                                        </div>
                                        <div class='col-sm-6'>
                                            <div class='form-group'>
                                                <input type="text" readonly value="<?php echo $userDataStudent->home_add_l1 ; ?>" id="add_L1" name="add-L1"   class="form-control"  required="true"  placeholder="Line 1"/>
                                            </div>
                                        </div>
                                     </div>
                                     <div class="row">
                                       <div class="col-sm-6 col-sm-offset-3"><input type="text" readonly value="<?php echo $userDataStudent->home_add_l2 ; ?>" id="add_L2" name="add_L2"   class="form-control"  placeholder="Line 2"/></div>
                                     </div> 
                                     </br> 
                                     <div class="row">
                                       <div class="col-sm-6 col-sm-offset-3"><input type="text" readonly value="<?php echo $userDataStudent->home_add_l3 ; ?>" id="add_L3" name="add_L3"   class="form-control"  placeholder="Line 3"/></div>
                                     </div>
                 <!--student address-->
                </div>
                
                <div class="form-group">
                 <!--student Tel No-->
                                     <div class="row">
                                        <div class='col-sm-3'> 
                                                <label for="student_tel_no" class="control-label">Home Telephone Number</label>
                                        </div>
                                         <div class='col-sm-4'>
                                            <div class='form-group'>
                                                <input type="text" readonly value="<?php echo $userDataStudent->child_tel_no ; ?>" id="home_tel" name="home_tel"   class="form-control"  minlength="10" maxlength="10"  placeholder="Number with 10 digits"/>
                                            </div>
                                        </div>
                                      </div>
                 <!--/student Tel No-->
                </div>
                
                <div class="form-group">
                 <!--emergency contact person-->
                                      <div class='row'>
                                        <div class='col-sm-3'> 
                                              <label for="Emergancy_name" class="control-label">Emergency Contact Person</label>
                                        </div>
                                        <div class='col-sm-4'>
                                            <div class='form-group'>
                                                <input type="text" readonly value="<?php echo $userDataStudent->emergency_con_person ; ?>" id="emergancy_name" name="emergancy_name"   class="form-control"    placeholder="Name"/>
                                            </div>
                                        </div>
                                        <div class='col-sm-4'>
                                            <div class='form-group'>
                                                <input type="text" readonly value="<?php echo $userDataStudent->emergency_tel_no ; ?>"  id="emergancy_no" name="semergancy_no"   class="form-control"  maxlength="10"  required="true" placeholder="Contact No"/>
                                            </div>
                                        </div>
                                       </div> 
                                       <!--/emergency contact person-->
                </div>
                </div> 
                
                <h3 style="font-family:serif;margin-top:-10px"> Health Details</h3>
                <div class="well" style="background-color: #d6d4d4;">
                
                              <!--allergy-->
                                     <div class="row">
                                        <div class='col-sm-3'> 
                                                <label for="any_alergy" class="control-label">Any Allergies?</label>
                                        </div>
                                        <div class='col-sm-2'>
                                            <div class='form-group'>
                                                
                                                <input type="text"  value="<?php echo $userDataStudent->allergy; ?>"   id="" name="allergy" class="form-control" readonly />
                                            </div>
                                        </div>
                                     
                                      </div>
                                     <!--/allergy-->
                                     
                                     </br>
                                     <!--allergy type-->
                                     <div class="row">
                                        <div class='col-sm-3'> 
                                                <label for="allergy_des" class="control-label">If Yes, Type?</label>
                                        </div>
                                        <div class='col-sm-6'>
                                            <div class='form-group'>
                                                <textarea id="allergy_des"      readonly value="<?php echo $userDataStudent->allery_type ; ?>"      name="allergy_des" rows="3" cols="80" class="form-control">
                                                </textarea>
                                            </div>
                                        </div>
                                      </div>
                                     <!--/allergy type-->
                                     </br>
                                     <!-- immune DATE-->
                                     <div class="row">
                                        <div class='col-sm-3'> 
                                                <label for="immune_date" class="control-label">Date of Immunization</label>
                                        </div>
                                    
                                         <div class='col-sm-3'>
                                             <div class='form-group'>
                                                <input type="date"      readonly value="<?php echo $userDataStudent->date_of_immune ; ?>"           id="i_date" name="i_date" class="form-control"  value="" />

                                             </div>
                                         </div> 
                                      </div>    
                                        <!-- immune DATE-->
                                     </br>
                                     <div class="row">
                                         <div class='col-sm-3'> 
                                                <label for="immune_details" class="control-label">Immune details</label>
                                        </div>
                                      
                                         
                                         <div class='col-sm-6'>
                                            <div class='form-group'>
                                                <textarea id="immune_details"  readonly value="<?php echo $userDataStudent->immune_des; ?>"          name="immune_details" rows="4" cols="80" class="form-control">
                                                </textarea>
                                            </div>
                                            
                                        </div>
                                      </div>
                                     <!-- /immune-->
                                     </br>    
                </div>
                
                <h3 style="font-family:serif;margin-top:-10px"> Parents Details</h3>
                <div class="well" style="background-color: #d6d4d4;">
                                
                <!----Fathers' details---> 
                <div class="well" style=" background-color: #d6d4d4;">        
                
                <div class="form-group">
                <!---NIC-->
                <div class='row'>
                <div class='col-sm-3'> 
                        <label for="f_nic" class="control-label">Father' NIC</label>
                </div>
                <div class='col-sm-4'>
                    <div class='form-group'>
                        <input type="text" readonly value="<?php echo $father->parent_id; ?>" id="fnic" name="fnic"   class="form-control"  placeholder="Insert   NIC *********V" />
                    </div>
                </div>
                </div> 
                <!---/NIC-->
                </div>
                                
                              
                <div class="form-group">
                <!--parent name-->    
               <div class='row'>
                    <div class='col-sm-3'> 
                            <label for="f_name" class="control-label">Father's Name</label>
                    </div>
                    <div class='col-sm-8'>
                        <div class='form-group'>
                            <input type="text" readonly value="<?php echo $father->title.":"."&nbsp;".$father->p_name; ?>" id="f_name" name="f_name"   class="form-control"   placeholder="Father's Name"/>
                        </div>
                    </div>
                </div> 
               <!--/parent name-->
                
                </div>
                
                 <div class="form-group">
                 <!--parent job-->    
                   <div class='row'>
                        <div class='col-sm-3'> 
                                <label for="f_job" class="control-label">Occupation</label>
                        </div>
                        <div class='col-sm-4'>
                            <div class='form-group'>
                                <input type="text" readonly value="<?php echo $father->p_occupation; ?>" id="f_job" name="f_job"   class="form-control"   placeholder="Eg:Doctor/Engineer"/>
                            </div>
                        </div>
                    </div> 
                   <!--/parent job--> 
                 
                 </div>
                
                <div class="form-group">
            <!--parent employer name-->    
               <div class='row'>
                    <div class='col-sm-3'> 
                            <label for="f_employer" class="control-label">Name of the Employer</label>
                    </div>
                    <div class='col-sm-8'>
                        <div class='form-group'>
                            <input type="text" readonly value="<?php echo $father->p_employer; ?>" id="f_employer" name="f_employer"   class="form-control"  placeholder="ABC Company Ltd,Matara"/>
                        </div>
                    </div>
                </div> 
               <!--/parent employer name-->
                </div>
                
                 <div class="form-group">
                 <!--parent address-->
                     <div class='row'>
                        <div class='col-sm-3'> 
                                <label for="f_address" class="control-label">Mailing Address</label>
                        </div>
                        <div class='col-sm-6'>
                            <div class='form-group'>
                                <input type="text" readonly value="<?php echo $father->p_add_l1; ?>" id="f_add_L1" name="f_add_L1"   class="form-control"    placeholder="Line 1"/>
                            </div>
                        </div>
                     </div>
                     <div class="row">
                       <div class="col-sm-6 col-sm-offset-3"><input type="text" readonly value="<?php echo $father->p_add_l2; ?>" id="f_add_L2" name="f_add_L2"   class="form-control"  placeholder="Line 2"/></div>
                     </div> 
                     </br> 
                     <div class="row">
                       <div class="col-sm-6 col-sm-offset-3"><input type="text" readonly value="<?php echo $father->p_add_l3; ?>" id="f_add_L3" name="f_add_L3"   class="form-control"  placeholder="Line 3"/></div>
                     </div>
                     <!--parent address-->
                 </div>
                
                <br/>
                
                <div class="form-group">
                 <!--parent Tel No-->
                     <div class="row">
                        <div class='col-sm-3'> 
                                <label for="f_tel_no" class="control-label">Contact Number</label>
                        </div>
                         <div class='col-sm-4'>
                            <div class='form-group'>
                                <input type="text" readonly value="<?php echo $father->p_tel_no; ?>"  id="f_tel" name="f_tel"  maxlength="10"   class="form-control"  placeholder="Number with 10 digits"/>
                            </div>
                        </div>
                      </div>
                     <!--/parent Tel No-->
                </div>
                
                 <div class="form-group">
                 <!--parent email-->
                 <div class="row">
                    <div class='col-sm-3'> 
                            <label for="f_email" class="control-label">Email</label>
                    </div>
                     <div class='col-sm-4'>
                        <div class='form-group'>
                            <input type="email" readonly value="<?php echo $father->p_email; ?>" id="f_email" name="f_email"   class="form-control"  placeholder=""/>
                        </div>
                    </div>
                  </div>
                 <!--/parent EMAIL-->
                 </div>
                </div>
               <!----/Fathers' details---> 
               
               
        <!----Mothers' details--->
                <div class="well" style=" background-color: #d6d4d4;">   
                                                
                <div class="form-group">
                <!---PID-->
                <div class='row'>
                <div class='col-sm-3'> 
                        <label for="mnic" class="control-label">Mather's NIC</label>
                </div>
                <div class='col-sm-4'>
                    <div class='form-group'>
                        <input type="text" readonly value="<?php echo $mother->parent_id; ?>" id="mnic" name="mnic"   class="form-control"  maxlength="10"    placeholder="Insert   NIC *********V" value="0"/>
                    </div>
                </div>
                </div> 
                <!---/PID-->
                </div>
                
                
                <div class="form-group">
                <!--Mothers name-->    
               <div class='row'>
                    <div class='col-sm-3'> 
                            <label for="m_name" class="control-label">Mother's Name</label>
                    </div>
                    <div class='col-sm-8'>
                        <div class='form-group'>
                            <input type="text" readonly value="<?php echo $mother->title.":"."&nbsp;".$mother->p_name; ?>" id="m_name" name="m_name"   class="form-control"    placeholder="Mother's Name"/>
                        </div>
                    </div>
                </div> 
               <!--/Mothers name-->
                 </div>
                
                 <div class="form-group">
                 <!--Mothers job-->    
                   <div class='row'>
                        <div class='col-sm-3'> 
                                <label for="m_job" class="control-label">Occupation</label>
                        </div>
                        <div class='col-sm-4'>
                            <div class='form-group'>
                                <input type="text" readonly value="<?php echo $mother->p_occupation; ?>" id="m_job" name="m_job"   class="form-control"   placeholder="Eg:Doctor/Engineer"/>
                            </div>
                        </div>
                    </div> 
                   <!--/Mothers job--> 
                 
                 </div>
                
                <div class="form-group">
            <!--parent employer name-->    
               <div class='row'>
                    <div class='col-sm-3'> 
                            <label for="m_employer" class="control-label">Name of the Employer</label>
                    </div>
                    <div class='col-sm-8'>
                        <div class='form-group'>
                            <input type="text" readonly value="<?php echo $mother->p_employer; ?>" id="m_employer" name="m_employer"   class="form-control"  placeholder="ABC Company Ltd,Matara"/>
                        </div>
                    </div>
                </div> 
               <!--/parent employer name-->
                </div>
                
                 <div class="form-group">
                 <!--parent address-->
                     <div class='row'>
                        <div class='col-sm-3'> 
                                <label for="m_address" class="control-label">Mailing Address</label>
                        </div>
                        <div class='col-sm-6'>
                            <div class='form-group'>
                                <input type="text" readonly value="<?php echo $mother->p_add_l1; ?>" id="m_add_L1" name="m_add_L1"   class="form-control"    placeholder="Line 1"/>
                            </div>
                        </div>
                     </div>
                     <div class="row">
                       <div class="col-sm-6 col-sm-offset-3"><input type="text" readonly value="<?php echo $mother->p_add_l2; ?>" id="m_add_L2" name="m_add_L2"   class="form-control"  placeholder="Line 2"/></div>
                     </div> 
                     </br> 
                     <div class="row">
                       <div class="col-sm-6 col-sm-offset-3"><input type="text" readonly value="<?php echo $mother->p_add_l3; ?>" id="m_add_L3" name="m_add_L3"   class="form-control"  placeholder="Line 3"/></div>
                     </div>
                     <!--parent address-->
                 </div>
                
                <br/>
                
                <div class="form-group">
                 <!--parent Tel No-->
                     <div class="row">
                        <div class='col-sm-3'> 
                                <label for="f_tel_no" class="control-label">Contact Number</label>
                        </div>
                         <div class='col-sm-4'>
                            <div class='form-group'>
                                <input type="text" readonly value="<?php echo $mother->p_tel_no; ?>"  id="m_tel" name="m_tel"  maxlength="10"  class="form-control"  placeholder="Number with 10 digits"/>
                            </div>
                        </div>
                      </div>
                     <!--/parent Tel No-->
                </div>
                
                 <div class="form-group">
                 <!--parent email-->
                 <div class="row">
                    <div class='col-sm-3'> 
                            <label for="m_email" class="control-label">Email</label>
                    </div>
                     <div class='col-sm-4'>
                        <div class='form-group'>
                            <input type="email" readonly value="<?php echo $mother->p_email; ?>" id="m_email" name="m_email"   class="form-control"  placeholder=""/>
                        </div>
                    </div>
                  </div>
                 <!--/parent EMAIL-->
                 </div>
                </div>
            </div>
        <!----/Mothers' details--->
          
                <div class="well" style=" background-color: #d6d4d4;">   
        <!----Guardian's details--->
                
                
                <div class="form-group">
                <!---PID-->
                <div class='row'>
                <div class='col-sm-3'> 
                        <label for="gnic" class="control-label">Guardian's NIC</label>
                </div>
                <div class='col-sm-4'>
                    <div class='form-group'>
                        <input type="text" readonly value="<?php echo $guardian->p_add_l1; ?>" id="gnic" name="gnic"   class="form-control"  maxlength="10"  placeholder="Insert   NIC *********V" />
                    </div>
                </div>
                </div> 
                <!---/PID-->
                </div>
        
                
                <div class="form-group">
                <!--Guardians name-->    
               <div class='row'>
                    <div class='col-sm-3'> 
                            <label for="g_name" class="control-label">Guardian's Name</label>
                    </div>
                    <div class='col-sm-8'>
                        <div class='form-group'>
                            <input type="text" readonly value="<?php echo $guardian->title.":"."&nbsp;".$guardian->p_name; ?>" id="g_name" name="g_name"   class="form-control"    placeholder="Guardian's Name"/>
                        </div>
                    </div>
                </div> 
               <!--/guardians name-->
                
                </div>
                
                 <div class="form-group">
                 <!--guardians job-->    
                   <div class='row'>
                        <div class='col-sm-3'> 
                                <label for="g_job" class="control-label">Occupation</label>
                        </div>
                        <div class='col-sm-4'>
                            <div class='form-group'>
                                <input type="text" readonly value="<?php echo $guardian->p_occupation; ?>" id="g_job" name="g_job"   class="form-control"   placeholder="Eg:Doctor/Engineer"/>
                            </div>
                        </div>
                    </div> 
                   <!--/guardians job--> 
                 
                 </div>
                
                <div class="form-group">
            <!--parent employer name-->    
               <div class='row'>
                    <div class='col-sm-3'> 
                            <label for="g_employer" class="control-label">Name of the Employer</label>
                    </div>
                    <div class='col-sm-8'>
                        <div class='form-group'>
                            <input type="text" readonly value="<?php echo $guardian->p_employer; ?>" id="g_employer" name="g_employer"   class="form-control"  placeholder="ABC Company Ltd,Matara"/>
                        </div>
                    </div>
                </div> 
               <!--/parent employer name-->
                </div>
                
                 <div class="form-group">
                 <!--parent address-->
                     <div class='row'>
                        <div class='col-sm-3'> 
                                <label for="g_address" class="control-label">Mailing Address</label>
                        </div>
                        <div class='col-sm-6'>
                            <div class='form-group'>
                                <input type="text" readonly value="<?php echo $guardian->p_add_l1; ?>" id="g_add_L1" name="g_add_L1"   class="form-control"    placeholder="Line 1"/>
                            </div>
                        </div>
                     </div>
                     <div class="row">
                       <div class="col-sm-6 col-sm-offset-3"><input type="text" readonly value="<?php echo $guardian->p_add_l2; ?>" id="g_add_L2" name="g_add_L2"   class="form-control"  placeholder="Line 2"/></div>
                     </div> 
                     </br> 
                     <div class="row">
                       <div class="col-sm-6 col-sm-offset-3"><input type="text" readonly value="<?php echo $guardian->p_add_l3; ?>" id="g_add_L3" name="g_add_L3"   class="form-control"  placeholder="Line 3"/></div>
                     </div>
                     <!--parent address-->
                 </div>
                
                <br/>
                
                <div class="form-group">
                 <!--parent Tel No-->
                     <div class="row">
                        <div class='col-sm-3'> 
                                <label for="g_tel_no" class="control-label">Contact Number</label>
                        </div>
                         <div class='col-sm-4'>
                            <div class='form-group'>
                                <input type="text" readonly value="<?php echo $guardian->p_tel_no; ?>" id="g_tel" name="g_tel"   class="form-control"   maxlength="10" placeholder="Number with 10 digits"/>
                            </div>
                        </div>
                      </div>
                     <!--/parent Tel No-->
                </div>
                
                 <div class="form-group">
                 <!--parent email-->
                 <div class="row">
                    <div class='col-sm-3'> 
                            <label for="g_email" class="control-label">Email</label>
                    </div>
                     <div class='col-sm-4'>
                        <div class='form-group'>
                            <input type="email" readonly value="<?php echo $guardian->p_email; ?>" id="g_email" name="g_email"   class="form-control"  placeholder=""/>
                        </div>
                    </div>
                  </div>
                 <!--/parent EMAIL-->
                 </div>
        </div>
       <!----/Guardian's details--->
                </div>
                
                <div class="col-sm-offset-11">
                       <div class="col-sm-3">
                       <a href="<?php echo base_url(); ?>index.php/parentsController/parentsDashboard">    
                       <button class="btn btn-primary btn-lg pull-right" type="submit"> Back </button>
                       </a>
                       </div>    
                 </div> 
                
                 
             </div>
        </div>
       <!--END PAGE CONTENT -->
    </div>
     <!--END MAIN WRAPPER -->

<!-- Java Script -->
<?php echo $this->load->view('admin_panel/template/footer'); ?>  
<!-- /Java Script -->


</body>
    <!-- END BODY-->
  
</html>

