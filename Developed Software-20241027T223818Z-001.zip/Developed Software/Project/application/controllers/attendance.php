<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class attendance extends CI_Controller {

	function __construct() {
        parent::__construct();
        $this->load->model('Generic_model', '', TRUE);
        $this->load->model('system_model', '', TRUE);
        
        /**if (!$this->session->userdata("username")) {
            redirect(base_url() . "index.php/login");
        };**/
        
    }
    
    public function Index() {
        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
                        
                        $fields = array("class_name");//get the teacher name to select
                        $whereArr=array("status" => 0);
                        $data['clz']=$this->Generic_model->getData($fields,'class',$whereArr); 

                        $this->load->view('admin/attendance/atten_index',$data); 
				
			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
            //outer else
            } else {
                    redirect('login/index');
            }
    }
    public function classStudentList($class_idp) {
     if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
			     $class_id = utf8_decode(urldecode($class_idp));
                                 $fields=array(       //data table
                                       "child.child_id", 
                                       "first_name",
                                       "last_name",
                                       "middle_name", 
                                       "child_tel_no",
                                       "reg_date","class_name",
                                       );
                                    $wherefieldtablefrom = array('child.child_status'=>0,'registration.class_name'=>$class_id,'registration.status'=>0);
                                    $tablefrom = 'child';
                                    $tablejoin = 'registration';
                                    $tablejoincondition = 'child.child_id = registration.child_id';
                                    $data['student_list'] =  $this->Generic_model->join($fields, $wherefieldtablefrom, $tablefrom, $tablejoin, $tablejoincondition);
				 
                                 
				 $this->load->view('admin/attendance/attenMarkForm',$data); 
				
			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
                    //outer else
                    } else {
                            redirect('login/index');
                    }
        }
    public function studentsAvail($class_idp) {
        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
			 $class_id = utf8_decode(urldecode($class_idp));
                         
                        $fields = "child_id";
                        $whereArr = array("class_name" => $class_id,"status" =>0);
                        $result = $this->Generic_model->getData($fields, 'registration', $whereArr);
                         
//                        var_dump(count($result));die;
                       
                        if (count($result) === 0){
                                 
                            $record = array("record1"=>'NONO');
                            echo json_encode($record);
                            die;
                         }
                         else {
                               $record = array("record1"=>'yes');
                            echo json_encode($record);  
                         } 
				
			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
                    //outer else
                    } else {
                            redirect('login/index');
                    }

                }
    
     public function classEvalList($class_idp) {
     if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
			     $class_id = utf8_decode(urldecode($class_idp)); 
					$fields=array(      //Activity List to load to data table
						"teacher.teacher_id", 
						"t_name",
						"sub_name","act_name","effect_date","activity_des","id",
								);
				 $wherefieldtablefrom = array('activities.status'=>0,'teacher.status'=>0,'activities.class_nm'=>$class_id);
				 $tablefrom = 'activities';
				 $tablejoin = 'teacher';
				 $tablejoincondition = 'activities.teacher_id = teacher.teacher_id';
				 $data['activity_table'] =  $this->Generic_model->join($fields, $wherefieldtablefrom, $tablefrom, $tablejoin, $tablejoincondition);
				
				 $this->load->view('admin/School/eval/evalClassActivities',$data); 
				
			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
                    //outer else
                    } else {
                            redirect('login/index');
                    }
        }
     
     public function evalClassActSumery($id) {
     if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
			     $activity_id = utf8_decode(urldecode($id)); 
			
                        $fields=array(      //Students List to load to data table
                               "child.child_id", 
                               "first_name",
                               "last_name","level","comment","id","score",
                                       );
                        $wherefieldtablefrom = array('child.child_status'=>0,'marks.status'=>0,"marks.activity_id" =>$activity_id);
                        $tablefrom = 'child';
                        $tablejoin = 'marks';
                        $tablejoincondition = 'child.child_id = marks.child_id';
                        $data['marks_table'] =  $this->Generic_model->join($fields, $wherefieldtablefrom, $tablefrom, $tablejoin, $tablejoincondition);
                        
                       $fields = '*';//get activity data load to form
                       $whereArr = array("id" =>$activity_id);
                       $data['act']=$this->Generic_model->getData($fields,'activities',$whereArr);
                       
				 $this->load->view('admin/School/eval/evalClassActivitySummery',$data); 
				
			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
                    //outer else
                    } else {
                            redirect('login/index');
                    }

     
     }
     
     public function evalStIndex() {
        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
                        
                        $fields=array(      //Students List
                        "child.child_id", 
                        "first_name",
                        "last_name",
                            );
                     $wherefieldtablefrom = array('child.child_status'=>0,'registration.status'=>0);
                     $tablefrom = 'child';
                     $tablejoin = 'registration';
                     $tablejoincondition = 'child.child_id = registration.child_id';
                     $data['Reg_Stdnt'] =  $this->Generic_model->join($fields, $wherefieldtablefrom, $tablefrom, $tablejoin, $tablejoincondition);
                     
                     $this->load->view('admin/School/eval/evalStudent',$data); 
				
			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
            //outer else
            } else {
                    redirect('login/index');
            }
    }
    
    public function activityAvailStdnt($child_idp) {
        if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
			 $child_id = utf8_decode(urldecode($child_idp));
             //           var_dump($class_id);die;
                        $checkavailabilty = $this->system_model->activityAvailStdnt($child_id);

                        if ($checkavailabilty === '0'){
                                 
                            $record = array("record1"=>'NONO');
                            echo json_encode($record);
                         }
                         else {
                               $record = array("record1"=>'yes');
                            echo json_encode($record);  
                         } 
				
			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
                    //outer else
                    } else {
                            redirect('login/index');
                    }

    }
    
         public function stdnSubejctList($child_idp) {
     if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);            
               
			    $child_id = utf8_decode(urldecode($child_idp));
                            $data['child_id']=$child_id;
                          
                            $fields = 'class_name';//get the class
                            $whereArr = array("child_id" =>$child_id);
                            $class_name=$this->Generic_model->getData($fields,'registration',$whereArr);

                            $fields = array('sub_name','t_name','class_name','teacher_id');//get the subjects
                            $whereArr = array("class_name" =>$class_name[0]->class_name,"status"=>0);
                            $data['subjects']=$this->Generic_model->getData($fields,'subject_teacher',$whereArr);
//                            var_dump($data);
                            $this->load->view('admin/School/eval/evalStdntSubjectList',$data); 
				
			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
                    //outer else
                    } else {
                            redirect('login/index');
                    }
        }
        
        public function evalStudentActSumery($idp) {
     if ($this->session->userdata('logged_in')) {

            $session_data = $this->session->userdata('logged_in');
            $group_id = $session_data['group_id'];
            $username = $session_data['username'];

            // inner if
            if ($group_id === "10") {
                //get user info 
                $fields = "*";//get teacher info
                $whereArr=array("user_id" => $username);
                $data['userData']=$this->Generic_model->getData($fields,'admins',$whereArr);   
                
                
                $id = utf8_decode(urldecode($idp));
//                var_dump($id);
                list($sub_name,$teacher_id,$t_name,$class_name,$child_id)= explode(":",$id);
                        
                        $data['sub_name']=$sub_name;
                        $data['t_name']=$t_name;
                        $data['class_name']=$class_name;
                        $data['child_id']=$child_id;
                        
                        $fields=array("first_name","last_name",);
                        $whereArr = array('child_id'=>$child_id);
                        $data['student_name']=$this->Generic_model->getData($fields,'child',$whereArr);
              
//                        var_dump($data);
                       $fields = array( 'score','activity_name','comment','level');//get activity data load to form
                       $whereArr = array("teacher_id" =>$teacher_id,'sub_name'=>$sub_name,'child_id'=>$child_id);
                       $data['student_marks_table']=$this->Generic_model->getData($fields,'marks',$whereArr);
                      
				 $this->load->view('admin/School/eval/evalStudentActivitySummery',$data); 
				
			 } else {
				   $this->load->view('admin/accessDeniedPage');
				}
                    //outer else
                    } else {
                            redirect('login/index');
                    }

     
     }
    public function teachers() {
        $fields = array("t_name","teacher_id");//get the teacher name to select
        $whereArr=array("status" => 0);
        $data['TName']=$this->Generic_model->getData($fields,'teacher',$whereArr); 
        //var_dump($data);die;
        
        $this->load->view('admin/School/eval/teacher/index',$data);
    }
    
    public function teachersIndex() {
        $TName = $this->input->post("TName");
        list($t_id,$tname)= explode(":",$TName);
        $data['tname']=$tname;
        
        $fields = "*";//get the subects to be seleceted DATA TABLE
        $whereArr=array("teacher_id"=>$t_id,"status" => 0);
        $data['assigns']=$this->Generic_model->getData($fields,'subject_teacher',$whereArr); 

        $fields = "*";//show activities DATA TABLE
        $whereArr=array("teacher_id"=>$t_id,"status" => 0);
        $data['records']=$this->Generic_model->getData($fields,'activities',$whereArr); 
         
        $this->load->view('admin/School/eval/teacher/index_2',$data);
    }
    
    public function addActivityForm($var) {
        $id = utf8_decode(urldecode($var));
         //   var_dump($idp);   
         list($t_id,$suject,$class_name)= explode(":",$id);
          $data['ids']=array($t_id,$suject,$class_name);
//         var_dump($data['ids']);
         $this->load->view('admin/School/eval/teacher/addActivityForm',$data);
    }
    
    public function addActivity() {
//    var_dump($_POST);
         $now = new DateTime();//Foreach to add classes 
         $add_date = $now->format("Y-m-d");
         $dataArr = array(
            "class_nm" => $this->input->post("class"),
            "sub_name" => $this->input->post("subject"),
            "teacher_id" => $this->input->post("teacher_id"),
            "act_name" => $this->input->post("act_name"),
            "year" => $this->input->post("year"),
            "month" => $this->input->post("month"),
            "activity_des" => $this->input->post("activity"),
            "added_on" => $add_date,
            "effect_date" => $this->input->post("fromD"),
            );
//        var_dump($dataArr ); die;
        $this->Generic_model->insertData('activities', $dataArr);
        redirect(base_url() . '/index.php/evaluation/teachers');
    }
    
     public function editActivityFormModal($id) {
                $id_n = utf8_decode(urldecode($id));
               $fields = array("act_name", "added_on","id","effect_date","activity_des",);
                $whereArr = array("id" => $id_n);
                $result = $this->Generic_model->getData($fields, 'activities', $whereArr);
//                var_dump($result);die;
                echo json_encode($result);

                }
       public function editActivityModal() {
//              var_dump($_POST);die;
                $id = $this->input->post("LP_id", TRUE);
                $dataArr = array(
                    "activity_des" => $this->input->post("activity"),
                    "added_on" => $this->input->post("add"),
                    "effect_date" => $this->input->post("fromD"),
                    "act_name" => $this->input->post("actN"),       
                    );
                  $whereArr = array("id" => $id);
//                  var_dump($dataArr);
//                  var_dump($whereArr);
                $this->Generic_model->updateData("activities", $dataArr, $whereArr);
                redirect(base_url() . '/index.php/evaluation/teachers');
        }
            
        public function delete_LP($id) { //add grades for the School
                    $dataArr=array("status"=>1);//delete Student
                    $WhereArr=array('id'=>$id);
                   
                    $this->Generic_model->updateData("activities",$dataArr,$WhereArr);
                    
                   redirect(base_url() . '/index.php/evaluation/teachers');
             }      
                
        public function addMarksForm($var) {
        $id = utf8_decode(urldecode($var));
//            var_dump($idp);  die; 
         list($actvity_id,$class_name)= explode(":",$id);
        
        $fields = '*';//get activity data load to form
        $whereArr = array("id" =>$actvity_id);
        $data['act']=$this->Generic_model->getData($fields,'activities',$whereArr);
        
        $fields1 = '*';//get activity data load to form
        $data['level']=$this->Generic_model->getData($fields,'rubrics');
        
         $fields=array(      //Students List
            "child.child_id", 
            "first_name",
            "last_name",
                );
         $wherefieldtablefrom = array('child.child_status'=>0,'registration.class_name'=>$class_name,'registration.status'=>0);
         $tablefrom = 'child';
         $tablejoin = 'registration';
         $tablejoincondition = 'child.child_id = registration.child_id';
         $data['students'] =  $this->Generic_model->join($fields, $wherefieldtablefrom, $tablefrom, $tablejoin, $tablejoincondition);
//            var_dump($data);
 //         $data['ids']=array($t_id,$suject,$class_name);
//         var_dump($data['ids']);
         $this->load->view('admin/School/eval/teacher/addMarksForm',$data);
             }  
             
         public function addMarks() {
                      var_dump($_POST);die;
                $id = $this->input->post("LP_id", TRUE);
                $dataArr = array(
                    "year" => $this->input->post("year"),
                    "month" => $this->input->post("month"),
                    "start_date" => $this->input->post("fromD"),
                    "end_date" => $this->input->post("ToD"), 
                    "lesson_plan_des" => $this->input->post("activity"),
                    "comment" => $this->input->post("comment"),
                    "approval_status" => $this->input->post("approval_status"),
                    );
//                var_dump($dataArr);die;
                  $whereArr = array("id" => $id);
                $this->Generic_model->updateData("lesson_plan", $dataArr, $whereArr);
               redirect(base_url() . '/index.php/evaluation/teachers');
    }     
                
     
    
    
    public function adminIndex() {
        $fields = '*';//get the class teachers for DATA TABLE
        $wherefieldtablefrom = array('lesson_plan.status'=>0,'lesson_plan.approval_status'=>'Pending Approval');
        $tablefrom = 'lesson_plan';
        $tablejoin = 'teacher';
        $tablejoincondition = 'lesson_plan.teacher_id = teacher.teacher_id';
        $data['records'] =  $this->Generic_model->join($fields, $wherefieldtablefrom, $tablefrom, $tablejoin, $tablejoincondition);
      
        $this->load->view('admin/School/lessons/admin/index',$data);
    }            
        public function approveLPForm($id) {
   //              var_dump($_POST);
   //                $id = $this->input->post("LP_id", TRUE);
           $fields = '*';
           $whereArr = array("id" => $id);
           $result=$this->Generic_model->getData($fields,'lesson_plan',$whereArr);
           $data['records']=$result[0];
           $this->load->view('admin/School/lessons/admin/approveLP',$data);
           }     
        
        public function approval() {
//              var_dump($_POST);
                $id = $this->input->post("LP_id", TRUE);
                $dataArr = array(
                    "year" => $this->input->post("year"),
                    "month" => $this->input->post("month"),
                    "start_date" => $this->input->post("fromD"),
                    "end_date" => $this->input->post("ToD"), 
                    "lesson_plan_des" => $this->input->post("activity"),
                    "comment" => $this->input->post("comment"),
                    "approval_status" => $this->input->post("approval_status"),
                    );
//                var_dump($dataArr);die;
                  $whereArr = array("id" => $id);
                $this->Generic_model->updateData("lesson_plan", $dataArr, $whereArr);
                redirect(base_url() . '/index.php/lessons/adminIndex');
        }
        public function approvedLPs($var) {
             $id = utf8_decode(urldecode($var));
              //   var_dump($idp);   
              list($t_id,$suject,$class_name)= explode(":",$id);
               $data['ids']=array($t_id,$suject,$class_name);
     //         var_dump($data['ids']);
           $fields = '*';
           $whereArr = array("teacher_id" => $t_id,"sub_name" =>$suject,"class_nm" =>$class_name,"approval_status" =>'Approved',"status"=>0);
           $data['approved']=$this->Generic_model->getData($fields,'lesson_plan',$whereArr);
           $this->load->view('admin/School/lessons/teacher/approvedLessonPlans',$data);
         }
         
        public function viewLPFormModal($id) {
                $id_n = utf8_decode(urldecode($id));
               $fields = array("lesson_plan_des","comment");
                $whereArr = array("id" => $id_n);
                $result = $this->Generic_model->getData($fields, 'lesson_plan', $whereArr);
                echo json_encode($result);

                } 
         
       public function lessonPlansForClasses() {
        $fields = array("class_name");//get the teacher name to select
        $whereArr=array("status" => 0);
        $data['clz']=$this->Generic_model->getData($fields,'class',$whereArr); 
        //var_dump($data);die;
        
        $this->load->view('admin/School/lessons/admin/lessonPlansForClasses',$data);
        }  
         public function clazAvailable($class_idp) { //to load subjects to the form //JQUERY
          // var_dump($class_id);die;
           $class_id = utf8_decode(urldecode($class_idp));
//           var_dump($class_id);die;
           $checkavailabilty = $this->system_model->checkApprovedSubjectLessonPClass($class_id);
                if ($checkavailabilty > 0) {
                    
                      $fields=array("id",
                          "sub_name",
                          "lesson_plan.teacher_id",
                          "year",
                          "month",
                          "start_date",
                          "end_date","lesson_plan_des","added_on","comment","t_name",    //data table
                             );
         $wherefieldtablefrom = array("class_nm" => $class_id,"approval_status"=>'Approved');
         $tablefrom = 'teacher';
         $tablejoin = 'lesson_plan';
         $tablejoincondition = 'teacher.teacher_id = lesson_plan.teacher_id';
         $result =  $this->Generic_model->join($fields, $wherefieldtablefrom, $tablefrom, $tablejoin, $tablejoincondition);
                  $record = array("record" =>$result, "rec1"=> $class_id);
//                   var_dump($record);die;
                    echo json_encode($record);
                } else {
                   
                    $record = array("record1" => "NONO");
//                     var_dump($result);die;
                      echo json_encode($record);
                }
        
        
    }
         
      public function lessonPlansForTeachers() {
        $fields = array("teacher_id","t_name",);//get the teacher name to select
        $whereArr=array("status" => 0);
        $data['clz']=$this->Generic_model->getData($fields,'teacher',$whereArr); 
        //var_dump($data);die;
        
        $this->load->view('admin/School/lessons/admin/lessonPlansForTeachers',$data);
        }  
       
}